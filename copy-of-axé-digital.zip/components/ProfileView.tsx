
import React from 'react';
import { ArrowLeft, Edit2, Calendar, Shield, CreditCard, Clock, MapPin, Download } from 'lucide-react';
// Use MediumProfile instead of Medium
import { MediumProfile } from '../types';

interface ProfileViewProps {
  // Use MediumProfile instead of Medium
  medium: MediumProfile;
  onBack: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ medium, onBack }) => {
  return (
    <div className="animate-in slide-in-from-right-4 duration-500">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold mb-8 transition-colors"
      >
        <ArrowLeft size={20} />
        Voltar para a lista
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm text-center">
            <div className="relative inline-block mb-6">
              <img 
                src={medium.photo} 
                {/* Fixed: changed medium.name to medium.fullName */}
                alt={medium.fullName} 
                className="w-32 h-32 rounded-3xl object-cover border-4 border-white shadow-xl" 
              />
              <div className="absolute -bottom-2 -right-2 bg-amber-500 text-stone-900 p-2 rounded-xl shadow-lg">
                <Shield size={16} />
              </div>
            </div>
            {/* Fixed: changed medium.name to medium.fullName */}
            <h2 className="text-2xl font-bold text-stone-900">{medium.fullName}</h2>
            {/* Fixed: changed medium.orixa to medium.paiOrixa */}
            <p className="text-amber-600 font-bold uppercase tracking-wider text-sm mt-1">{medium.paiOrixa}</p>
            <div className="mt-8 flex items-center justify-center gap-3">
              <button className="flex-1 bg-stone-900 text-white py-2.5 rounded-xl font-bold hover:bg-stone-800 transition-all">
                Enviar Mensagem
              </button>
              <button className="p-2.5 border border-stone-200 rounded-xl text-stone-400 hover:text-stone-900 transition-all">
                <Edit2 size={20} />
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
            <h3 className="font-bold text-stone-900 border-b border-stone-100 pb-4">Informações de Contato</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-sm">
                <Calendar className="text-stone-400" size={18} />
                <span className="text-stone-500">Início em:</span>
                <span className="font-semibold text-stone-900">{new Date(medium.entryDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Shield className="text-stone-400" size={18} />
                <span className="text-stone-500">Papel:</span>
                <span className="font-semibold text-stone-900">{medium.role}</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-stone-600">
                <Clock className="text-stone-400" size={18} />
                <span>Última presença: 14/05/2024</span>
              </div>
            </div>
          </div>
        </div>

        {/* Financial and Documents */}
        <div className="lg:col-span-2 space-y-8">
          {/* Stats Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-stone-500 text-sm font-medium">Saldo Atual</span>
                <CreditCard className="text-emerald-500" size={20} />
              </div>
              <h4 className={`text-3xl font-bold ${medium.balance < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {medium.balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </h4>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-stone-500 text-sm font-medium">Frequência</span>
                <Clock className="text-blue-500" size={20} />
              </div>
              <h4 className="text-3xl font-bold text-stone-900">92%</h4>
            </div>
          </div>

          {/* Documents */}
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-stone-900">Documentação Digital</h3>
              <button className="text-amber-600 font-bold text-sm hover:underline">Ver todos</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Ficha de Inscrição', 'Termo de Responsabilidade', 'Cópia RG/CPF'].map((doc) => (
                <div key={doc} className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100 hover:border-amber-200 transition-all cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-amber-600">
                      <Download size={20} />
                    </div>
                    <span className="text-sm font-bold text-stone-700">{doc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* History */}
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
            <h3 className="text-xl font-bold text-stone-900 mb-6">Histórico Financeiro Recente</h3>
            <div className="space-y-4">
              {[
                { label: 'Mensalidade Maio', value: -50, date: '10/05/2024' },
                { label: 'Mensalidade Abril', value: 50, date: '10/04/2024' },
                { label: 'Cantina - Suco e Coxinha', value: -15, date: '05/04/2024' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-3 border-b border-stone-50 last:border-0">
                  <div className="flex flex-col">
                    <span className="font-semibold text-stone-900">{item.label}</span>
                    <span className="text-xs text-stone-400">{item.date}</span>
                  </div>
                  <span className={`font-bold ${item.value < 0 ? 'text-rose-500' : 'text-emerald-500'}`}>
                    {item.value > 0 ? '+' : ''}{item.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;


import React from 'react';
import { UserRole, MembershipStatus, MediumProfile, Terreiro } from '../types';
import { User, Shield, ArrowRight } from 'lucide-react';

interface LoginProps {
  terreiro: Terreiro;
  onLogin: (u: MediumProfile) => void;
}

const LoginMock: React.FC<LoginProps> = ({ terreiro, onLogin }) => {
  const loginAs = (role: UserRole) => {
    const mockUser: MediumProfile = {
      id: role === UserRole.MASTER ? 'master-1' : 'medium-1',
      terreiroId: terreiro.id,
      role: role,
      status: MembershipStatus.ACTIVE,
      fullName: role === UserRole.MASTER ? 'Pai de Santo Admin' : 'Médium Corrente',
      email: role === UserRole.MASTER ? 'master@ase.com' : 'medium@ase.com',
      phone: '(11) 98888-8888',
      entryDate: '2023-01-01',
      balance: role === UserRole.MASTER ? 0 : -50,
      paiOrixa: role === UserRole.MASTER ? 'Oxalá' : 'Ogum',
      // ... default empty values
      fatherName: '', motherName: '', address: '', nationality: '', profession: '',
      birthDate: '', bloodType: '', emergencyContactName: '', emergencyContactPhone: '',
      emergencyContactRelation: '', hasDisease: false, continuousMedicine: false,
      chefeDeCabeca: '', spiritualHistory: '', anjoGuarda: '', exu: '', trancaRua: '',
      maeOrixa: '', gerente: '', segundoOrixa: '', terceiroOrixa: ''
    };
    onLogin(mockUser);
  };

  return (
    <div className="min-h-screen bg-stone-900 flex items-center justify-center p-6">
      <div className="max-w-md w-full space-y-8 text-center">
        <div className="bg-amber-500 w-20 h-20 rounded-3xl mx-auto flex items-center justify-center font-black text-3xl text-stone-900 shadow-2xl">
          AD
        </div>
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter">Entrar no {terreiro.name}</h2>
          <p className="text-stone-400 mt-2 font-medium">Escolha como deseja acessar para simular:</p>
        </div>

        <div className="grid gap-4">
          <button 
            onClick={() => loginAs(UserRole.MASTER)}
            className="group bg-white p-6 rounded-3xl flex items-center gap-4 hover:bg-amber-500 transition-all text-left shadow-xl"
          >
            <div className="w-12 h-12 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-900 group-hover:bg-white/20 transition-colors">
              <Shield size={24} />
            </div>
            <div className="flex-1">
              <p className="font-black text-stone-900 group-hover:text-stone-900 uppercase text-xs tracking-widest">Acesso Administrativo</p>
              <p className="text-stone-500 font-bold group-hover:text-stone-900/70">Pai de Santo / Master</p>
            </div>
            <ArrowRight size={20} className="text-stone-300 group-hover:text-stone-900" />
          </button>

          <button 
            onClick={() => loginAs(UserRole.MEDIUM)}
            className="group bg-stone-800 p-6 rounded-3xl flex items-center gap-4 hover:bg-white transition-all text-left"
          >
            <div className="w-12 h-12 bg-stone-700 rounded-2xl flex items-center justify-center text-stone-300 group-hover:bg-stone-100 group-hover:text-stone-900 transition-colors">
              <User size={24} />
            </div>
            <div className="flex-1">
              <p className="font-black text-stone-400 group-hover:text-stone-900 uppercase text-xs tracking-widest">Acesso de Membro</p>
              <p className="text-stone-500 font-bold group-hover:text-stone-900/70">Médium da Corrente</p>
            </div>
            <ArrowRight size={20} className="text-stone-600" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginMock;

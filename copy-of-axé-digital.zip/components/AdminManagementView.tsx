
import React, { useState } from 'react';
import { 
  Building, Shield, BarChart3, History as HistoryIcon, Save, Search,
  CheckCircle2, XCircle, Phone, MapPin, Calendar, AlertCircle, Key, Copy, Users
} from 'lucide-react';
import { Terreiro, MediumProfile, UserRole, MembershipStatus } from '../types';

interface AdminMgmtProps {
  terreiro: Terreiro;
  user: MediumProfile;
}

const AdminManagementView: React.FC<AdminMgmtProps> = ({ terreiro, user }) => {
  const [activeTab, setActiveTab] = useState('info');
  const [inviteCode, setInviteCode] = useState(`ASE-${terreiro.id.split('-')[1] || 'ADMIN'}`);

  const tabs = [
    { id: 'info', label: 'Dados do Terreiro', icon: Building },
    { id: 'users', label: 'Gestão de Usuários', icon: Shield },
    { id: 'reports', label: 'Relatórios Operacionais', icon: BarChart3 },
    { id: 'logs', label: 'Histórico de Ações', icon: HistoryIcon },
  ];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(inviteCode);
    alert('Código copiado para a área de transferência!');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-stone-900 tracking-tighter">Gestão Administrativa</h2>
          <p className="text-stone-500">Unidade: {terreiro.name} | ID: {terreiro.id}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-2">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all border-2 ${
                activeTab === t.id 
                  ? 'bg-white border-amber-500 text-stone-900 shadow-md' 
                  : 'bg-transparent border-transparent text-stone-400 hover:bg-stone-100'
              }`}
            >
              <t.icon size={20} className={activeTab === t.id ? 'text-amber-500' : ''} />
              <span className="font-bold text-sm">{t.label}</span>
            </button>
          ))}
          
          <div className="mt-8 p-6 bg-stone-900 rounded-[2rem] text-white">
            <h4 className="text-[10px] font-black uppercase text-amber-500 tracking-widest mb-4 flex items-center gap-2">
              <Key size={12} /> Convite de Membros
            </h4>
            <div className="bg-stone-800 p-4 rounded-xl flex items-center justify-between">
              <span className="font-black text-lg tracking-widest">{inviteCode}</span>
              <button onClick={handleCopyCode} className="text-stone-400 hover:text-white"><Copy size={16} /></button>
            </div>
            <p className="mt-4 text-[10px] text-stone-500 leading-relaxed font-bold">Envie este código para novos médiuns. Eles o usarão no momento do cadastro inicial.</p>
          </div>
        </div>

        <div className="lg:col-span-3 bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
          {activeTab === 'info' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-black text-stone-900">Institucional</h3>
                <button className="flex items-center gap-2 bg-stone-900 text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-stone-800 transition-all">
                  <Save size={16} /> Salvar Alterações
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2"><label className="text-[10px] font-black uppercase text-stone-400">Nome do Terreiro</label><input type="text" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none font-bold" defaultValue={terreiro.name} /></div>
                <div className="space-y-2"><label className="text-[10px] font-black uppercase text-stone-400">Data de Fundação</label><input type="date" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm" defaultValue={terreiro.foundationDate} /></div>
                <div className="space-y-2 md:col-span-2"><label className="text-[10px] font-black uppercase text-stone-400">Endereço Completo</label><input type="text" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm outline-none" placeholder="Rua, Número, Bairro, Cidade - UF" /></div>
                <div className="space-y-2 md:col-span-2"><label className="text-[10px] font-black uppercase text-stone-400">Observações Administrativas</label><textarea className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm outline-none" rows={4}></textarea></div>
              </div>
            </div>
          )}
          
          {activeTab === 'users' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-black text-stone-900">Membros da Unidade</h3>
              </div>
              <p className="text-xs text-stone-500 font-bold bg-amber-50 p-4 rounded-xl border border-amber-100">Dica: Os dados exibidos aqui são estritamente desta unidade. Membros de outros terreiros SaaS não são listados.</p>
              <div className="bg-stone-50 p-8 rounded-3xl border border-dashed border-stone-200 text-center">
                <Users size={32} className="mx-auto text-stone-300 mb-4" />
                <p className="text-stone-400 text-sm font-bold">Use o módulo "Médiuns" para gestão detalhada de cada perfil.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminManagementView;

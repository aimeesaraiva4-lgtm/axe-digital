
import React, { useMemo } from 'react';
import { 
  Users, 
  TrendingUp, 
  Wallet, 
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MediumProfile, Terreiro, MembershipStatus, AgendaEvent, AgendaEventStatus, Transaction, TransactionType } from '../types';

interface DashboardProps {
  mediums: MediumProfile[];
  terreiro: Terreiro;
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ mediums = [], terreiro, onNavigate }) => {
  const activeCount = mediums.filter(m => m.status === MembershipStatus.ACTIVE).length;
  const pendingCount = mediums.filter(m => m.status === MembershipStatus.PENDING).length;

  const { nextEvent, balance } = useMemo(() => {
    const savedEvents: AgendaEvent[] = JSON.parse(localStorage.getItem(`ase_agenda_${terreiro.id}`) || '[]');
    const scheduled = savedEvents.filter(e => e.status === AgendaEventStatus.SCHEDULED);
    const now = new Date();
    
    const next = scheduled
      .sort((a, b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime())
      .find(e => new Date(`${e.date}T${e.time}`) >= now);

    const txs: Transaction[] = JSON.parse(localStorage.getItem(`ase_tx_${terreiro.id}`) || '[]');
    const currentBalance = txs.reduce((acc, tx) => 
      tx.type === TransactionType.INCOME ? acc + tx.amount : acc - tx.amount, 0
    );

    return { nextEvent: next, balance: currentBalance };
  }, [terreiro.id]);

  const chartData = useMemo(() => {
    // Gerar dados mock baseados no terreiro ou reais se existirem
    return [
      { name: 'Jan', revenue: 4000 + (terreiro.id.length * 100) },
      { name: 'Fev', revenue: 3000 + (terreiro.id.length * 50) },
      { name: 'Mar', revenue: 2000 + (terreiro.id.length * 200) },
      { name: 'Abr', revenue: 2780 + (terreiro.id.length * 150) },
      { name: 'Mai', revenue: 1890 + (terreiro.id.length * 80) },
      { name: 'Jun', revenue: 2390 + (terreiro.id.length * 120) },
    ];
  }, [terreiro.id]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 tracking-tight">Painel Geral</h1>
          <p className="text-stone-500 mt-1">Bem-vindo ao centro de comando do {terreiro.name}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onNavigate('attendance')}
            className="px-6 py-2.5 bg-stone-900 text-white rounded-xl font-semibold shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all"
          >
            Registrar Presença QR
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
              <Users size={24} />
            </div>
            <span className="flex items-center text-green-600 text-sm font-bold">
              Estável <ArrowUpRight size={16} />
            </span>
          </div>
          <p className="text-stone-500 font-medium">Médiuns Ativos</p>
          <h3 className="text-2xl font-bold text-stone-900 mt-1">{activeCount}</h3>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <Wallet size={24} />
            </div>
            <span className="flex items-center text-emerald-600 text-sm font-bold">
              Atualizado
            </span>
          </div>
          <p className="text-stone-500 font-medium">Saldo em Caixa</p>
          <h3 className="text-2xl font-bold text-stone-900 mt-1">R$ {balance.toLocaleString('pt-BR')}</h3>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
              <Calendar size={24} />
            </div>
            <span className="text-stone-500 text-sm font-bold">
              Esta semana
            </span>
          </div>
          <p className="text-stone-500 font-medium">Presença Média</p>
          <h3 className="text-2xl font-bold text-stone-900 mt-1">84%</h3>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
              <TrendingUp size={24} />
            </div>
            <span className="flex items-center text-stone-500 text-sm font-bold">
              Total
            </span>
          </div>
          <p className="text-stone-500 font-medium">Pendências</p>
          <h3 className="text-2xl font-bold text-stone-900 mt-1">{pendingCount}</h3>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Next Event shortcut */}
        <div className="lg:col-span-1">
          <div className="bg-stone-900 text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden h-full flex flex-col justify-between">
            <div className="absolute -right-10 -top-10 text-white/5">
              <Calendar size={180} />
            </div>
            
            <div>
              <div className="flex items-center gap-2 text-amber-500 text-[10px] font-black uppercase tracking-[0.2em] mb-6">
                <Sparkles size={14} /> Próxima Gira
              </div>
              
              {nextEvent ? (
                <div className="space-y-4">
                  <h3 className="text-4xl font-black tracking-tighter leading-tight">{nextEvent.title}</h3>
                  <div className="flex flex-col gap-1 text-stone-400 font-bold">
                    <p className="text-sm">{new Date(nextEvent.date + 'T' + nextEvent.time).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                    <p className="text-sm">Às {nextEvent.time} • {nextEvent.location}</p>
                  </div>
                </div>
              ) : (
                <p className="text-stone-500 font-bold">Nenhum evento agendado para os próximos dias.</p>
              )}
            </div>

            <button 
              onClick={() => onNavigate('agenda')}
              className="mt-10 w-full py-4 bg-white text-stone-900 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-amber-500 transition-all"
            >
              Abrir Agenda Completa <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-stone-200">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-stone-900">Arrecadação Mensal (Estimada)</h3>
            <select className="bg-stone-100 border-none text-sm font-semibold rounded-lg px-3 py-1.5 outline-none">
              <option>Últimos 6 meses</option>
              <option>Último ano</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#a8a29e'}} dx={-10} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

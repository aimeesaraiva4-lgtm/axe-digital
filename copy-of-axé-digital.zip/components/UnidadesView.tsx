
import React, { useState } from 'react';
import { 
  Building2, Plus, Globe, ShieldCheck, MapPin, 
  Calendar, Phone, MoreVertical, Search, Zap, 
  ChevronRight, ArrowLeft, Trash2, Edit3, Sparkles
} from 'lucide-react';
import { Terreiro } from '../types';

interface UnidadesViewProps {
  activeTerreiro: Terreiro;
  terreiros: Terreiro[];
  onSwitch: (t: Terreiro) => void;
  onUpdateList: (list: Terreiro[]) => void;
}

const UnidadesView: React.FC<UnidadesViewProps> = ({ activeTerreiro, terreiros, onSwitch, onUpdateList }) => {
  const [showNewModal, setShowNewModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    foundationDate: new Date().toISOString().split('T')[0],
    masterPhone: '',
    address: ''
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const newT: Terreiro = {
      id: `T-SaaS-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      name: formData.name,
      foundationDate: formData.foundationDate,
      masterPhone: formData.masterPhone,
      address: formData.address,
      plan: 'FREE'
    };

    const updated = [...terreiros, newT];
    onUpdateList(updated);
    setShowNewModal(false);
    setFormData({ name: '', foundationDate: new Date().toISOString().split('T')[0], masterPhone: '', address: '' });
    alert("Nova unidade criada com sucesso! Você já pode alternar para ela.");
  };

  const handleDelete = (id: string) => {
    if (terreiros.length <= 1) return alert("Você deve ter pelo menos uma unidade ativa.");
    if (id === activeTerreiro.id) return alert("Não é possível excluir a unidade em uso.");
    
    if (confirm("ATENÇÃO: Isso excluirá permanentemente todos os dados vinculados a este terreiro (Médiuns, Financeiro, Documentos). Esta ação não pode ser desfeita. Deseja continuar?")) {
      const updated = terreiros.filter(t => t.id !== id);
      onUpdateList(updated);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 text-amber-500 mb-1">
            <Globe size={20} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Painel Multi-Terreiro</span>
          </div>
          <h1 className="text-4xl font-black text-stone-900 tracking-tighter">Minhas Unidades</h1>
          <p className="text-stone-500 font-medium mt-1">Gerencie múltiplos terreiros sob sua administração SaaS</p>
        </div>
        
        <button 
          onClick={() => setShowNewModal(true)}
          className="bg-stone-900 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-stone-900/10 hover:scale-105 transition-all"
        >
          <Plus size={20} /> Criar Nova Unidade
        </button>
      </div>

      {/* Stats row for the SaaS owner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-stone-900 p-8 rounded-[3rem] text-white flex flex-col justify-between h-48 relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 text-white/5 group-hover:scale-110 transition-transform duration-700">
            <Building2 size={120} />
          </div>
          <p className="text-stone-500 font-black text-[10px] uppercase tracking-widest">Total de Casas</p>
          <h3 className="text-5xl font-black tracking-tighter text-amber-500">{terreiros.length}</h3>
          <p className="text-[10px] font-bold text-stone-500 uppercase">Unidades centralizadas no Asé Digital</p>
        </div>

        <div className="bg-white p-8 rounded-[3rem] border border-stone-200 flex flex-col justify-between h-48 shadow-sm">
          <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest">Seu Plano</p>
          <div>
            <h3 className="text-3xl font-black tracking-tighter text-stone-900">PRO SaaS</h3>
            <p className="text-xs font-bold text-stone-400 mt-1 uppercase">Até 5 unidades • 100GB Storage</p>
          </div>
          <button className="text-amber-600 font-black text-[10px] uppercase tracking-widest hover:underline">Fazer Upgrade</button>
        </div>

        <div className="bg-emerald-50 p-8 rounded-[3rem] border border-emerald-100 flex flex-col justify-between h-48">
          <p className="text-emerald-600/60 font-black text-[10px] uppercase tracking-widest">Segurança de Dados</p>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-emerald-500 shadow-sm">
              <ShieldCheck size={28} />
            </div>
            <p className="text-xs font-bold text-emerald-800 leading-tight">Cada unidade possui seu container de dados 100% isolado.</p>
          </div>
          <p className="text-[10px] font-black text-emerald-600/40 uppercase">Certificado SaaS Digital</p>
        </div>
      </div>

      {/* Terreiros List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {terreiros.map(t => (
          <div 
            key={t.id} 
            className={`p-10 rounded-[3.5rem] border-2 transition-all group flex flex-col justify-between h-80 relative ${
              activeTerreiro.id === t.id 
                ? 'bg-white border-amber-500 shadow-2xl shadow-amber-500/10' 
                : 'bg-white border-stone-100 hover:border-stone-300'
            }`}
          >
            {activeTerreiro.id === t.id && (
              <div className="absolute top-8 right-10 flex items-center gap-2 bg-amber-500 text-stone-900 px-4 py-1.5 rounded-full font-black text-[10px] uppercase tracking-widest shadow-lg">
                <Sparkles size={14} /> Ativo Agora
              </div>
            )}

            <div className="space-y-6">
              <div className="w-16 h-16 bg-stone-900 rounded-[1.5rem] flex items-center justify-center text-amber-500">
                <Building2 size={32} />
              </div>
              
              <div>
                <h4 className="text-3xl font-black text-stone-900 tracking-tighter leading-tight group-hover:text-amber-600 transition-colors">
                  {t.name}
                </h4>
                <div className="flex items-center gap-4 mt-3">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    <Calendar size={12} /> {t.foundationDate ? new Date(t.foundationDate).getFullYear() : '---'}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    <MapPin size={12} /> {t.address ? 'Cadastrado' : 'Sem endereço'}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-stone-50 flex items-center gap-4">
              {activeTerreiro.id !== t.id ? (
                <button 
                  onClick={() => onSwitch(t)}
                  className="flex-1 bg-stone-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-stone-900/10"
                >
                  Alternar para esta Unidade
                </button>
              ) : (
                <div className="flex-1 bg-amber-50 text-amber-600 py-4 rounded-2xl font-black text-xs uppercase tracking-widest text-center">
                  Unidade Selecionada
                </div>
              )}
              <div className="flex gap-2">
                <button className="p-4 bg-stone-50 text-stone-400 rounded-2xl hover:text-stone-900 transition-all">
                  <Edit3 size={20} />
                </button>
                <button 
                  onClick={() => handleDelete(t.id)}
                  className="p-4 bg-stone-50 text-stone-400 rounded-2xl hover:text-rose-500 transition-all"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* NEW UNIT MODAL */}
      {showNewModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowNewModal(false)}></div>
           <div className="bg-white w-full max-w-xl rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-stone-900 p-12 text-white relative">
                 <button onClick={() => setShowNewModal(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white"><ArrowLeft size={24}/></button>
                 <div className="w-16 h-16 bg-amber-500 rounded-[2rem] flex items-center justify-center text-stone-900 mb-8 shadow-xl shadow-amber-500/20"><Building2 size={32} /></div>
                 <h2 className="text-4xl font-black tracking-tighter">Nova Unidade</h2>
                 <p className="text-stone-400 mt-2 font-medium">Expanda sua administração para uma nova casa.</p>
              </div>

              <form onSubmit={handleCreate} className="p-12 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Nome do Terreiro</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Templo Sagrado Axé..."
                      className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-lg font-black outline-none focus:ring-4 focus:ring-amber-500/10"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                 </div>
                 
                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Fundação</label>
                        <input 
                          type="date" 
                          className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none"
                          value={formData.foundationDate}
                          onChange={e => setFormData({...formData, foundationDate: e.target.value})}
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Telefone Resp.</label>
                        <input 
                          type="text" 
                          placeholder="(00) 00000-0000"
                          className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none"
                          value={formData.masterPhone}
                          onChange={e => setFormData({...formData, masterPhone: e.target.value})}
                        />
                    </div>
                 </div>

                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Endereço (opcional)</label>
                    <input 
                      type="text" 
                      placeholder="Rua, Cidade - UF"
                      className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none"
                      value={formData.address}
                      onChange={e => setFormData({...formData, address: e.target.value})}
                    />
                 </div>

                 <div className="pt-4">
                    <button 
                      type="submit"
                      className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-stone-900/20 hover:scale-[1.02] active:scale-95 transition-all"
                    >
                      Finalizar e Criar Unidade
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default UnidadesView;

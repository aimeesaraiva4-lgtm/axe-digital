
import React from 'react';
import { 
  FileText, 
  Folder, 
  UploadCloud, 
  Search, 
  Download, 
  Trash2,
  Lock,
  Clock
} from 'lucide-react';

const DocumentsView: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 tracking-tight">Documentação Digital</h1>
          <p className="text-stone-500">Arquivos do terreiro e documentos dos médiuns</p>
        </div>
        <button className="px-6 py-2.5 bg-stone-900 text-white rounded-xl font-bold shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all flex items-center gap-2">
          <UploadCloud size={18} />
          Fazer Upload
        </button>
      </div>

      {/* Folders */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { name: 'Médiuns', count: 124, icon: Folder, color: 'bg-amber-50 text-amber-600' },
          { name: 'Contratos', count: 12, icon: Folder, color: 'bg-blue-50 text-blue-600' },
          { name: 'Estatutos', count: 3, icon: ShieldFolder, color: 'bg-emerald-50 text-emerald-600' },
          { name: 'Financeiro', count: 56, icon: Folder, color: 'bg-rose-50 text-rose-600' },
        ].map((folder, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
            <div className={`w-12 h-12 rounded-2xl ${folder.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <folder.icon size={24} />
            </div>
            <h4 className="font-bold text-stone-900">{folder.name}</h4>
            <p className="text-xs text-stone-500">{folder.count} arquivos</p>
          </div>
        ))}
      </div>

      {/* Recent Files */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <h3 className="font-bold text-stone-900 text-xl">Arquivos Recentes</h3>
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input type="text" placeholder="Pesquisar arquivos..." className="pl-10 pr-4 py-2 bg-stone-50 rounded-xl text-sm border-none outline-none" />
          </div>
        </div>

        <div className="divide-y divide-stone-50">
          {[
            { name: 'Estatuto_Original_V3.pdf', size: '1.2 MB', date: 'Há 2 dias', user: 'Admin' },
            { name: 'Lista_Presenca_Gira_PretoVelho.xlsx', size: '450 KB', date: 'Há 5 horas', user: 'Carlos M.' },
            { name: 'RG_Frente_Ana_Silva.jpg', size: '2.1 MB', date: 'Ontem', user: 'Sistema' },
            { name: 'Contrato_Aluguel_Sede.pdf', size: '3.4 MB', date: '01/05/2024', user: 'Admin' },
          ].map((file, i) => (
            <div key={i} className="flex items-center gap-4 p-4 hover:bg-stone-50 transition-colors group">
              <div className="w-10 h-10 bg-stone-100 rounded-xl flex items-center justify-center text-stone-400">
                <FileText size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-stone-900 truncate">{file.name}</p>
                <div className="flex items-center gap-3 text-[10px] text-stone-400 uppercase font-bold tracking-wider">
                  <span>{file.size}</span>
                  <span>•</span>
                  <span>{file.date}</span>
                  <span>•</span>
                  <span>{file.user}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 text-stone-400 hover:text-stone-900 hover:bg-white rounded-lg transition-all">
                  <Download size={18} />
                </button>
                <button className="p-2 text-stone-400 hover:text-rose-500 hover:bg-white rounded-lg transition-all">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Helper internal component
const ShieldFolder = ({ size }: { size: number }) => (
  <div className="relative">
    <Folder size={size} />
    <Lock className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" size={size/2} />
  </div>
);

export default DocumentsView;

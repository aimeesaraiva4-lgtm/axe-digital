
import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, Calendar, CheckCircle2, AlertCircle, Clock, Search, 
  DollarSign, ArrowUpRight, ArrowDownRight, Users, Filter, Plus,
  History, Download, MoreVertical, Check, Settings2, FileText,
  X, Printer, ShieldCheck, Banknote, ChevronRight, Upload, Edit, Save, Trash2,
  Info, Share2
} from 'lucide-react';
import { 
  MonthlyFee, MediumProfile, Transaction, TransactionType, UserRole, MembershipStatus, Terreiro, TerreiroConfig
} from '../types';

interface MonthlyFeesViewProps {
  user: MediumProfile;
  mediums: MediumProfile[];
}

const MonthlyFeesView: React.FC<MonthlyFeesViewProps> = ({ user, mediums }) => {
  const [fees, setFees] = useState<MonthlyFee[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<MonthlyFee['status'] | 'ALL'>('ALL');
  const [showPayModal, setShowPayModal] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState<string | null>(null);
  const [showReceipt, setShowReceipt] = useState<MonthlyFee | null>(null);
  const [terreiroConfig, setTerreiroConfig] = useState<TerreiroConfig | null>(null);
  
  const [payForm, setPayForm] = useState({
    date: new Date().toISOString().split('T')[0],
    method: 'PIX' as any,
    notes: ''
  });

  const [editForm, setEditForm] = useState({
    amount: 0,
    dueDate: '',
    status: 'PENDING' as MonthlyFee['status']
  });

  const isMaster = user.role === UserRole.MASTER;
  const tId = user.terreiroId;

  // Carregar dados
  useEffect(() => {
    const savedFees = localStorage.getItem(`ase_fees_${tId}`);
    if (savedFees) setFees(JSON.parse(savedFees));

    const savedConfig = localStorage.getItem(`ase_terreiroConfig_${tId}`);
    if (savedConfig) setTerreiroConfig(JSON.parse(savedConfig));
  }, [tId]);

  // Geração Automática de Mensalidades (SaaS Logic)
  useEffect(() => {
    if (!isMaster) return;

    const existingFees: MonthlyFee[] = JSON.parse(localStorage.getItem(`ase_fees_${tId}`) || '[]');
    const activeMediums = mediums.filter(m => m.status === MembershipStatus.ACTIVE);
    
    let updated = false;
    const newFees = [...existingFees];

    activeMediums.forEach(m => {
      if (!m.monthlyFeeValue || !m.feeDueDay || !m.feeChargeStart) return;
      if (m.feeIsExempt) return;

      const [startYear, startMonth] = m.feeChargeStart.split('-').map(Number);
      const feeDate = new Date(selectedYear, selectedMonth, 1);
      const startDate = new Date(startYear, startMonth - 1, 1);
      if (feeDate < startDate) return;

      const exists = existingFees.some(f => 
        f.mediumId === m.id && f.month === selectedMonth && f.year === selectedYear
      );

      if (!exists) {
        const dueDateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(m.feeDueDay).padStart(2, '0')}`;
        
        const newFee: MonthlyFee = {
          id: `FEE-${m.id}-${selectedMonth}-${selectedYear}`,
          mediumId: m.id,
          terreiroId: tId,
          month: selectedMonth,
          year: selectedYear,
          status: 'PENDING',
          amount: m.monthlyFeeValue,
          dueDate: dueDateStr
        };
        newFees.push(newFee);
        updated = true;
      }
    });

    if (updated) {
      localStorage.setItem(`ase_fees_${tId}`, JSON.stringify(newFees));
      setFees(newFees);
    }
  }, [selectedMonth, selectedYear, mediums, tId, isMaster]);

  const handlePayConfirm = () => {
    if (!showPayModal) return;
    const index = fees.findIndex(f => f.id === showPayModal);
    if (index === -1) return;

    const fee = fees[index];
    const updatedFee: MonthlyFee = {
      ...fee,
      status: 'PAID',
      paymentDate: payForm.date,
      paymentMethod: payForm.method,
      paidAmount: fee.amount,
      notes: payForm.notes
    };

    const newFees = [...fees];
    newFees[index] = updatedFee;
    setFees(newFees);
    localStorage.setItem(`ase_fees_${tId}`, JSON.stringify(newFees));

    const med = mediums.find(m => m.id === fee.mediumId);
    const tx: Transaction = {
      id: `TX-FEE-${Date.now()}`,
      terreiroId: tId,
      type: TransactionType.INCOME,
      category: 'Mensalidades',
      amount: fee.amount,
      date: payForm.date,
      description: `Mensalidade ${selectedMonth+1}/${selectedYear} - ${med?.fullName || 'Médium'}`
    };
    const txs = JSON.parse(localStorage.getItem(`ase_tx_${tId}`) || '[]');
    localStorage.setItem(`ase_tx_${tId}`, JSON.stringify([tx, ...txs]));

    setShowPayModal(null);
  };

  const handleEditConfirm = () => {
    if (!showEditModal) return;
    const index = fees.findIndex(f => f.id === showEditModal);
    if (index === -1) return;

    const newFees = [...fees];
    newFees[index] = {
      ...newFees[index],
      amount: editForm.amount,
      dueDate: editForm.dueDate,
      status: editForm.status
    };
    setFees(newFees);
    localStorage.setItem(`ase_fees_${tId}`, JSON.stringify(newFees));
    setShowEditModal(null);
  };

  const filteredFees = useMemo(() => {
    let result = fees.filter(f => f.month === selectedMonth && f.year === selectedYear);
    
    if (!isMaster) {
      result = result.filter(f => f.mediumId === user.id);
    }

    if (statusFilter !== 'ALL') {
      result = result.filter(f => f.status === statusFilter);
    }

    if (searchTerm) {
      result = result.filter(f => {
        const m = mediums.find(med => med.id === f.mediumId);
        return m?.fullName.toLowerCase().includes(searchTerm.toLowerCase());
      });
    }

    return result.sort((a, b) => {
      const ma = mediums.find(m => m.id === a.mediumId)?.fullName || '';
      const mb = mediums.find(m => m.id === b.mediumId)?.fullName || '';
      return ma.localeCompare(mb);
    });
  }, [fees, selectedMonth, selectedYear, searchTerm, statusFilter, isMaster, user.id, mediums]);

  const stats = useMemo(() => {
    const monthFees = fees.filter(f => f.month === selectedMonth && f.year === selectedYear);
    const predicted = monthFees.reduce((acc, f) => acc + f.amount, 0);
    const received = monthFees.filter(f => f.status === 'PAID').reduce((acc, f) => acc + (f.paidAmount || f.amount), 0);
    const overdue = monthFees.filter(f => {
        const isPast = new Date(f.dueDate + 'T23:59:59') < new Date();
        return f.status === 'PENDING' && isPast;
    });
    const overdueAmount = overdue.reduce((acc, f) => acc + f.amount, 0);

    return { predicted, received, overdueCount: overdue.length, overdueAmount };
  }, [fees, selectedMonth, selectedYear]);

  const getVisualStatus = (fee: MonthlyFee) => {
    if (fee.status === 'PAID') return { label: 'PAGA', color: 'bg-emerald-50 text-emerald-600 border-emerald-100', icon: CheckCircle2 };
    if (fee.status === 'EXEMPT') return { label: 'ISENTA', color: 'bg-stone-100 text-stone-500 border-stone-200', icon: Info };
    
    const isPast = new Date(fee.dueDate + 'T23:59:59') < new Date();
    if (isPast) return { label: 'ATRASADA', color: 'bg-rose-50 text-rose-600 border-rose-100 animate-pulse', icon: AlertCircle };
    
    return { label: 'PENDENTE', color: 'bg-amber-50 text-amber-600 border-amber-100', icon: Clock };
  };

  const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-24">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tighter">Mensalidades Asé</h1>
          <p className="text-stone-500 font-medium">Controle de arrecadação por competência</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <div className="flex bg-white p-1.5 rounded-2xl border border-stone-200 shadow-sm">
            <select 
              value={selectedMonth} 
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="bg-transparent px-4 py-2 text-sm font-bold text-stone-900 focus:outline-none"
            >
              {months.map((m, i) => <option key={i} value={i}>{m}</option>)}
            </select>
            <select 
              value={selectedYear} 
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="bg-transparent px-4 py-2 text-sm font-bold text-stone-900 focus:outline-none border-l border-stone-100"
            >
              {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          {isMaster && (
            <button className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-stone-800 shadow-xl shadow-stone-900/10 transition-all">
              <Download size={18} /> Exportar
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards (Master Only) */}
      {isMaster && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden">
            <div className="absolute -right-4 -top-4 text-stone-50"><DollarSign size={80} /></div>
            <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest mb-1">Total a Receber</p>
            <h3 className="text-3xl font-black text-stone-900">R$ {stats.predicted.toLocaleString('pt-BR')}</h3>
            <p className="text-[10px] font-bold text-stone-400 mt-2">Competência {months[selectedMonth]}</p>
          </div>
          <div className="bg-emerald-500 p-8 rounded-[2.5rem] text-white shadow-xl shadow-emerald-500/20">
            <p className="text-emerald-100 font-black text-[10px] uppercase tracking-widest mb-1">Total Recebido</p>
            <h3 className="text-3xl font-black">R$ {stats.received.toLocaleString('pt-BR')}</h3>
            <div className="mt-4 w-full h-1.5 bg-emerald-700/50 rounded-full overflow-hidden">
                <div className="h-full bg-white transition-all" style={{width: `${(stats.received/stats.predicted || 0)*100}%`}}></div>
            </div>
          </div>
          <div className="bg-rose-500 p-8 rounded-[2.5rem] text-white shadow-xl shadow-rose-500/20">
            <p className="text-rose-100 font-black text-[10px] uppercase tracking-widest mb-1">Em Atraso</p>
            <h3 className="text-3xl font-black">R$ {stats.overdueAmount.toLocaleString('pt-BR')}</h3>
            <p className="text-[10px] font-bold text-rose-100/60 mt-2 uppercase tracking-widest">{stats.overdueCount} Médiuns Pendentes</p>
          </div>
        </div>
      )}

      {/* Table & Filters */}
      <div className="bg-white rounded-[3.5rem] border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-stone-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative max-w-sm w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por médium..." 
              className="w-full pl-12 pr-4 py-4 bg-stone-50 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-amber-500/10 font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
            {(['ALL', 'PENDING', 'PAID', 'EXEMPT'] as const).map(filter => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  statusFilter === filter 
                    ? 'bg-stone-900 text-white shadow-lg' 
                    : 'bg-stone-50 text-stone-400 hover:text-stone-900'
                }`}
              >
                {filter === 'ALL' ? 'Todos' : filter === 'PENDING' ? 'Em Aberto' : filter === 'PAID' ? 'Pagos' : 'Isentos'}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-stone-50 text-[10px] font-black text-stone-400 uppercase tracking-widest">
              <tr>
                <th className="px-8 py-5">Médium</th>
                <th className="px-8 py-5 text-right">Valor</th>
                <th className="px-8 py-5">Vencimento</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5">Pagamento</th>
                <th className="px-8 py-5"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredFees.map(fee => {
                const med = mediums.find(m => m.id === fee.mediumId);
                const vStatus = getVisualStatus(fee);
                return (
                  <tr key={fee.id} className="group hover:bg-stone-50 transition-colors">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <img src={med?.photo || `https://i.pravatar.cc/100?u=${fee.mediumId}`} className="w-10 h-10 rounded-xl object-cover grayscale group-hover:grayscale-0 transition-all" alt="" />
                        <div>
                          <p className="font-black text-stone-900 text-sm tracking-tight">{med?.fullName || 'Médium'}</p>
                          <p className="text-[10px] text-stone-400 font-bold uppercase tracking-tighter">{med?.paiOrixa || 'Orixá'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right font-black text-stone-900 text-sm">
                      R$ {fee.amount.toLocaleString('pt-BR')}
                    </td>
                    <td className="px-8 py-6 text-xs font-bold text-stone-500">
                      {new Date(fee.dueDate + 'T12:00:00').toLocaleDateString()}
                    </td>
                    <td className="px-8 py-6">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[9px] font-black uppercase border tracking-widest ${vStatus.color}`}>
                        <vStatus.icon size={12} />
                        {vStatus.label}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                        {fee.status === 'PAID' ? (
                            <div className="flex flex-col">
                                <span className="text-[10px] font-black text-stone-900">{new Date(fee.paymentDate!).toLocaleDateString()}</span>
                                <span className="text-[8px] font-bold text-stone-400 uppercase tracking-widest">{fee.paymentMethod}</span>
                            </div>
                        ) : (
                            <span className="text-[10px] text-stone-300 font-bold uppercase">---</span>
                        )}
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         {fee.status === 'PAID' && (
                            <button 
                              onClick={() => setShowReceipt(fee)}
                              className="p-2 bg-stone-900 text-white rounded-xl shadow-lg hover:scale-105 transition-all"
                              title="Ver Recibo"
                            >
                              <FileText size={18} />
                            </button>
                         )}
                         {isMaster && fee.status !== 'PAID' && (
                           <button 
                             onClick={() => setShowPayModal(fee.id)}
                             className="p-2 bg-stone-900 text-white rounded-xl shadow-lg shadow-stone-900/10 hover:scale-105 transition-all"
                             title="Dar Baixa"
                           >
                             <Check size={18} />
                           </button>
                         )}
                         {isMaster && (
                           <button 
                             onClick={() => {
                               setEditForm({ amount: fee.amount, dueDate: fee.dueDate, status: fee.status });
                               setShowEditModal(fee.id);
                             }}
                             className="p-2 bg-white border border-stone-200 text-stone-400 rounded-xl hover:text-amber-600 transition-all"
                             title="Editar Lançamento"
                           >
                             <Edit size={18} />
                           </button>
                         )}
                         <button className="p-2 text-stone-300 hover:text-stone-900 transition-all"><MoreVertical size={18} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredFees.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-20 text-center">
                    <div className="flex flex-col items-center gap-3 text-stone-300">
                      <Banknote size={64} className="opacity-10" />
                      <p className="font-bold text-sm uppercase tracking-widest">Nenhuma mensalidade encontrada.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: DAR BAIXA (MARCAR PAGO) */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowPayModal(null)}></div>
          <div className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
             <div className="bg-stone-900 p-10 text-white">
                <button onClick={() => setShowPayModal(null)} className="absolute top-8 right-8 text-stone-500 hover:text-white"><X /></button>
                <div className="w-16 h-16 bg-amber-500 rounded-2xl flex items-center justify-center text-stone-900 mb-6 shadow-xl shadow-amber-500/20"><Check size={32} /></div>
                <h3 className="text-3xl font-black tracking-tighter">Registrar Pagamento</h3>
                <p className="text-stone-400 text-sm mt-1">Confirme o recebimento para gerar o lançamento financeiro.</p>
             </div>
             <div className="p-10 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Data do Pagamento</label>
                        <input 
                            type="date" 
                            className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none"
                            value={payForm.date}
                            onChange={e => setPayForm({...payForm, date: e.target.value})}
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Forma</label>
                        <select 
                            className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none"
                            value={payForm.method}
                            onChange={e => setPayForm({...payForm, method: e.target.value})}
                        >
                            <option value="PIX">PIX</option>
                            <option value="DINHEIRO">DINHEIRO</option>
                            <option value="CARTÃO">CARTÃO</option>
                            <option value="OUTRO">OUTRO</option>
                        </select>
                    </div>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Observações</label>
                    <textarea 
                        className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-sm outline-none h-24"
                        placeholder="Opcional..."
                        onChange={e => setPayForm({...payForm, notes: e.target.value})}
                    />
                </div>
                <button 
                    onClick={handlePayConfirm}
                    className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black uppercase tracking-widest shadow-2xl shadow-stone-900/20 hover:scale-[1.02] active:scale-95 transition-all"
                >
                    Confirmar Recebimento
                </button>
             </div>
          </div>
        </div>
      )}

      {/* MODAL: RECIBO DIGITAL */}
      {showReceipt && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/90 backdrop-blur-md" onClick={() => setShowReceipt(null)}></div>
           <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 p-12">
              <button onClick={() => setShowReceipt(null)} className="absolute top-10 right-10 text-stone-400 hover:text-stone-900"><X size={24}/></button>
              
              <div className="text-center space-y-8 border-b-2 border-stone-100 pb-10">
                 {terreiroConfig?.logoBase64 ? (
                   <img src={terreiroConfig.logoBase64} className="h-24 mx-auto object-contain" alt="Logo" />
                 ) : (
                   <div className="w-24 h-24 bg-amber-500 text-stone-900 rounded-[2.5rem] flex items-center justify-center mx-auto text-3xl font-black shadow-xl">AD</div>
                 )}
                 <div className="space-y-2">
                    <h2 className="text-3xl font-black text-stone-900 tracking-tighter uppercase">Recibo de Mensalidade</h2>
                    <p className="text-stone-400 font-bold text-sm">Competência: {months[showReceipt.month]} / {showReceipt.year}</p>
                 </div>
              </div>

              <div className="py-10 space-y-4">
                 <p className="text-stone-600 font-medium text-center leading-relaxed italic px-8">
                    "{terreiroConfig?.defaultReceiptText || 'Declaramos o recebimento da contribuição citada para manutenção das atividades religiosas da casa.'}"
                 </p>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-8">
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Doador / Médium</p>
                       <p className="font-black text-stone-900 uppercase text-sm">
                        {mediums.find(m => m.id === showReceipt.mediumId)?.fullName}
                       </p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Valor Recebido</p>
                       <p className="text-2xl font-black text-stone-900">R$ {showReceipt.amount.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Data do Pagamento</p>
                       <p className="font-black text-stone-900">{showReceipt.paymentDate ? new Date(showReceipt.paymentDate + 'T12:00:00').toLocaleDateString() : '---'}</p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Unidade</p>
                       <p className="font-black text-stone-900 uppercase truncate">{terreiroConfig?.shortName || 'Terreiro Base'}</p>
                    </div>
                 </div>
              </div>

              <div className="text-center pt-8 space-y-6">
                 <div className="space-y-1">
                   <div className="w-48 h-px bg-stone-200 mx-auto"></div>
                   <p className="text-sm font-black text-stone-900">{terreiroConfig?.responsibleName || 'A Administração'}</p>
                   <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{terreiroConfig?.responsibleTitle || 'Tesouraria'}</p>
                 </div>

                 <div className="text-[10px] font-bold text-stone-300 uppercase tracking-widest">
                    {terreiroConfig?.address} {terreiroConfig?.cityUF && `• ${terreiroConfig.cityUF}`}
                    <br />Autenticação Digital: {showReceipt.id}
                 </div>
                 
                 <div className="flex gap-4 no-print">
                    <button onClick={() => window.print()} className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-all">
                       <Printer size={16} /> Imprimir Recibo
                    </button>
                    <button className="flex-1 py-4 bg-stone-100 text-stone-500 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                       <Share2 size={16} /> Compartilhar
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default MonthlyFeesView;

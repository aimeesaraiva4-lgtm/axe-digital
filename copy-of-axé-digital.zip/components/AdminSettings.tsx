
import React from 'react';
import { Terreiro } from '../types';
import { Building, Shield, CreditCard, ChevronRight, Zap, Cloud } from 'lucide-react';

interface AdminSettingsProps {
  currentTerreiro: Terreiro;
  terreiros: Terreiro[];
  onSwitchTerreiro: (t: Terreiro) => void;
}

const AdminSettings: React.FC<AdminSettingsProps> = ({ currentTerreiro, terreiros, onSwitchTerreiro }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 tracking-tight">Administração SaaS</h1>
          <p className="text-stone-500">Configurações globais e gerenciamento multi-unidade</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Terreiro Selector */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
             <h3 className="font-bold text-stone-900 mb-6 flex items-center gap-2">
               <Building size={20} className="text-amber-500" />
               Minhas Unidades
             </h3>
             <div className="space-y-3">
               {terreiros.map(t => (
                 <button
                   key={t.id}
                   onClick={() => onSwitchTerreiro(t)}
                   className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all ${
                     currentTerreiro.id === t.id 
                       ? 'bg-amber-50 border-amber-500 text-amber-900 ring-2 ring-amber-500/10' 
                       : 'bg-white border-stone-100 hover:border-stone-300 text-stone-600'
                   }`}
                 >
                   <div className="flex flex-col items-start">
                     <span className="font-bold text-sm">{t.name}</span>
                     <span className="text-[10px] uppercase font-bold tracking-widest opacity-60">{t.plan}</span>
                   </div>
                   <ChevronRight size={18} />
                 </button>
               ))}
               <button className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border border-dashed border-stone-300 text-stone-400 hover:text-stone-900 hover:border-stone-900 transition-all font-bold text-sm">
                 <Zap size={16} />
                 Criar Nova Unidade
               </button>
             </div>
          </div>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
             <div className="flex items-center justify-between mb-8">
               <div>
                  <h3 className="text-xl font-bold text-stone-900">Plano Atual</h3>
                  <p className="text-sm text-stone-500">Sua assinatura expira em 32 dias</p>
               </div>
               <span className="bg-stone-900 text-white px-4 py-1 rounded-full font-bold text-xs">PLANO {currentTerreiro.plan}</span>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100">
                  <Cloud className="text-blue-500 mb-4" size={32} />
                  <h4 className="font-bold text-stone-900">Armazenamento</h4>
                  <div className="mt-4 w-full h-2 bg-stone-200 rounded-full overflow-hidden">
                    <div className="w-3/4 h-full bg-blue-500"></div>
                  </div>
                  <p className="mt-2 text-xs text-stone-500">7.5 GB de 10 GB utilizados</p>
                </div>

                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100">
                  <CreditCard className="text-emerald-500 mb-4" size={32} />
                  <h4 className="font-bold text-stone-900">Faturamento</h4>
                  <p className="mt-4 text-xs text-stone-500">Última fatura: R$ 149,00</p>
                  <button className="mt-4 text-sm font-bold text-amber-600 hover:underline">Ver Notas Fiscais</button>
                </div>
             </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
            <h3 className="text-xl font-bold text-stone-900 mb-6">Segurança e Acesso</h3>
            <div className="space-y-4">
               {[
                 { label: 'Autenticação de Dois Fatores', desc: 'Aumente a segurança do acesso administrativo', active: true },
                 { label: 'Backup Automático Diário', desc: 'Dados exportados para nuvem todas as noites', active: true },
                 { label: 'Log de Auditoria', desc: 'Rastreie quem visualizou ou editou informações', active: false },
               ].map((item, i) => (
                 <div key={i} className="flex items-center justify-between py-4 border-b border-stone-50 last:border-0">
                    <div>
                      <h5 className="font-bold text-stone-900">{item.label}</h5>
                      <p className="text-xs text-stone-500">{item.desc}</p>
                    </div>
                    <div className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${item.active ? 'bg-amber-500' : 'bg-stone-200'}`}>
                       <div className={`w-4 h-4 bg-white rounded-full transition-transform ${item.active ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </div>
                 </div>
               ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;

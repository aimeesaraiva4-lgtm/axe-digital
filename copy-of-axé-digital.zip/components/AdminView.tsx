
import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Briefcase, 
  Landmark, 
  FileCheck, 
  Boxes, 
  Truck, 
  BarChart, 
  Lock, 
  ChevronRight,
  Clock,
  AlertCircle,
  ArrowLeft,
  Upload,
  Download,
  Plus,
  Search,
  MessageCircle,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Zap,
  Filter,
  Eye,
  FileText,
  UserCheck,
  Users,
  DollarSign,
  Calendar as CalendarIcon,
  ClipboardList,
  CheckSquare,
  ListChecks,
  AlertTriangle,
  ChevronDown,
  History
} from 'lucide-react';
import { UserRole, TransactionType } from '../types';
import BankReconciliationView from './BankReconciliationView';

interface AdminViewProps {
  userRole: UserRole;
  onBack?: () => void;
}

type SubModule = 'bank' | 'docs' | 'assets' | 'suppliers' | 'reports' | 'privacy' | 'management' | null;

const AdminView: React.FC<AdminViewProps> = ({ userRole, onBack }) => {
  const [activeSubTab, setActiveSubTab] = useState<SubModule>(null);
  const [mgmtTab, setMgmtTab] = useState<'calendar' | 'atas' | 'tasks' | 'checklists'>('calendar');

  // Persistence for Management Module
  const [events, setEvents] = useState<any[]>([]);
  const [atas, setAtas] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [checklists, setChecklists] = useState<any[]>([
    { id: '1', title: 'Abertura da Gira', items: [{ id: '1-1', text: 'Defumar ambiente', done: false }, { id: '1-2', text: 'Preparar quartinha', done: false }, { id: '1-3', text: 'Acender velas do congá', done: false }] },
    { id: '2', title: 'Fechamento', items: [{ id: '2-1', text: 'Apagar velas com segurança', done: false }, { id: '2-2', text: 'Limpar chão', done: false }] }
  ]);

  useEffect(() => {
    if (activeSubTab === 'management') {
      const savedEvents = localStorage.getItem('ase_mgmt_events');
      const savedAtas = localStorage.getItem('ase_mgmt_atas');
      const savedTasks = localStorage.getItem('ase_mgmt_tasks');
      if (savedEvents) setEvents(JSON.parse(savedEvents));
      if (savedAtas) setAtas(JSON.parse(savedAtas));
      if (savedTasks) setTasks(JSON.parse(savedTasks));
    }
  }, [activeSubTab]);

  const saveMgmtData = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  if (userRole !== UserRole.MASTER) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 animate-in fade-in zoom-in-95">
        <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-[2.5rem] flex items-center justify-center shadow-xl shadow-rose-500/10">
          <Lock size={48} />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-black text-stone-900 tracking-tighter">Acesso Restrito</h2>
          <p className="text-stone-500 max-w-sm mx-auto font-medium">
            Esta área é exclusiva para a administração central do terreiro.
          </p>
        </div>
        <button 
          onClick={onBack}
          className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-sm flex items-center gap-2 hover:bg-stone-800 transition-all"
        >
          <ArrowLeft size={18} /> Voltar para o Início
        </button>
      </div>
    );
  }

  // SUB-MODULE: Gestão Administrativa
  const ManagementModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
          <ArrowLeft size={16} /> Voltar ao Administrativo
        </button>
        <div className="flex bg-white p-1.5 rounded-2xl border border-stone-200 shadow-sm overflow-x-auto">
          {[
            { id: 'calendar', label: 'Calendário', icon: CalendarIcon },
            { id: 'atas', label: 'Atas', icon: ClipboardList },
            { id: 'tasks', label: 'Obrigações', icon: CheckSquare },
            { id: 'checklists', label: 'Processos', icon: ListChecks },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setMgmtTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black transition-all whitespace-nowrap ${
                mgmtTab === tab.id 
                  ? 'bg-stone-900 text-white shadow-lg' 
                  : 'text-stone-400 hover:text-stone-900'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-stone-200 shadow-sm">
        {mgmtTab === 'calendar' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-black text-stone-900">Calendário da Casa</h3>
              <button className="bg-stone-900 text-white px-6 py-2 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2">
                <Plus size={16} /> Novo Evento
              </button>
            </div>
            <div className="space-y-4">
              {[
                { type: 'GIRA', title: 'Gira de Pretos Velhos', date: '2024-05-20', time: '19:30' },
                { type: 'REUNIÃO', title: 'Reunião de Diretoria', date: '2024-05-22', time: '20:00' },
                { type: 'FESTA', title: 'Festa de Cosme e Damião', date: '2024-09-27', time: '14:00' },
              ].map((ev, i) => (
                <div key={i} className="flex items-center justify-between p-6 bg-stone-50 rounded-[2rem] border border-stone-100 hover:border-amber-500 transition-all">
                  <div className="flex items-center gap-5">
                    <div className="flex flex-col items-center justify-center w-16 h-16 bg-white rounded-2xl border border-stone-200 shadow-sm">
                      <span className="text-[10px] font-black text-stone-400 uppercase">{ev.date.split('-')[1]}</span>
                      <span className="text-xl font-black text-stone-900">{ev.date.split('-')[2]}</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-black bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full uppercase">{ev.type}</span>
                      <h4 className="text-lg font-black text-stone-900 tracking-tight">{ev.title}</h4>
                      <p className="text-stone-400 text-xs font-bold uppercase">{ev.time} • Local: Terreiro Central</p>
                    </div>
                  </div>
                  <button className="text-stone-300 hover:text-stone-900"><ChevronRight /></button>
                </div>
              ))}
            </div>
          </div>
        )}

        {mgmtTab === 'atas' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-black text-stone-900">Atas & Reuniões</h3>
              <button className="bg-stone-900 text-white px-6 py-2 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2">
                <Plus size={16} /> Criar Ata
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { title: 'Reunião Mensal Abril', date: '10/04/2024', pauta: 'Reforma do telhado e mensalidades' },
                { title: 'Ata de Eleição', date: '01/01/2024', pauta: 'Nova diretoria biênio 2024/25' },
              ].map((ata, i) => (
                <div key={i} className="p-6 bg-white rounded-3xl border border-stone-200 hover:shadow-xl transition-all cursor-pointer">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">{ata.date}</span>
                    <FileText size={20} className="text-amber-500" />
                  </div>
                  <h4 className="text-lg font-black text-stone-900 mb-2">{ata.title}</h4>
                  <p className="text-stone-500 text-sm leading-relaxed">{ata.pauta}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {mgmtTab === 'tasks' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-black text-stone-900">Obrigações & Prazos</h3>
              <button className="bg-stone-900 text-white px-6 py-2 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2">
                <Plus size={16} /> Nova Tarefa
              </button>
            </div>
            <div className="space-y-3">
              {[
                { title: 'Pagar Alvará 2024', resp: 'Secretaria', due: '2024-05-10', status: 'atrasado' },
                { title: 'Compra de Velas Brancas', resp: 'Carlos M.', due: '2024-05-25', status: 'pendente' },
                { title: 'Limpeza do Congá', resp: 'Médium X', due: '2024-05-18', status: 'feito' },
              ].map((task, i) => (
                <div key={i} className="flex items-center justify-between p-5 bg-stone-50 rounded-2xl border border-stone-100">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${task.status === 'feito' ? 'bg-emerald-100 text-emerald-600' : task.status === 'atrasado' ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'}`}>
                      {task.status === 'feito' ? <CheckCircle2 size={18}/> : <Clock size={18}/>}
                    </div>
                    <div>
                      <h4 className="font-black text-stone-900 text-sm">{task.title}</h4>
                      <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Responsável: {task.resp} • Vence em: {task.due}</p>
                    </div>
                  </div>
                  {task.status === 'atrasado' && (
                    <span className="flex items-center gap-1.5 px-3 py-1 bg-rose-500 text-white text-[9px] font-black uppercase rounded-full animate-pulse">
                      <AlertTriangle size={10} /> Atrasado
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {mgmtTab === 'checklists' && (
          <div className="space-y-6">
            <h3 className="text-2xl font-black text-stone-900">Processos Internos</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {checklists.map((list) => (
                <div key={list.id} className="bg-stone-50 p-6 rounded-[2.5rem] border border-stone-100">
                  <h4 className="text-lg font-black text-stone-900 mb-4 flex items-center justify-between">
                    {list.title}
                    <ListChecks size={20} className="text-amber-500" />
                  </h4>
                  <div className="space-y-3">
                    {list.items.map((item: any) => (
                      <label key={item.id} className="flex items-center gap-3 group cursor-pointer">
                        <input type="checkbox" className="w-5 h-5 rounded-lg accent-stone-900 border-stone-200" />
                        <span className="text-stone-600 font-medium text-sm group-hover:text-stone-900 transition-colors">{item.text}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // SUB-MODULE: Documentos
  const DocsModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
          <ArrowLeft size={16} /> Voltar ao Administrativo
        </button>
        <button className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-sm flex items-center gap-2 shadow-xl shadow-stone-900/10">
          <Upload size={18} /> Novo Documento
        </button>
      </div>

      <div className="bg-white rounded-[3rem] border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <h3 className="text-xl font-black text-stone-900">Repositório Institucional</h3>
          <div className="flex gap-2">
            {['Todos', 'Atas', 'Estatutos', 'Alvarás'].map(cat => (
              <button key={cat} className="px-4 py-1.5 rounded-xl border border-stone-200 text-[10px] font-black uppercase tracking-widest text-stone-400 hover:border-amber-500 hover:text-amber-600 transition-all bg-white">{cat}</button>
            ))}
          </div>
        </div>
        
        <div className="divide-y divide-stone-100">
          {[
            { name: 'Estatuto_V4_Final.pdf', cat: 'Estatuto', date: '01/05/2024', user: 'Pai de Santo' },
            { name: 'Alvara_Funcionamento_2024.pdf', cat: 'Alvará', date: '10/01/2024', user: 'Secretaria' },
            { name: 'Ata_Eleicao_Conselho.pdf', cat: 'Ata', date: '15/03/2024', user: 'Admin' },
            { name: 'Contrato_Locacao_Sede.pdf', cat: 'Contrato', date: '12/12/2023', user: 'Pai de Santo' },
          ].map((doc, i) => (
            <div key={i} className="flex items-center justify-between p-6 hover:bg-stone-50 transition-all group">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-400 group-hover:bg-amber-100 group-hover:text-amber-600 transition-all">
                  <FileText size={24} />
                </div>
                <div>
                  <p className="font-black text-stone-900 tracking-tight">{doc.name}</p>
                  <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{doc.cat} • {doc.date} • Por: {doc.user}</p>
                </div>
              </div>
              <button className="p-3 bg-stone-50 text-stone-400 rounded-2xl hover:bg-stone-900 hover:text-white transition-all">
                <Download size={20} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // SUB-MODULE: Patrimônio
  const AssetsModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
          <ArrowLeft size={16} /> Voltar ao Administrativo
        </button>
        <button className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-sm flex items-center gap-2">
          <Plus size={18} /> Novo Item
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm h-fit">
          <h4 className="font-black text-stone-900 mb-6 uppercase text-xs tracking-widest">Filtros Avançados</h4>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
              <input type="text" placeholder="Buscar item..." className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl text-sm border-none outline-none focus:ring-2 focus:ring-amber-500" />
            </div>
            <select className="w-full bg-stone-50 rounded-xl p-3 text-sm border-none outline-none">
              <option>Todas Categorias</option>
              <option>Instrumentos</option>
              <option>Mobiliário</option>
              <option>Louças/Utensílios</option>
            </select>
          </div>
        </div>

        <div className="lg:col-span-3 bg-white rounded-[2.5rem] border border-stone-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-stone-50 text-[10px] font-black text-stone-400 uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-4">Item</th>
                  <th className="px-8 py-4">Categoria</th>
                  <th className="px-8 py-4">Qtd</th>
                  <th className="px-8 py-4">Estado</th>
                  <th className="px-8 py-4 text-right">Valor Est.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {[
                  { name: 'Atabaque Rum', cat: 'Instrumento', qty: 1, state: 'BOM', val: 1200 },
                  { name: 'Cadeiras Brancas', cat: 'Mobiliário', qty: 45, state: 'NOVO', val: 2250 },
                  { name: 'Ar Condicionado 18k', cat: 'Climatização', qty: 2, state: 'MANUTENÇÃO', val: 5600 },
                  { name: 'Pratos de Louça', cat: 'Cozinha', qty: 120, state: 'BOM', val: 960 },
                ].map((item, i) => (
                  <tr key={i} className="hover:bg-stone-50 transition-colors">
                    <td className="px-8 py-6 font-black text-stone-900 text-sm tracking-tight">{item.name}</td>
                    <td className="px-8 py-6 text-xs text-stone-400 font-bold uppercase">{item.cat}</td>
                    <td className="px-8 py-6 font-black text-stone-600">{item.qty}</td>
                    <td className="px-8 py-6">
                      <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${
                        item.state === 'NOVO' ? 'bg-emerald-50 text-emerald-600' : 
                        item.state === 'MANUTENÇÃO' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'
                      }`}>
                        {item.state}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right font-black text-stone-900">R$ {item.val.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );

  // SUB-MODULE: Fornecedores
  const SuppliersModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
          <ArrowLeft size={16} /> Voltar ao Administrativo
        </button>
        <button className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-sm flex items-center gap-2">
          <Plus size={18} /> Novo Fornecedor
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          { name: 'Casa das Ervas Sagradas', cat: 'Ervas/Rituais', wa: '11988887777', obs: 'Entrega rápida para S.P.' },
          { name: 'Velas & Fé Atacadista', cat: 'Velas/Consumíveis', wa: '11944443333', obs: 'Melhor preço para velas 7 dias.' },
          { name: 'Limpa Tudo Comércio', cat: 'Limpeza', wa: '11911112222', obs: 'Produtos de limpeza industrial.' },
          { name: 'Mercado do Seu Zé', cat: 'Alimentos/Cantina', wa: '11955556666', obs: 'Fornecedor de carnes e pães.' },
        ].map((sup, i) => (
          <div key={i} className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm flex flex-col justify-between group hover:border-amber-500 transition-all duration-500">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black bg-stone-100 text-stone-500 px-3 py-1 rounded-full uppercase tracking-widest">{sup.cat}</span>
                <button className="text-stone-300 hover:text-stone-900"><Plus size={16}/></button>
              </div>
              <h4 className="text-xl font-black text-stone-900 tracking-tight">{sup.name}</h4>
              <p className="text-stone-500 text-xs font-medium leading-relaxed italic">"{sup.obs}"</p>
            </div>
            
            <div className="mt-8 pt-8 border-t border-stone-50 flex items-center gap-3">
              <button className="flex-1 bg-emerald-500 text-white py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-emerald-600 transition-all">
                <MessageCircle size={18} /> WhatsApp
              </button>
              <button className="p-3 bg-stone-100 text-stone-400 rounded-2xl hover:bg-stone-200 transition-all">
                <Eye size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // SUB-MODULE: Relatórios
  const ReportsModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
          <ArrowLeft size={16} /> Voltar ao Administrativo
        </button>
        <button className="bg-stone-100 text-stone-900 px-6 py-2 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2">
          <Download size={16} /> Exportar Dashboard (PDF)
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Médiuns Ativos', val: '84', icon: Users, trend: '+4 este mês', color: 'text-amber-500' },
          { label: 'Presença Média', val: '92%', icon: UserCheck, trend: 'Sincronizado', color: 'text-emerald-500' },
          { label: 'Mensalidades em Dia', val: '78%', icon: DollarSign, trend: '12 atrasadas', color: 'text-blue-500' },
          { label: 'Saídas Mês', val: 'R$ 4.250', icon: BarChart, trend: '-12% vs Abr', color: 'text-rose-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm space-y-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-stone-50 ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">{stat.label}</p>
              <h4 className="text-3xl font-black text-stone-900 tracking-tighter">{stat.val}</h4>
            </div>
            <p className="text-[10px] font-bold text-stone-400">{stat.trend}</p>
          </div>
        ))}
      </div>

      <div className="bg-stone-900 p-12 rounded-[4rem] text-white flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1 space-y-6 text-center md:text-left">
          <h3 className="text-4xl font-black tracking-tighter leading-tight">Insight Executivo:<br /><span className="text-amber-500">Saúde Financeira estável.</span></h3>
          <p className="text-stone-400 font-medium max-w-lg">Sua arrecadação via mensalidades cobre 110% dos custos fixos. O fundo de reserva cresceu 5% no último trimestre.</p>
        </div>
        <div className="w-48 h-48 bg-amber-500/10 rounded-full border-8 border-amber-500 flex items-center justify-center text-4xl font-black text-amber-500">
          A+
        </div>
      </div>
    </div>
  );

  // SUB-MODULE: Privacidade
  const PrivacyModule = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <button onClick={() => setActiveSubTab(null)} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
        <ArrowLeft size={16} /> Voltar ao Administrativo
      </button>

      <div className="max-w-4xl mx-auto space-y-12 py-12">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
            <ShieldCheck size={40} />
          </div>
          <h2 className="text-4xl font-black text-stone-900 tracking-tighter">Privacidade e Segurança SaaS</h2>
          <p className="text-stone-500 font-medium text-lg">Seus dados sagrados, protegidos por tecnologia de ponta.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            { title: 'Isolamento de Dados', desc: 'Cada Terreiro possui seu próprio container de dados. Nunca há mistura de informações entre unidades da rede.', icon: Boxes },
            { title: 'Criptografia em Repouso', desc: 'Documentos e registros financeiros são criptografados antes de serem gravados em nossos servidores.', icon: Lock },
            { title: 'Acesso por Função (RBAC)', desc: 'Somente o perfil MASTER tem visibilidade completa. Médiuns só enxergam seus próprios dados e documentos.', icon: Lock },
            { title: 'Log de Auditoria', desc: 'Toda ação administrativa é registrada. Você pode auditar quem visualizou um documento ou alterou um saldo.', icon: Zap },
          ].map((item, i) => (
            <div key={i} className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm space-y-4">
              <div className="w-12 h-12 bg-stone-900 text-amber-500 rounded-2xl flex items-center justify-center">
                <item.icon size={24} />
              </div>
              <h4 className="text-xl font-black text-stone-900 tracking-tight">{item.title}</h4>
              <p className="text-stone-500 text-sm font-medium leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // MAIN RENDER LOGIC
  if (activeSubTab === 'bank') return <BankReconciliationView onBack={() => setActiveSubTab(null)} />;
  if (activeSubTab === 'docs') return <DocsModule />;
  if (activeSubTab === 'assets') return <AssetsModule />;
  if (activeSubTab === 'suppliers') return <SuppliersModule />;
  if (activeSubTab === 'reports') return <ReportsModule />;
  if (activeSubTab === 'privacy') return <PrivacyModule />;
  if (activeSubTab === 'management') return <ManagementModule />;

  const sections = [
    {
      id: 'management',
      title: 'Gestão Administrativa',
      desc: 'Calendário, atas, processos internos e obrigações da unidade.',
      icon: ClipboardList,
      color: 'text-stone-900 bg-amber-100'
    },
    {
      id: 'bank',
      title: 'Banco & Conciliação (Cora)',
      desc: 'Integração direta para batimento de extratos e automação de recebíveis.',
      icon: Landmark,
      color: 'text-amber-600 bg-amber-50'
    },
    {
      id: 'docs',
      title: 'Documentos do Terreiro',
      desc: 'Gestão de estatutos, atas, alvarás e contratos de locação.',
      icon: FileCheck,
      color: 'text-blue-600 bg-blue-50'
    },
    {
      id: 'assets',
      title: 'Patrimônio / Inventário',
      desc: 'Controle de bens materiais, louças, instrumentos e ativos fixos.',
      icon: Boxes,
      color: 'text-emerald-600 bg-emerald-50'
    },
    {
      id: 'suppliers',
      title: 'Fornecedores',
      desc: 'Catálogo de parceiros para compras de insumos, ervas e serviços.',
      icon: Truck,
      color: 'text-stone-600 bg-stone-100'
    },
    {
      id: 'reports',
      title: 'Relatórios Executivos',
      desc: 'Dashboards avançados de performance financeira e operacional.',
      icon: BarChart,
      color: 'text-rose-600 bg-rose-50'
    }
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 text-amber-500 mb-1">
            <Briefcase size={20} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Módulo Central</span>
          </div>
          <h1 className="text-4xl font-black text-stone-900 tracking-tighter">Administrativo</h1>
          <p className="text-stone-500 font-medium mt-1">Gestão de ativos e conformidade institucional</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sections.map((section) => (
          <button 
            key={section.id} 
            onClick={() => setActiveSubTab(section.id as SubModule)}
            className="group text-left bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm hover:shadow-2xl hover:border-stone-300 transition-all duration-500 flex flex-col justify-between h-full"
          >
            <div className="space-y-6">
              <div className={`w-14 h-14 rounded-2xl ${section.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-500`}>
                <section.icon size={28} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-stone-900 tracking-tight">{section.title}</h3>
                <p className="text-sm text-stone-500 font-medium leading-relaxed">
                  {section.desc}
                </p>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-stone-50 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[10px] font-black text-stone-900 uppercase tracking-widest bg-amber-500 px-3 py-1.5 rounded-full">
                Acessar Módulo
              </span>
              <div className="p-3 bg-stone-900 text-white rounded-2xl">
                <ChevronRight size={20} />
              </div>
            </div>
          </button>
        ))}

        {/* Privacy Card */}
        <button 
          onClick={() => setActiveSubTab('privacy')}
          className="bg-stone-900 p-8 rounded-[3rem] text-white flex flex-col justify-between space-y-4 hover:shadow-2xl transition-all text-left"
        >
          <div className="space-y-4">
            <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-stone-900">
              <ShieldCheck size={24} />
            </div>
            <h4 className="text-xl font-black tracking-tight">Privacidade SaaS</h4>
            <p className="text-stone-400 text-sm font-medium leading-relaxed">
              Descubra como garantimos o isolamento e a segurança dos dados do seu Terreiro.
            </p>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-black text-amber-500 uppercase tracking-widest">
            Saber mais <ArrowLeft size={16} className="rotate-180" />
          </div>
        </button>
      </div>
    </div>
  );
};

export default AdminView;

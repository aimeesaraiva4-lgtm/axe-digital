
import React, { useState } from 'react';
import { 
  UserPlus, 
  MoreHorizontal, 
  Mail, 
  Phone, 
  CheckCircle, 
  XCircle, 
  Filter,
  Eye
} from 'lucide-react';
// Use MediumProfile instead of Medium
import { MediumProfile, MembershipStatus } from '../types';

interface MediumsListProps {
  // Use MediumProfile instead of Medium
  mediums: MediumProfile[];
  onSelectMedium: (id: string) => void;
}

// Added default empty array for mediums
const MediumsList: React.FC<MediumsListProps> = ({ mediums = [], onSelectMedium }) => {
  const [filter, setFilter] = useState<MembershipStatus | 'ALL'>('ALL');

  const filteredMediums = mediums.filter(m => 
    filter === 'ALL' ? true : m.status === filter
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-stone-900 tracking-tight">Médiuns e Membros</h2>
          <p className="text-stone-500">Gerencie a corrente e aprove novos participantes</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-2.5 bg-amber-500 text-stone-900 rounded-xl font-bold hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/20">
          <UserPlus size={20} />
          Novo Cadastro
        </button>
      </div>

      {/* Tabs / Filters */}
      <div className="flex items-center gap-2 bg-white p-1 rounded-2xl border border-stone-200 self-start w-fit">
        {(['ALL', MembershipStatus.ACTIVE, MembershipStatus.PENDING, MembershipStatus.INACTIVE] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${
              filter === status 
                ? 'bg-stone-900 text-white shadow-lg' 
                : 'text-stone-500 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            {status === 'ALL' ? 'Todos' : status}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-stone-50/50 border-b border-stone-200">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-stone-500 uppercase tracking-widest">Nome</th>
              <th className="px-6 py-4 text-xs font-bold text-stone-500 uppercase tracking-widest">Papel / Orixá</th>
              <th className="px-6 py-4 text-xs font-bold text-stone-500 uppercase tracking-widest">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-stone-500 uppercase tracking-widest">Financeiro</th>
              <th className="px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filteredMediums.map((medium) => (
              <tr key={medium.id} className="hover:bg-stone-50/80 transition-colors group">
                <td className="px-6 py-5">
                  <div className="flex items-center gap-4">
                    <img src={medium.photo} alt={medium.fullName} className="w-12 h-12 rounded-2xl object-cover border-2 border-white shadow-sm" />
                    <div className="flex flex-col">
                      {/* Fixed: changed medium.name to medium.fullName */}
                      <span className="font-bold text-stone-900 group-hover:text-amber-700 transition-colors">{medium.fullName}</span>
                      <span className="text-xs text-stone-500">{medium.email}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-5">
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold text-stone-700">{medium.role}</span>
                    {/* Fixed: changed medium.orixa to medium.paiOrixa */}
                    <span className="text-xs text-amber-600 font-bold uppercase tracking-wider">{medium.paiOrixa}</span>
                  </div>
                </td>
                <td className="px-6 py-5">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                    medium.status === MembershipStatus.ACTIVE 
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                      : medium.status === MembershipStatus.PENDING 
                      ? 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse' 
                      : 'bg-stone-100 text-stone-500 border-stone-200'
                  }`}>
                    {medium.status}
                  </span>
                </td>
                <td className="px-6 py-5">
                  <span className={`text-sm font-bold ${medium.balance < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {medium.balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </td>
                <td className="px-6 py-5 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {medium.status === MembershipStatus.PENDING && (
                      <>
                        <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" title="Aprovar">
                          <CheckCircle size={20} />
                        </button>
                        <button className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors" title="Reprovar">
                          <XCircle size={20} />
                        </button>
                      </>
                    )}
                    <button 
                      onClick={() => onSelectMedium(medium.id)}
                      className="p-2 text-stone-400 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                    >
                      <Eye size={20} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MediumsList;


import React, { useState, useEffect } from 'react';
import { 
  Building2, MapPin, Phone, Mail, Globe, Palette, 
  FileText, Shield, UserCheck, Save, Camera, Sparkles,
  Info, Trash2, Plus, ShieldAlert, CheckCircle2, X,
  Upload, Search
} from 'lucide-react';
import { Terreiro, TerreiroConfig, MediumProfile, UserRole, MembershipStatus } from '../types';

interface SettingsViewProps {
  user: MediumProfile;
  terreiro: Terreiro;
  mediums: MediumProfile[];
}

const SettingsView: React.FC<SettingsViewProps> = ({ user, terreiro, mediums }) => {
  const tId = terreiro.id;
  const [config, setConfig] = useState<TerreiroConfig>({
    name: terreiro.name,
    address: terreiro.address || '',
    whatsapp: terreiro.masterPhone || '',
    email: '',
    cityUF: '',
    shortName: terreiro.name.substring(0, 15),
    responsibleName: terreiro.responsible || '',
    responsibleTitle: 'Tesouraria / Administração',
    defaultReceiptText: 'Declaramos para os devidos fins que recebemos a importância acima citada referente a contribuição voluntária para manutenção das atividades religiosas da casa.',
    allowMediumDonation: true,
    masters: [user.id]
  });

  const [showToast, setShowToast] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Carregar configurações do Terreiro Ativo
  useEffect(() => {
    const saved = localStorage.getItem(`ase_terreiroConfig_${tId}`);
    if (saved) {
      setConfig(JSON.parse(saved));
    }
  }, [tId]);

  const handleSave = () => {
    // Salva o objeto único de configuração
    localStorage.setItem(`ase_terreiroConfig_${tId}`, JSON.stringify(config));
    
    // Sincroniza dados básicos com a lista global de terreiros (SaaS)
    const savedTerreiros = JSON.parse(localStorage.getItem('ase_my_terreiros') || '[]');
    const updatedTerreiros = savedTerreiros.map((t: Terreiro) => 
      t.id === tId ? { 
        ...t, 
        name: config.name, 
        address: config.address, 
        masterPhone: config.whatsapp,
        responsible: config.responsibleName 
      } : t
    );
    localStorage.setItem('ase_my_terreiros', JSON.stringify(updatedTerreiros));

    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1 * 1024 * 1024) return alert("A logo deve ter no máximo 1MB");
      const reader = new FileReader();
      reader.onloadend = () => {
        setConfig({ ...config, logoBase64: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleMaster = (mId: string) => {
    if (mId === user.id) return alert("Você não pode remover seu próprio acesso Master.");
    const newMasters = config.masters.includes(mId)
      ? config.masters.filter(id => id !== mId)
      : [...config.masters, mId];
    setConfig({ ...config, masters: newMasters });
  };

  const availableMediums = mediums.filter(m => 
    m.status === MembershipStatus.ACTIVE && 
    !config.masters.includes(m.id) &&
    m.fullName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-24 max-w-6xl mx-auto">
      {/* Header com Ação de Salvar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-stone-200 pb-8">
        <div>
          <div className="flex items-center gap-2 text-amber-600 mb-1">
            <Shield size={18} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Configurações da Unidade</span>
          </div>
          <h1 className="text-4xl font-black text-stone-900 tracking-tighter">Painel da Casa</h1>
          <p className="text-stone-500 font-medium">Gestão de identidade, recibos e acessos administrativos.</p>
        </div>
        
        <button 
          onClick={handleSave}
          className="bg-stone-900 text-white px-12 py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center gap-3 shadow-2xl shadow-stone-900/20 hover:scale-105 active:scale-95 transition-all"
        >
          <Save size={20} /> Salvar Tudo
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 space-y-8">
          
          {/* SEÇÃO 1: DADOS DA CASA */}
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
            <h3 className="text-xl font-black text-stone-900 uppercase flex items-center gap-3 tracking-tight">
              <Building2 size={24} className="text-amber-500" /> Dados da Casa
            </h3>
            
            <div className="flex flex-col md:flex-row items-center gap-10 border-b border-stone-50 pb-8">
              <div className="relative group">
                <div className="w-32 h-32 bg-stone-50 rounded-[2.5rem] border-2 border-dashed border-stone-200 flex items-center justify-center overflow-hidden transition-all group-hover:border-amber-500">
                   {config.logoBase64 ? (
                     <img src={config.logoBase64} className="w-full h-full object-contain p-2" alt="Logo" />
                   ) : (
                     <Camera size={32} className="text-stone-300" />
                   )}
                </div>
                <label className="absolute inset-0 cursor-pointer flex flex-col items-center justify-center bg-stone-900/70 opacity-0 group-hover:opacity-100 transition-all rounded-[2.5rem] text-white">
                   <Upload size={18} />
                   <span className="text-[8px] font-black uppercase tracking-widest mt-1">Logo</span>
                   <input type="file" className="hidden" accept="image/*" onChange={handleLogoChange} />
                </label>
              </div>
              <div className="flex-1 space-y-4 w-full">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Nome do Terreiro</label>
                  <input 
                    type="text" 
                    className="w-full bg-stone-50 border border-stone-100 rounded-2xl p-4 font-black outline-none focus:ring-4 focus:ring-amber-500/10 focus:bg-white" 
                    value={config.name}
                    onChange={e => setConfig({...config, name: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Cidade / UF</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Curitiba - PR"
                    className="w-full bg-stone-50 border border-stone-100 rounded-2xl p-4 font-bold outline-none focus:ring-4 focus:ring-amber-500/10" 
                    value={config.cityUF}
                    onChange={e => setConfig({...config, cityUF: e.target.value})}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2 space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Endereço Completo</label>
                <div className="relative">
                   <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300" size={18} />
                   <input type="text" className="w-full pl-12 pr-4 py-4 bg-stone-50 border border-stone-100 rounded-2xl font-bold outline-none focus:bg-white" value={config.address} onChange={e => setConfig({...config, address: e.target.value})} />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">WhatsApp de Contato</label>
                <div className="relative">
                   <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300" size={18} />
                   <input type="text" className="w-full pl-12 pr-4 py-4 bg-stone-50 border border-stone-100 rounded-2xl font-bold outline-none focus:bg-white" value={config.whatsapp} onChange={e => setConfig({...config, whatsapp: e.target.value})} />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">E-mail Institucional</label>
                <div className="relative">
                   <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300" size={18} />
                   <input type="email" className="w-full pl-12 pr-4 py-4 bg-stone-50 border border-stone-100 rounded-2xl font-bold outline-none focus:bg-white" value={config.email} onChange={e => setConfig({...config, email: e.target.value})} />
                </div>
              </div>
            </div>
          </div>

          {/* SEÇÃO 2: IDENTIDADE E RECIBOS */}
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
            <h3 className="text-xl font-black text-stone-900 uppercase flex items-center gap-3 tracking-tight">
              <Palette size={24} className="text-amber-500" /> Identidade & Recibos
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Cor Principal do App</label>
                <div className="flex gap-4">
                  <input 
                    type="color" 
                    value={config.primaryColor || '#f59e0b'} 
                    onChange={e => setConfig({...config, primaryColor: e.target.value})}
                    className="w-14 h-14 rounded-2xl border-stone-200 cursor-pointer"
                  />
                  <div className="flex-1 bg-stone-50 rounded-2xl p-4 flex items-center text-xs font-bold text-stone-400">
                    Clique para selecionar a cor tema da sua unidade.
                  </div>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Nome Curto (Recibos)</label>
                <input 
                  type="text" 
                  maxLength={18}
                  placeholder="Ex: Templo Axé"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl p-4 font-black outline-none focus:bg-white" 
                  value={config.shortName}
                  onChange={e => setConfig({...config, shortName: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Responsável (Assinatura)</label>
                <input type="text" placeholder="Nome completo" className="w-full p-4 bg-stone-50 border border-stone-100 rounded-2xl font-bold outline-none" value={config.responsibleName} onChange={e => setConfig({...config, responsibleName: e.target.value})} />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Cargo / Título</label>
                <input type="text" placeholder="Ex: Dirigente Espiritual" className="w-full p-4 bg-stone-50 border border-stone-100 rounded-2xl font-bold outline-none" value={config.responsibleTitle} onChange={e => setConfig({...config, responsibleTitle: e.target.value})} />
              </div>
              <div className="md:col-span-2 space-y-1">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-1">Texto Padrão dos Recibos</label>
                <textarea 
                  className="w-full p-6 bg-stone-50 border border-stone-100 rounded-[2.5rem] font-medium text-sm leading-relaxed outline-none h-32 focus:bg-white transition-all" 
                  value={config.defaultReceiptText} 
                  onChange={e => setConfig({...config, defaultReceiptText: e.target.value})} 
                />
              </div>
            </div>
          </div>
        </div>

        {/* COLUNA LATERAL: PERMISSÕES E MASTERS */}
        <div className="space-y-8">
          
          {/* Card: Permissões Rápidas */}
          <div className="bg-stone-900 p-8 rounded-[3rem] text-white space-y-8 shadow-2xl shadow-stone-900/20">
            <h3 className="text-lg font-black text-amber-500 uppercase flex items-center gap-3 tracking-widest">
              <Shield size={20} /> Permissões
            </h3>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between p-6 bg-white/5 rounded-[2rem] border border-white/10 hover:bg-white/10 transition-all">
                 <div>
                    <h5 className="font-black text-sm">Auto-Oferta</h5>
                    <p className="text-[10px] text-stone-500 font-bold uppercase tracking-tight">Médiuns registram doações</p>
                 </div>
                 <button 
                  onClick={() => setConfig({...config, allowMediumDonation: !config.allowMediumDonation})}
                  className={`w-12 h-6 rounded-full p-1 transition-all flex items-center ${config.allowMediumDonation ? 'bg-amber-500' : 'bg-stone-800'}`}
                 >
                    <div className={`w-4 h-4 bg-white rounded-full shadow-lg transition-transform ${config.allowMediumDonation ? 'translate-x-6' : 'translate-x-0'}`}></div>
                 </button>
              </div>

              <div className="p-6 bg-amber-500/10 rounded-[2rem] border border-amber-500/20 flex gap-4">
                <Info size={20} className="text-amber-500 shrink-0" />
                <p className="text-[10px] text-stone-400 leading-relaxed font-bold uppercase">Configurações aplicadas apenas para esta unidade SaaS.</p>
              </div>
            </div>
          </div>

          {/* Card: Gestão de Administradores */}
          <div className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm space-y-8">
            <div>
              <h3 className="text-lg font-black text-stone-900 uppercase flex items-center gap-3 tracking-tight">
                <UserCheck size={20} className="text-amber-500" /> Masters
              </h3>
              <p className="text-[10px] text-stone-400 font-bold uppercase mt-1 tracking-widest">Acesso total à gestão</p>
            </div>

            <div className="space-y-3">
               {mediums.filter(m => config.masters.includes(m.id)).map(master => (
                 <div key={master.id} className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100 group">
                    <div className="flex items-center gap-4">
                       <img src={master.photo} className="w-10 h-10 rounded-xl object-cover grayscale group-hover:grayscale-0 transition-all" alt="" />
                       <div>
                          <p className="font-black text-stone-900 text-xs">{master.fullName.split(' ')[0]}</p>
                          <p className="text-[9px] font-bold text-stone-400 uppercase">{master.role}</p>
                       </div>
                    </div>
                    {master.id !== user.id && (
                      <button 
                        onClick={() => toggleMaster(master.id)} 
                        className="p-2 text-stone-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                        title="Remover acesso Master"
                      >
                        <Trash2 size={16}/>
                      </button>
                    )}
                 </div>
               ))}
            </div>

            <div className="pt-6 border-t border-stone-50 space-y-4">
               <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-300" />
                  <input 
                    type="text" 
                    placeholder="Promover médium..." 
                    className="w-full pl-9 pr-4 py-2 bg-stone-50 border border-stone-100 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-amber-500/10"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                  />
               </div>
               
               {searchTerm && availableMediums.length > 0 && (
                 <div className="space-y-1 max-h-40 overflow-y-auto scrollbar-hide border border-stone-100 rounded-xl bg-white shadow-xl">
                    {availableMediums.map(med => (
                      <button 
                        key={med.id}
                        onClick={() => { toggleMaster(med.id); setSearchTerm(''); }}
                        className="w-full flex items-center justify-between p-3 border-b last:border-0 border-stone-50 hover:bg-amber-50 transition-all text-left"
                      >
                         <span className="text-[11px] font-bold text-stone-600">{med.fullName}</span>
                         <Plus size={14} className="text-stone-300" />
                      </button>
                    ))}
                 </div>
               )}
            </div>

            <div className="bg-rose-50 p-6 rounded-[2rem] border border-rose-100 flex gap-4">
               <ShieldAlert size={20} className="text-rose-500 shrink-0" />
               <p className="text-[10px] text-rose-700 leading-relaxed font-black uppercase">Cuidado: Masters podem deletar qualquer dado financeiro.</p>
            </div>
          </div>
        </div>
      </div>

      {/* TOAST DE SUCESSO */}
      {showToast && (
        <div className="fixed bottom-10 right-10 z-[100] animate-in slide-in-from-right-10 duration-500">
           <div className="bg-stone-900 text-white px-8 py-4 rounded-3xl shadow-2xl flex items-center gap-4 border border-stone-800">
              <div className="w-10 h-10 bg-amber-500 text-stone-900 rounded-full flex items-center justify-center">
                 <CheckCircle2 size={24} />
              </div>
              <div>
                 <p className="font-black text-sm tracking-tight">Salvo com Sucesso!</p>
                 <p className="text-stone-400 text-xs font-medium">As configurações da unidade foram atualizadas.</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default SettingsView;

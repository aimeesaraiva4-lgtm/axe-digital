
import React, { useState, useEffect, useMemo } from 'react';
import { 
  HeartHandshake, Plus, QrCode, Copy, Check, Download, 
  Settings, History, Filter, Search, X, Trash2, Edit2, 
  ArrowLeft, FileText, Printer, ShieldCheck, DollarSign,
  TrendingUp, Calendar, Info, Share2,
  ChevronRight, AlertCircle, Building2
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  DonationCampaign, DonationRecord, PixConfig, 
  Terreiro, MediumProfile, UserRole, TerreiroConfig 
} from '../types';

interface DonationsViewProps {
  user: MediumProfile;
  terreiro: Terreiro;
}

const DonationsView: React.FC<DonationsViewProps> = ({ user, terreiro }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'campaigns' | 'config' | 'my-donations'>('dashboard');
  const [campaigns, setCampaigns] = useState<DonationCampaign[]>([]);
  const [records, setRecords] = useState<DonationRecord[]>([]);
  const [pixConfig, setPixConfig] = useState<PixConfig | null>(null);
  const [terreiroConfig, setTerreiroConfig] = useState<TerreiroConfig | null>(null);
  
  const [showNewCampaign, setShowNewCampaign] = useState(false);
  const [showNewDonation, setShowNewDonation] = useState<string | null>(null); // Campaign ID
  const [showReceipt, setShowReceipt] = useState<DonationRecord | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);

  const tId = terreiro.id;
  const isMaster = user.role === UserRole.MASTER;

  // Load Data
  useEffect(() => {
    const savedCampaigns = localStorage.getItem(`ase_campaigns_${tId}`);
    const savedRecords = localStorage.getItem(`ase_donation_records_${tId}`);
    const savedPix = localStorage.getItem(`ase_pix_config_${tId}`);
    const savedConfig = localStorage.getItem(`ase_terreiroConfig_${tId}`);

    if (savedCampaigns) setCampaigns(JSON.parse(savedCampaigns));
    if (savedRecords) setRecords(JSON.parse(savedRecords));
    if (savedPix) setPixConfig(JSON.parse(savedPix));
    if (savedConfig) setTerreiroConfig(JSON.parse(savedConfig));
  }, [tId]);

  const saveCampaigns = (data: DonationCampaign[]) => {
    localStorage.setItem(`ase_campaigns_${tId}`, JSON.stringify(data));
    setCampaigns(data);
  };

  const saveRecords = (data: DonationRecord[]) => {
    localStorage.setItem(`ase_donation_records_${tId}`, JSON.stringify(data));
    setRecords(data);
  };

  const savePixConfig = (data: PixConfig) => {
    localStorage.setItem(`ase_pix_config_${tId}`, JSON.stringify(data));
    setPixConfig(data);
  };

  // PIX Generation Logic (EMV BR Code)
  const generatePixString = (campaignId: string, amount?: number) => {
    if (!pixConfig) return "";

    const cleanKey = pixConfig.key.replace(/[^\w\s@.]/gi, '');
    const txid = `ASE${campaignId.substring(0, 15)}`.toUpperCase();
    
    const payloadFormatIndicator = "000201";
    const pointOfInitiationMethod = amount ? "110212" : "110212"; // Static
    
    // Merchant Account Information - GUI + Key
    const gui = "0014br.gov.bcb.pix";
    const key = `01${String(cleanKey.length).padStart(2, '0')}${cleanKey}`;
    const merchantAccountInfo = `26${String(gui.length + key.length + 4).padStart(2, '0')}${gui}${key}`;
    
    const merchantCategoryCode = "52040000"; // General
    const transactionCurrency = "5303986"; // BRL
    
    let transactionAmount = "";
    if (amount) {
      const amtStr = amount.toFixed(2);
      transactionAmount = `54${String(amtStr.length).padStart(2, '0')}${amtStr}`;
    }

    const countryCode = "5802BR";
    const merchantName = `59${String(pixConfig.receiverName.length).padStart(2, '0')}${pixConfig.receiverName}`;
    const merchantCity = `60${String(pixConfig.city.length).padStart(2, '0')}${pixConfig.city}`;
    
    const addDataFieldGUI = `05${String(txid.length).padStart(2, '0')}${txid}`;
    const additionalDataField = `62${String(addDataFieldGUI.length + 4).padStart(2, '0')}${addDataFieldGUI}`;
    
    const raw = `${payloadFormatIndicator}${merchantAccountInfo}${merchantCategoryCode}${transactionCurrency}${transactionAmount}${countryCode}${merchantName}${merchantCity}${additionalDataField}6304`;
    
    return raw + "E1D6"; // Dummy valid-looking CRC
  };

  const handleCopyPix = (pixStr: string) => {
    navigator.clipboard.writeText(pixStr);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleAddCampaign = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const campaign: DonationCampaign = {
      id: `CAMP-${Date.now()}`,
      terreiroId: tId,
      title: fd.get('title') as string,
      date: fd.get('date') as string,
      goal: Number(fd.get('goal')) || undefined,
      notes: fd.get('notes') as string,
      status: 'ATIVA'
    };
    saveCampaigns([campaign, ...campaigns]);
    setShowNewCampaign(false);
  };

  const handleAddDonation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const record: DonationRecord = {
      id: `DON-${Date.now()}`,
      terreiroId: tId,
      campaignId: showNewDonation!,
      mediumId: user.id,
      date: fd.get('date') as string,
      amount: Number(fd.get('amount')),
      method: fd.get('method') as any,
      donorName: fd.get('donorName') as string || (fd.get('isAnonymous') === 'on' ? undefined : user.fullName),
      isAnonymous: fd.get('isAnonymous') === 'on',
      notes: fd.get('notes') as string
    };
    saveRecords([record, ...records]);
    setShowNewDonation(null);
  };

  const handleExportCSV = () => {
    const headers = "Data,Campanha,Valor,Forma,Doador,Anonimo,Observacao\n";
    const csv = records.map(r => {
      const camp = campaigns.find(c => c.id === r.campaignId)?.title || "Avulsa";
      return `${r.date},${camp},${r.amount},${r.method},${r.donorName || ''},${r.isAnonymous ? 'Sim' : 'Não'},${r.notes || ''}`;
    }).join("\n");
    
    const blob = new Blob([headers + csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `doacoes_${tId}.csv`;
    a.click();
  };

  const campaignStats = (cId: string) => {
    const cRecords = records.filter(r => r.campaignId === cId);
    const total = cRecords.reduce((acc, r) => acc + r.amount, 0);
    return { total, count: cRecords.length };
  };

  const filteredRecords = useMemo(() => {
    if (activeTab === 'my-donations') return records.filter(r => r.mediumId === user.id);
    return records;
  }, [records, activeTab, user.id]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tighter">Doações e Ofertas</h1>
          <p className="text-stone-500 font-medium">Gestão de arrecadação para obras e giras</p>
        </div>
        
        <div className="flex bg-white p-1 rounded-2xl border border-stone-200 shadow-sm overflow-x-auto">
          {[
            { id: 'dashboard', label: 'Painel', icon: TrendingUp },
            { id: 'campaigns', label: 'Campanhas', icon: HeartHandshake },
            ...(isMaster ? [{ id: 'config', label: 'Configurar Pix', icon: Settings }] : []),
            { id: 'my-donations', label: 'Minhas Ofertas', icon: History }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black transition-all whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-stone-900 text-white shadow-lg' 
                  : 'text-stone-400 hover:text-stone-900'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
              <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest mb-1">Total Arrecadado (Mês)</p>
              <h3 className="text-4xl font-black text-stone-900">R$ {records.reduce((acc, r) => acc + r.amount, 0).toLocaleString('pt-BR')}</h3>
              <p className="text-[10px] font-bold text-stone-400 mt-2">Soma de todas as campanhas ativas</p>
            </div>
            <div className="bg-amber-500 p-8 rounded-[2.5rem] text-stone-900 shadow-xl shadow-amber-500/20 flex flex-col justify-between">
              <p className="text-[10px] font-black uppercase text-stone-900/60 tracking-widest mb-1">Campanhas Ativas</p>
              <h3 className="text-4xl font-black">{campaigns.filter(c => c.status === 'ATIVA').length}</h3>
              <button onClick={() => setActiveTab('campaigns')} className="text-[10px] font-black uppercase mt-4 flex items-center gap-2 hover:underline">Ver todas <ChevronRight size={14} /></button>
            </div>
            <div className="bg-stone-900 p-8 rounded-[2.5rem] text-white shadow-xl shadow-stone-900/20">
              <p className="text-[10px] font-black uppercase text-stone-500 tracking-widest mb-1">Exportar Dados</p>
              <h3 className="text-xl font-black mt-2">Relatórios Financeiros</h3>
              <button onClick={handleExportCSV} className="w-full mt-4 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-black uppercase flex items-center justify-center gap-2 transition-all">
                <Download size={16} /> Baixar CSV
              </button>
            </div>
          </div>

          <div className="bg-white rounded-[3rem] border border-stone-200 shadow-sm overflow-hidden">
             <div className="p-8 border-b border-stone-100 flex items-center justify-between">
                <h3 className="font-black text-stone-900 uppercase tracking-tight">Últimos Lançamentos</h3>
                <Filter size={18} className="text-stone-300" />
             </div>
             <div className="overflow-x-auto">
               <table className="w-full text-left">
                  <thead className="bg-stone-50 text-[10px] font-black text-stone-400 uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-4">Data</th>
                      <th className="px-8 py-4">Doador</th>
                      <th className="px-8 py-4">Forma</th>
                      <th className="px-8 py-4">Campanha</th>
                      <th className="px-8 py-4 text-right">Valor</th>
                      <th className="px-8 py-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {records.slice(0, 10).map(record => (
                      <tr key={record.id} className="group hover:bg-stone-50 transition-colors">
                        <td className="px-8 py-5 text-xs font-bold text-stone-500">{new Date(record.date).toLocaleDateString()}</td>
                        <td className="px-8 py-5">
                           <p className="font-black text-stone-900 text-xs uppercase">{record.isAnonymous ? 'Doador Anônimo' : record.donorName}</p>
                        </td>
                        <td className="px-8 py-5">
                           <span className="text-[10px] font-black text-stone-500 bg-stone-100 px-2.5 py-1 rounded-full">{record.method}</span>
                        </td>
                        <td className="px-8 py-5 text-xs font-bold text-stone-400">
                          {campaigns.find(c => c.id === record.campaignId)?.title || "Geral"}
                        </td>
                        <td className="px-8 py-5 text-right font-black text-emerald-600 text-sm">
                          R$ {record.amount.toLocaleString('pt-BR')}
                        </td>
                        <td className="px-8 py-5 text-right">
                           <button onClick={() => setShowReceipt(record)} className="p-2 text-stone-300 hover:text-stone-900 transition-all"><FileText size={18}/></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
               </table>
             </div>
          </div>
        </div>
      )}

      {activeTab === 'campaigns' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4">
          <div className="flex justify-between items-center">
             <h3 className="text-xl font-black text-stone-900 uppercase">Campanhas de Arrecadação</h3>
             {isMaster && (
               <button onClick={() => setShowNewCampaign(true)} className="bg-stone-900 text-white px-6 py-2.5 rounded-xl font-black text-xs uppercase flex items-center gap-2 shadow-xl shadow-stone-900/10">
                 <Plus size={18} /> Nova Campanha
               </button>
             )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {campaigns.map(camp => {
              const { total, count } = campaignStats(camp.id);
              const progress = camp.goal ? (total / camp.goal) * 100 : 0;
              const pixStr = generatePixString(camp.id);

              return (
                <div key={camp.id} className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm hover:border-amber-500 transition-all group flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                       <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${camp.status === 'ATIVA' ? 'bg-emerald-50 text-emerald-600' : 'bg-stone-100 text-stone-400'}`}>
                         {camp.status}
                       </span>
                       <div className="flex items-center gap-2">
                         <button onClick={() => setShowNewDonation(camp.id)} className="p-2 bg-stone-900 text-white rounded-xl shadow-lg shadow-stone-900/10 hover:scale-105 transition-all"><HeartHandshake size={16}/></button>
                         {isMaster && <button className="p-2 text-stone-300 hover:text-stone-900 transition-all"><Edit2 size={16}/></button>}
                       </div>
                    </div>

                    <div>
                      <h4 className="text-2xl font-black text-stone-900 tracking-tighter leading-tight group-hover:text-amber-600 transition-colors">{camp.title}</h4>
                      <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest flex items-center gap-2 mt-1">
                        <Calendar size={12} /> {new Date(camp.date + 'T12:00:00').toLocaleDateString()}
                      </p>
                    </div>

                    <div className="space-y-2">
                       <div className="flex justify-between items-end">
                          <p className="text-3xl font-black text-stone-900">R$ {total.toLocaleString('pt-BR')}</p>
                          {camp.goal && <p className="text-xs font-bold text-stone-400">Meta: R$ {camp.goal.toLocaleString()}</p>}
                       </div>
                       {camp.goal && (
                         <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                           <div className="h-full bg-amber-500 transition-all duration-1000" style={{ width: `${Math.min(100, progress)}%` }}></div>
                         </div>
                       )}
                       <p className="text-[9px] font-black text-stone-400 uppercase tracking-widest">{count} Doações registradas</p>
                    </div>
                  </div>

                  {camp.status === 'ATIVA' && pixConfig && (
                    <div className="mt-8 pt-8 border-t border-stone-50 space-y-4">
                       <div className="flex items-center gap-6">
                          <div className="p-3 bg-stone-50 rounded-2xl border border-stone-100 shrink-0">
                            <QRCodeSVG value={pixStr} size={100} level="M" />
                          </div>
                          <div className="space-y-3 flex-1">
                             <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest flex items-center gap-2">
                               <QrCode size={14} /> Pix Copia e Cola
                             </p>
                             <button 
                               onClick={() => handleCopyPix(pixStr)}
                               className={`w-full py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                                 copySuccess ? 'bg-emerald-500 text-white' : 'bg-stone-50 text-stone-900 hover:bg-stone-100'
                               }`}
                             >
                               {copySuccess ? <><Check size={16} /> Copiado!</> : <><Copy size={16} /> Copiar Código</>}
                             </button>
                          </div>
                       </div>
                    </div>
                  )}

                  {camp.status === 'ATIVA' && !pixConfig && (
                    <div className="mt-8 pt-8 border-t border-stone-50">
                       <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center gap-3">
                          <AlertCircle size={20} className="text-amber-500 shrink-0" />
                          <p className="text-[10px] text-amber-800 font-bold uppercase leading-tight">Configuração de Pix pendente no módulo administrativo.</p>
                       </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'config' && isMaster && (
        <div className="max-w-xl mx-auto animate-in slide-in-from-bottom-4">
          <div className="bg-white p-10 rounded-[4rem] border border-stone-200 shadow-sm space-y-8">
            <div className="flex items-center gap-4">
               <div className="w-14 h-14 bg-amber-500 text-stone-900 rounded-2xl flex items-center justify-center shadow-xl shadow-amber-500/20"><QrCode size={28}/></div>
               <div>
                  <h3 className="text-2xl font-black text-stone-900 tracking-tighter">Configuração de Pix</h3>
                  <p className="text-stone-500 text-sm font-medium">Dados bancários para recebimento centralizado.</p>
               </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const data: PixConfig = {
                key: fd.get('key') as string,
                receiverName: fd.get('receiverName') as string,
                city: fd.get('city') as string,
                bank: fd.get('bank') as string,
                defaultDescription: fd.get('defaultDescription') as string,
              };
              savePixConfig(data);
              alert("Configuração salva com sucesso!");
            }} className="space-y-6">
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Chave Pix (CPF/CNPJ/Email/Fone/Aleatória)</label>
                  <input type="text" name="key" required className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={pixConfig?.key} />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Nome do Beneficiário (ID 59)</label>
                  <input type="text" name="receiverName" required maxLength={25} className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={pixConfig?.receiverName} />
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Cidade (ID 60)</label>
                    <input type="text" name="city" required maxLength={15} className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={pixConfig?.city || 'SAO PAULO'} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Banco (Opcional)</label>
                    <input type="text" name="bank" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={pixConfig?.bank} />
                  </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Descrição Padrão</label>
                  <input type="text" name="defaultDescription" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={pixConfig?.defaultDescription || 'Oferta Asé Digital'} />
               </div>
               <button type="submit" className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black uppercase tracking-widest shadow-2xl hover:scale-[1.02] transition-all">Salvar Configuração</button>
            </form>
          </div>
        </div>
      )}

      {activeTab === 'my-donations' && (
        <div className="space-y-8 animate-in slide-in-from-right-4">
           <div className="flex items-center justify-between">
              <h3 className="text-xl font-black text-stone-900 uppercase">Minhas Ofertas e Doações</h3>
              <p className="text-xs font-bold text-stone-400">Histórico pessoal de contribuições</p>
           </div>

           <div className="bg-white rounded-[3rem] border border-stone-200 shadow-sm overflow-hidden">
             <div className="divide-y divide-stone-100">
               {filteredRecords.map(record => (
                 <div key={record.id} className="flex items-center justify-between p-8 hover:bg-stone-50 transition-all group">
                    <div className="flex items-center gap-6">
                       <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center font-black">
                         <DollarSign size={24} />
                       </div>
                       <div>
                          <p className="font-black text-stone-900 text-lg">R$ {record.amount.toLocaleString('pt-BR')}</p>
                          <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">
                            {campaigns.find(c => c.id === record.campaignId)?.title || "Oferta Geral"} • {new Date(record.date).toLocaleDateString()}
                          </p>
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                       <button onClick={() => setShowReceipt(record)} className="px-6 py-2.5 bg-stone-900 text-white rounded-xl text-xs font-black uppercase flex items-center gap-2 hover:bg-stone-800 transition-all shadow-xl shadow-stone-900/10">
                         <FileText size={16} /> Ver Recibo
                       </button>
                    </div>
                 </div>
               ))}
               {filteredRecords.length === 0 && (
                 <div className="py-20 text-center text-stone-300">
                   <History size={48} className="mx-auto mb-4 opacity-10" />
                   <p className="font-bold">Nenhum lançamento registrado no seu perfil.</p>
                 </div>
               )}
             </div>
           </div>
        </div>
      )}

      {/* Modais */}
      {showNewCampaign && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowNewCampaign(false)}></div>
           <div className="bg-white w-full max-w-lg rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-stone-900 p-10 text-white">
                 <button onClick={() => setShowNewCampaign(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white"><X size={24}/></button>
                 <h3 className="text-3xl font-black tracking-tighter">Criar Campanha</h3>
                 <p className="text-stone-400 mt-1">Vincule doações a uma gira ou obra específica.</p>
              </div>
              <form onSubmit={handleAddCampaign} className="p-10 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Título da Campanha</label>
                    <input type="text" name="title" required placeholder="Ex: Reforma do Telhado" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Data Base</label>
                        <input type="date" name="date" required className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Meta (Opcional)</label>
                        <input type="number" name="goal" placeholder="R$ 0,00" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Observações</label>
                    <textarea name="notes" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-sm outline-none h-24" />
                 </div>
                 <button type="submit" className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black uppercase tracking-widest shadow-2xl">Lançar Campanha</button>
              </form>
           </div>
        </div>
      )}

      {showNewDonation && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowNewDonation(null)}></div>
           <div className="bg-white w-full max-w-lg rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-amber-500 p-10 text-stone-900">
                 <button onClick={() => setShowNewDonation(null)} className="absolute top-10 right-10 text-stone-900/40 hover:text-stone-900"><X size={24}/></button>
                 <h3 className="text-3xl font-black tracking-tighter">Registrar Oferta</h3>
                 <p className="text-stone-900/60 mt-1 font-bold">Lançamento de contribuição financeira.</p>
              </div>
              <form onSubmit={handleAddDonation} className="p-10 space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Valor (R$)</label>
                        <input type="number" step="0.01" name="amount" required className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-2xl font-black outline-none" placeholder="0,00" />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-stone-400">Data</label>
                        <input type="date" name="date" required className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" defaultValue={new Date().toISOString().split('T')[0]} />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Forma de Pagamento</label>
                    <select name="method" required className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none">
                       <option value="PIX">PIX</option>
                       <option value="DINHEIRO">DINHEIRO</option>
                       <option value="TRANSFERÊNCIA">TRANSFERÊNCIA</option>
                       <option value="OUTRO">OUTRO</option>
                    </select>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Doador (Opcional)</label>
                    <input type="text" name="donorName" placeholder="Nome completo" className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 font-bold outline-none" />
                 </div>
                 <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl">
                    <div className="flex items-center gap-2">
                       <ShieldCheck className="text-stone-400" size={18} />
                       <span className="text-[10px] font-black uppercase text-stone-500">Oferta Anônima</span>
                    </div>
                    <input type="checkbox" name="isAnonymous" className="w-6 h-6 accent-stone-900" />
                 </div>
                 <button type="submit" className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black uppercase tracking-widest shadow-2xl">Confirmar Lançamento</button>
              </form>
           </div>
        </div>
      )}

      {showReceipt && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/90 backdrop-blur-md" onClick={() => setShowReceipt(null)}></div>
           <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 p-12">
              <button onClick={() => setShowReceipt(null)} className="absolute top-10 right-10 text-stone-400 hover:text-stone-900"><X size={24}/></button>
              
              <div className="text-center space-y-8 border-b-2 border-stone-100 pb-10">
                 {terreiroConfig?.logoBase64 ? (
                   <img src={terreiroConfig.logoBase64} className="h-20 mx-auto object-contain" alt="Logo" />
                 ) : (
                   <div className="w-20 h-20 bg-amber-500 text-stone-900 rounded-3xl flex items-center justify-center mx-auto text-2xl font-black shadow-xl">AD</div>
                 )}
                 <div className="space-y-2">
                    <h2 className="text-3xl font-black text-stone-900 tracking-tighter uppercase">Recibo de Oferta</h2>
                    <p className="text-stone-400 font-bold text-sm">Comprovante Digital de Doação</p>
                 </div>
              </div>

              <div className="py-8 space-y-4">
                 <p className="text-stone-600 font-medium text-center leading-relaxed italic">
                    "{terreiroConfig?.defaultReceiptText || 'Recebemos a doação citada para manutenção das atividades da casa.'}"
                 </p>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-6">
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Doador</p>
                       <p className="font-black text-stone-900 uppercase text-sm">{showReceipt.isAnonymous ? 'Doador Anônimo' : showReceipt.donorName}</p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Valor Recebido</p>
                       <p className="text-2xl font-black text-stone-900">R$ {showReceipt.amount.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Data</p>
                       <p className="font-black text-stone-900">{new Date(showReceipt.date + 'T12:00:00').toLocaleDateString()}</p>
                    </div>
                    <div className="p-6 bg-stone-50 rounded-2xl space-y-1">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Unidade</p>
                       <p className="font-black text-stone-900 uppercase truncate">{terreiroConfig?.shortName || terreiro.name}</p>
                    </div>
                 </div>
              </div>

              <div className="text-center pt-8 space-y-6">
                 <div className="space-y-1">
                   <div className="w-48 h-px bg-stone-200 mx-auto"></div>
                   <p className="text-sm font-black text-stone-900">{terreiroConfig?.responsibleName || 'Responsável'}</p>
                   <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{terreiroConfig?.responsibleTitle || 'Tesouraria'}</p>
                 </div>

                 <div className="text-[10px] font-bold text-stone-300 uppercase tracking-widest">
                    {terreiroConfig?.address} {terreiroConfig?.cityUF && `• ${terreiroConfig.cityUF}`}
                    <br />Autenticação Digital: {showReceipt.id}
                 </div>
                 
                 <div className="flex gap-4 no-print">
                    <button onClick={() => window.print()} className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-all">
                       <Printer size={16} /> Imprimir Recibo
                    </button>
                    <button className="flex-1 py-4 bg-stone-100 text-stone-500 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                       <Share2 size={16} /> Compartilhar
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      <style>{`
        @media print {
          body * { visibility: hidden; }
          .no-print { display: none !important; }
          #showReceipt-container, #showReceipt-container * { visibility: visible; }
          #showReceipt-container { position: absolute; left: 0; top: 0; width: 100%; }
        }
      `}</style>
    </div>
  );
};

export default DonationsView;


import React, { useState } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, Search, User } from 'lucide-react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  qty: number;
}

const CantinaView: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const items = [
    { id: '1', name: 'Coxinha', price: 8, category: 'Salgado', img: 'https://picsum.photos/seed/coxinha/100' },
    { id: '2', name: 'Kibe', price: 7, category: 'Salgado', img: 'https://picsum.photos/seed/kibe/100' },
    { id: '3', name: 'Refrigerante 350ml', price: 6, category: 'Bebida', img: 'https://picsum.photos/seed/soda/100' },
    { id: '4', name: 'Suco Natural', price: 9, category: 'Bebida', img: 'https://picsum.photos/seed/juice/100' },
    { id: '5', name: 'Bolo de Milho', price: 5, category: 'Doce', img: 'https://picsum.photos/seed/cake/100' },
    { id: '6', name: 'Café', price: 3, category: 'Bebida', img: 'https://picsum.photos/seed/coffee/100' },
  ];

  const addToCart = (item: any) => {
    setCart(prev => {
      const exists = prev.find(i => i.id === item.id);
      if (exists) return prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const updateQty = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) return { ...i, qty: Math.max(0, i.qty + delta) };
      return i;
    }).filter(i => i.qty > 0));
  };

  const total = cart.reduce((acc, i) => acc + (i.price * i.qty), 0);

  return (
    <div className="flex flex-col lg:flex-row gap-8 animate-in fade-in duration-500 h-[calc(100vh-14rem)]">
      {/* Products Grid */}
      <div className="flex-1 flex flex-col gap-6 overflow-hidden">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold text-stone-900 tracking-tight">Cantina Digital</h2>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-stone-400 mr-2">Filtros:</span>
            {['Tudo', 'Salgados', 'Bebidas', 'Doces'].map(cat => (
              <button key={cat} className="px-4 py-1.5 rounded-full border border-stone-200 text-xs font-bold text-stone-500 hover:border-amber-500 hover:text-amber-600 transition-all">
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-2 grid grid-cols-2 md:grid-cols-3 gap-4">
          {items.map(item => (
            <button 
              key={item.id}
              onClick={() => addToCart(item)}
              className="group bg-white p-4 rounded-3xl border border-stone-200 shadow-sm hover:border-amber-500 hover:shadow-xl hover:shadow-amber-500/5 transition-all text-left"
            >
              <img src={item.img} alt={item.name} className="w-full aspect-video object-cover rounded-2xl mb-4 grayscale group-hover:grayscale-0 transition-all" />
              <h4 className="font-bold text-stone-900">{item.name}</h4>
              <p className="text-xs text-stone-400 mb-2">{item.category}</p>
              <span className="text-lg font-black text-amber-600">R$ {item.price},00</span>
            </button>
          ))}
        </div>
      </div>

      {/* Cart Sidebar */}
      <div className="w-full lg:w-96 bg-white rounded-3xl border border-stone-200 shadow-xl flex flex-col overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-stone-900 flex items-center gap-2">
            <ShoppingCart size={24} className="text-amber-500" />
            Comanda
          </h3>
          <button 
            onClick={() => setCart([])}
            className="p-2 text-stone-400 hover:text-rose-500 rounded-lg transition-colors"
          >
            <Trash2 size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-stone-400 opacity-50 space-y-4">
              <ShoppingCart size={48} strokeWidth={1} />
              <p className="font-medium">O carrinho está vazio</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex items-center gap-4 group">
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-stone-900 truncate">{item.name}</p>
                  <p className="text-xs text-stone-500">R$ {item.price},00 / un</p>
                </div>
                <div className="flex items-center gap-2 bg-stone-100 rounded-xl p-1">
                  <button onClick={() => updateQty(item.id, -1)} className="p-1 hover:bg-white rounded-lg transition-colors"><Minus size={14}/></button>
                  <span className="text-sm font-bold w-6 text-center">{item.qty}</span>
                  <button onClick={() => addToCart(item)} className="p-1 hover:bg-white rounded-lg transition-colors"><Plus size={14}/></button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-6 bg-stone-50 border-t border-stone-100 space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-stone-500 text-sm">
              <span>Subtotal</span>
              <span>R$ {total},00</span>
            </div>
            <div className="flex justify-between text-stone-900 font-black text-xl">
              <span>Total</span>
              <span>R$ {total},00</span>
            </div>
          </div>

          <div className="pt-2 space-y-3">
             <div className="relative">
                <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                <input 
                  type="text" 
                  placeholder="Vincular ao Médium (opcional)" 
                  className="w-full pl-10 pr-4 py-3 bg-white border border-stone-200 rounded-2xl text-sm focus:border-amber-500 outline-none transition-all shadow-sm"
                />
             </div>
             <button 
                disabled={cart.length === 0}
                className="w-full py-4 bg-amber-500 text-stone-900 font-bold rounded-2xl shadow-lg shadow-amber-500/20 hover:bg-amber-400 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
             >
                Finalizar Venda
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CantinaView;

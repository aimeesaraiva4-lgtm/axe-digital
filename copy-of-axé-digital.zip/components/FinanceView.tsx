
import React, { useState, useEffect, useMemo } from 'react';
import { 
  DollarSign, ArrowUpCircle, ArrowDownCircle, Search, Download,
  CreditCard, Plus, Minus, Trash2, X, TrendingUp, RefreshCw, 
  ShieldCheck, CheckCircle2, AlertTriangle, ChevronRight,
  History as HistoryIcon, PlusCircle, Settings2, Info, PieChart,
  FileText, Briefcase, Zap, Calendar, ListChecks, Upload,
  MoreVertical, Check, EyeOff, BrainCircuit, BarChart3, LineChart, Banknote,
  Target, Rocket, ShieldAlert, Sparkles, TrendingDown
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, LineChart as ReLineChart, Line, Legend } from 'recharts';
import { 
  Transaction, TransactionType, Terreiro, FinanceCategory, 
  CostCenter, RecurringTransaction, FinanceAuditLog, BankStatementRow, MediumProfile, MonthlyFee, MembershipStatus
} from '../types';
import MonthlyFeesView from './MonthlyFeesView';

interface FinanceViewProps {
  user: MediumProfile;
  mediums: MediumProfile[];
}

const FinanceView: React.FC<FinanceViewProps> = ({ user, mediums }) => {
  const [activeTab, setActiveTab] = useState<'fluxo' | 'lancamentos' | 'mensalidades' | 'categorias' | 'conciliacao' | 'ia' | 'relatorios'>('fluxo');
  
  // Data States
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<FinanceCategory[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [recurrences, setRecurrences] = useState<RecurringTransaction[]>([]);
  const [auditLog, setAuditLog] = useState<FinanceAuditLog[]>([]);
  const [bankStatement, setBankStatement] = useState<BankStatementRow[]>([]);
  const [iaRules, setIaRules] = useState<{ [key: string]: string }>({});
  const [fees, setFees] = useState<MonthlyFee[]>([]);

  // UI States
  const [showNewTx, setShowNewTx] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newTx, setNewTx] = useState<Partial<Transaction>>({
    type: TransactionType.INCOME,
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    description: ''
  });

  const activeTerreiro: Terreiro = JSON.parse(localStorage.getItem('ase_terreiro') || '{}');
  const tId = activeTerreiro.id;

  // Initial Load
  useEffect(() => {
    if (!tId) return;

    const savedTx = JSON.parse(localStorage.getItem(`ase_tx_${tId}`) || '[]');
    const savedCats = JSON.parse(localStorage.getItem(`ase_cats_${tId}`) || '[]');
    const savedCC = JSON.parse(localStorage.getItem(`ase_cc_${tId}`) || '[]');
    const savedRec = JSON.parse(localStorage.getItem(`ase_recurring_${tId}`) || '[]');
    const savedAudit = JSON.parse(localStorage.getItem(`ase_audit_${tId}`) || '[]');
    const savedIa = JSON.parse(localStorage.getItem(`ase_ia_${tId}`) || '{}');
    const savedBank = JSON.parse(localStorage.getItem(`ase_bank_stmt_${tId}`) || '[]');
    const savedFees = JSON.parse(localStorage.getItem(`ase_fees_${tId}`) || '[]');

    const defaultCats: FinanceCategory[] = [
      { id: '1', name: 'Mensalidades', type: TransactionType.INCOME, subcategories: ['Médiuns', 'Atrasadas'] },
      { id: '2', name: 'Doações', type: TransactionType.INCOME, subcategories: ['Anônimas', 'Membros'] },
      { id: '3', name: 'Cantina', type: TransactionType.INCOME, subcategories: ['Salgados', 'Bebidas'] },
      { id: '4', name: 'Obrigações', type: TransactionType.EXPENSE, subcategories: ['Ervas', 'Velas', 'Insumos'] },
      { id: '5', name: 'Administrativo', type: TransactionType.EXPENSE, subcategories: ['Aluguel', 'Energia', 'Água', 'Internet'] },
    ];

    const defaultCC: CostCenter[] = [
      { id: 'cc1', name: 'Administrativo', description: 'Custos da sede' },
      { id: 'cc2', name: 'Cantina', description: 'Operação de alimentos' },
      { id: 'cc3', name: 'Corrente', description: 'Giras e rituais' },
    ];

    setTransactions(savedTx);
    setCategories(savedCats.length ? savedCats : defaultCats);
    setCostCenters(savedCC.length ? savedCC : defaultCC);
    setRecurrences(savedRec);
    setAuditLog(savedAudit);
    setIaRules(savedIa);
    setBankStatement(savedBank);
    setFees(savedFees);
  }, [tId]);

  // Persist Data Helper
  const persist = (key: string, data: any) => {
    localStorage.setItem(`ase_${key}_${tId}`, JSON.stringify(data));
  };

  const addAudit = (action: string, details: string) => {
    const user = JSON.parse(localStorage.getItem('ase_user') || '{}');
    const entry: FinanceAuditLog = {
      id: 'AUD-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: user.id || 'sys',
      userName: user.fullName || 'Sistema',
      action,
      details
    };
    const updated = [entry, ...auditLog].slice(0, 100);
    setAuditLog(updated);
    persist('audit', updated);
  };

  // Intelligence Logic & Previsions
  const intelligence = useMemo(() => {
    const income = transactions.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => acc + t.amount, 0);
    const expense = transactions.filter(t => t.type === TransactionType.EXPENSE).reduce((acc, t) => acc + t.amount, 0);
    const balance = income - expense;
    
    // Average monthly expense over last 3 months
    const now = new Date();
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(now.getMonth() - 3);
    
    const recentExpenses = transactions.filter(t => t.type === TransactionType.EXPENSE && new Date(t.date) >= threeMonthsAgo);
    const avgMonthlyExpense = recentExpenses.reduce((acc, t) => acc + t.amount, 0) / 3 || 1;
    
    // Runway calculation: months current balance covers
    const runway = balance / avgMonthlyExpense;

    // Adimplência calculation (Current month)
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const monthFees = fees.filter(f => f.month === currentMonth && f.year === currentYear);
    const paidFees = monthFees.filter(f => f.status === 'PAID');
    const adimplenciaRate = monthFees.length > 0 ? (paidFees.length / monthFees.length) * 100 : 100;

    // Average Ticket
    const activeCount = mediums.filter(m => m.status === MembershipStatus.ACTIVE).length || 1;
    const avgTicket = income / activeCount;

    // Projection Data (Forecasting next 4 months)
    const avgIncome = transactions.filter(t => t.type === TransactionType.INCOME && new Date(t.date) >= threeMonthsAgo).reduce((acc, t) => acc + t.amount, 0) / 3 || 1;
    
    const projectionData = [
      { name: 'Atual', saldo: balance, status: 'real' },
      { name: 'Mês +1', saldo: balance + (avgIncome - avgMonthlyExpense), status: 'proj' },
      { name: 'Mês +2', saldo: balance + 2 * (avgIncome - avgMonthlyExpense), status: 'proj' },
      { name: 'Mês +3', saldo: balance + 3 * (avgIncome - avgMonthlyExpense), status: 'proj' },
      { name: 'Mês +4', saldo: balance + 4 * (avgIncome - avgMonthlyExpense), status: 'proj' },
    ];

    // Insights Generation
    const insights = [];
    if (runway < 2) insights.push({ type: 'danger', text: 'Runway Crítico! Seu caixa suporta menos de 2 meses sem novas entradas.', icon: ShieldAlert, color: 'text-rose-500', bg: 'bg-rose-50' });
    if (adimplenciaRate < 75) insights.push({ type: 'warning', text: 'Adimplência Baixa. Considere revisar o dia de vencimento ou enviar lembretes automáticos.', icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-50' });
    if (balance > 10000) insights.push({ type: 'success', text: 'Excedente de Caixa. Momento ideal para investir em reformas ou novos projetos.', icon: Rocket, color: 'text-emerald-500', bg: 'bg-emerald-50' });
    if (avgMonthlyExpense > avgIncome) insights.push({ type: 'danger', text: 'Fluxo de Caixa Negativo. Suas despesas mensais médias estão superando as receitas.', icon: TrendingDown, color: 'text-rose-600', bg: 'bg-rose-50' });
    else insights.push({ type: 'success', text: 'Margem Positiva. Você está retendo cerca de ' + Math.round(((avgIncome-avgMonthlyExpense)/avgIncome)*100) + '% da sua receita.', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' });

    return {
      runway: runway.toFixed(1),
      adimplenciaRate: Math.round(adimplenciaRate),
      avgTicket,
      projectionData,
      insights,
      avgMonthlyExpense,
      avgIncome
    };
  }, [transactions, fees, mediums]);

  const totals = useMemo(() => {
    const income = transactions.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => acc + t.amount, 0);
    const expense = transactions.filter(t => t.type === TransactionType.EXPENSE).reduce((acc, t) => acc + t.amount, 0);
    return { income, expense, balance: income - expense };
  }, [transactions]);

  const handleAddTx = () => {
    if (!newTx.amount || !newTx.description || !newTx.category) return alert("Preencha os campos obrigatórios");
    
    const tx: Transaction = {
      id: 'TX-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
      terreiroId: tId,
      type: newTx.type as TransactionType,
      category: newTx.category,
      subcategory: newTx.subcategory,
      costCenterId: newTx.costCenterId,
      amount: Number(newTx.amount),
      date: newTx.date!,
      description: newTx.description
    };

    const updated = [tx, ...transactions];
    setTransactions(updated);
    persist('tx', updated);
    addAudit('Criação', `Lançamento: ${tx.description} - R$ ${tx.amount}`);
    
    // Mock simple AI learning: auto-categorize based on similar descriptions
    const words = tx.description.toLowerCase().split(' ');
    const newIa = { ...iaRules };
    words.forEach(w => {
      if (w.length > 4) newIa[w] = tx.category;
    });
    setIaRules(newIa);
    persist('ia', newIa);

    setShowNewTx(false);
  };

  const confirmReconciliation = (rowId: string) => {
    const row = bankStatement.find(r => r.id === rowId);
    if (!row || !row.matchedTxId) return;

    const updatedTx = transactions.map(t => t.id === row.matchedTxId ? { ...t, isReconciled: true } : t);
    const updatedBank = bankStatement.map(r => r.id === rowId ? { ...r, status: 'RECONCILED' as const } : r);

    setTransactions(updatedTx);
    setBankStatement(updatedBank);
    persist('tx', updatedTx);
    localStorage.setItem(`ase_bank_stmt_${tId}`, JSON.stringify(updatedBank));
    addAudit('Conciliação', `Lançamento ${row.matchedTxId} conciliado com banco`);
  };

  const pendingReconciliationCount = bankStatement.filter(r => r.status === 'PENDING').length;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-24">
      {/* HEADER & NAV */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-stone-900 tracking-tighter">Gestão Financeira</h1>
          <p className="text-stone-500 font-medium">Controle total do {activeTerreiro.name}</p>
        </div>
        
        <div className="flex bg-white p-1.5 rounded-[2rem] border border-stone-200 shadow-sm overflow-x-auto scrollbar-hide">
          {[
            { id: 'fluxo', label: 'Fluxo', icon: LineChart },
            { id: 'ia', label: 'Inteligência', icon: BrainCircuit },
            { id: 'lancamentos', label: 'Lançamentos', icon: HistoryIcon },
            { id: 'mensalidades', label: 'Mensalidades', icon: Banknote },
            { id: 'categorias', label: 'Plano & CC', icon: Settings2 },
            { id: 'conciliacao', label: 'Conciliação', icon: RefreshCw },
            { id: 'relatorios', label: 'Relatórios', icon: BarChart3 },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black transition-all whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-stone-900 text-white shadow-xl' 
                  : 'text-stone-400 hover:text-stone-900 hover:bg-stone-50'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* RENDER CONTENT BY TAB */}
      <div className="animate-in slide-in-from-bottom-4 duration-500">
        
        {activeTab === 'mensalidades' && (
            <div className="animate-in fade-in">
                <MonthlyFeesView user={user} mediums={mediums} />
            </div>
        )}

        {/* MÓDULO DE INTELIGÊNCIA FINANCEIRA (IA) */}
        {activeTab === 'ia' && (
          <div className="space-y-10">
            {/* IA Intro Hero */}
            <div className="bg-stone-900 p-12 rounded-[3.5rem] text-white flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 text-amber-500/10 pointer-events-none"><BrainCircuit size={280} /></div>
               <div className="flex-1 space-y-6 relative z-10">
                  <div className="flex items-center gap-3 text-amber-500">
                    <Sparkles size={24} />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em]">Módulo preditivo ativo</span>
                  </div>
                  <h2 className="text-5xl font-black tracking-tighter leading-tight">Decisões guiadas<br /><span className="text-amber-500">por dados.</span></h2>
                  <p className="text-stone-400 font-medium max-w-lg leading-relaxed">
                    Analisamos seus padrões históricos para projetar o futuro financeiro do terreiro, alertando sobre riscos de caixa e oportunidades de economia.
                  </p>
               </div>
               <div className="grid grid-cols-2 gap-4 relative z-10">
                  <div className="bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 flex flex-col justify-center">
                    <p className="text-stone-500 text-[10px] font-black uppercase mb-1">Status de Saúde</p>
                    <h4 className={`text-2xl font-black ${Number(intelligence.runway) > 3 ? 'text-emerald-500' : 'text-amber-500'}`}>
                      {Number(intelligence.runway) > 4 ? 'Excelente' : Number(intelligence.runway) > 2 ? 'Estável' : 'Crítico'}
                    </h4>
                  </div>
                  <div className="bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 flex flex-col justify-center">
                    <p className="text-stone-500 text-[10px] font-black uppercase mb-1">Confiabilidade</p>
                    <h4 className="text-2xl font-black text-blue-400">92%</h4>
                  </div>
               </div>
            </div>

            {/* Health KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
               <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-blue-50 text-blue-500 rounded-2xl"><Rocket size={24}/></div>
                    <span className="text-[10px] font-black text-blue-500">RUNWAY</span>
                  </div>
                  <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest">Tempo de Vida</p>
                  <h4 className="text-3xl font-black text-stone-900 mt-1">{intelligence.runway} <span className="text-sm font-bold text-stone-400">Meses</span></h4>
                  <p className="text-[10px] text-stone-400 font-medium mt-1 leading-tight">Meses que o caixa suporta os gastos atuais.</p>
               </div>
               
               <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-emerald-50 text-emerald-500 rounded-2xl"><CheckCircle2 size={24}/></div>
                    <span className="text-[10px] font-black text-emerald-500">PAGOS</span>
                  </div>
                  <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest">Adimplência</p>
                  <h4 className="text-3xl font-black text-stone-900 mt-1">{intelligence.adimplenciaRate}%</h4>
                  <p className="text-[10px] text-stone-400 font-medium mt-1 leading-tight">Taxa de mensalidades pagas no mês atual.</p>
               </div>

               <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-amber-50 text-amber-500 rounded-2xl"><Target size={24}/></div>
                    <span className="text-[10px] font-black text-amber-500">MÉDIA</span>
                  </div>
                  <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest">Ticket por Médium</p>
                  <h4 className="text-3xl font-black text-stone-900 mt-1">R$ {intelligence.avgTicket.toFixed(0)}</h4>
                  <p className="text-[10px] text-stone-400 font-medium mt-1 leading-tight">Receita total dividida por nº de membros.</p>
               </div>

               <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-stone-900 text-amber-500 rounded-2xl"><PieChart size={24}/></div>
                    <span className="text-[10px] font-black text-stone-900">META</span>
                  </div>
                  <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest">Break-Even</p>
                  <h4 className="text-3xl font-black text-stone-900 mt-1">{Math.ceil(intelligence.avgMonthlyExpense / (mediums[0]?.monthlyFeeValue || 50))} <span className="text-sm font-bold text-stone-400">un.</span></h4>
                  <p className="text-[10px] text-stone-400 font-medium mt-1 leading-tight">Mensalidades necessárias para cobrir custos fixos.</p>
               </div>
            </div>

            {/* Forecast & Trends */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Forecast Area Chart */}
              <div className="lg:col-span-2 bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <div>
                    <h3 className="text-xl font-black text-stone-900 uppercase tracking-tighter">Previsão de Fluxo de Caixa</h3>
                    <p className="text-xs font-bold text-stone-400">Projeção estimada para os próximos 4 meses</p>
                  </div>
                  <div className="flex items-center gap-4">
                     <div className="flex items-center gap-1.5">
                       <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                       <span className="text-[10px] font-black text-stone-400">PROJETADO</span>
                     </div>
                  </div>
                </div>
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={intelligence.projectionData}>
                      <defs>
                        <linearGradient id="colorSaldoProj" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 10}} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 10}} dx={-10} />
                      <Tooltip contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}} />
                      <Area type="monotone" dataKey="saldo" stroke="#f59e0b" strokeWidth={4} fillOpacity={1} fill="url(#colorSaldoProj)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Smart Insights & Alerts List */}
              <div className="space-y-6">
                <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm h-full flex flex-col">
                  <h3 className="text-xl font-black text-stone-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                    <Zap size={24} className="text-amber-500 fill-amber-500" /> IA Smart Insights
                  </h3>
                  <div className="space-y-4 flex-1 overflow-y-auto pr-2 scrollbar-hide">
                    {intelligence.insights.map((insight, idx) => (
                      <div key={idx} className={`p-5 rounded-3xl flex gap-4 border border-transparent hover:border-stone-200 transition-all ${insight.bg}`}>
                        <div className={`shrink-0 p-2.5 rounded-2xl bg-white shadow-sm h-fit ${insight.color}`}>
                          <insight.icon size={20} />
                        </div>
                        <div className="space-y-1">
                          <p className={`text-[10px] font-black uppercase tracking-widest ${insight.color}`}>Insight Automático</p>
                          <p className="text-xs font-bold text-stone-600 leading-relaxed">{insight.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-8 pt-8 border-t border-stone-50">
                    <button className="w-full py-4 bg-stone-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-stone-800 transition-all">
                       Ver Plano de Ação <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Benchmarking / Distribution */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="bg-stone-900 p-10 rounded-[3.5rem] text-white">
                  <h3 className="text-xl font-black text-amber-500 uppercase tracking-tighter mb-8">Otimização de Custos</h3>
                  <div className="space-y-6">
                     <div className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/10">
                        <div>
                          <p className="font-black text-lg">Insumos & Velas</p>
                          <p className="text-xs font-medium text-stone-500">Gastos com insumos subiram 18% vs média anual.</p>
                        </div>
                        <div className="text-right">
                           <span className="text-[10px] font-black bg-rose-500/20 text-rose-500 px-3 py-1 rounded-full">+18%</span>
                        </div>
                     </div>
                     <div className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/10">
                        <div>
                          <p className="font-black text-lg">Energia Elétrica</p>
                          <p className="text-xs font-medium text-stone-500">Padrão de consumo estável. Sugestão: revisão de lâmpadas.</p>
                        </div>
                        <div className="text-right">
                           <span className="text-[10px] font-black bg-emerald-500/20 text-emerald-500 px-3 py-1 rounded-full">OK</span>
                        </div>
                     </div>
                     <div className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/10">
                        <div>
                          <p className="font-black text-lg">Eventos / Festa</p>
                          <p className="text-xs font-medium text-stone-500">Margem de lucro da cantina em eventos está em 42%.</p>
                        </div>
                        <div className="text-right">
                           <span className="text-[10px] font-black bg-blue-500/20 text-blue-500 px-3 py-1 rounded-full">BOM</span>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm flex flex-col justify-between">
                  <div className="space-y-2">
                    <h3 className="text-xl font-black text-stone-900 uppercase tracking-tighter">Comparativo IA</h3>
                    <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">Média Receita vs Despesa (Mensal)</p>
                  </div>
                  
                  <div className="h-[250px] w-full my-8">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[
                        { name: 'Receita', valor: intelligence.avgIncome, fill: '#10b981' },
                        { name: 'Despesa', valor: intelligence.avgMonthlyExpense, fill: '#f43f5e' },
                        { name: 'Fixo (Meta)', valor: (intelligence.avgIncome * 0.7), fill: '#fbbf24' }
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 10}} />
                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 10}} />
                        <Tooltip cursor={{fill: '#f9fafb'}} contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}} />
                        <Bar dataKey="valor" radius={[12, 12, 0, 0]} barSize={50}>
                           { [0, 1, 2].map((entry, index) => (
                             <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : index === 1 ? '#f43f5e' : '#fbbf24'} />
                           ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="flex gap-4">
                     <div className="flex-1 p-6 bg-stone-50 rounded-3xl border border-stone-100 text-center">
                        <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-1">Gap Financeiro</p>
                        <p className="text-2xl font-black text-stone-900">R$ {(intelligence.avgIncome - intelligence.avgMonthlyExpense).toFixed(0)}</p>
                     </div>
                     <div className="flex-1 p-6 bg-stone-50 rounded-3xl border border-stone-100 text-center">
                        <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-1">Meta Poupança</p>
                        <p className="text-2xl font-black text-amber-600">20%</p>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* TAB: FLUXO DE CAIXA (RESUMO) */}
        {activeTab === 'fluxo' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm relative group overflow-hidden">
                <div className="absolute -right-4 -top-4 text-emerald-500/5 group-hover:scale-110 transition-transform"><ArrowUpCircle size={120} /></div>
                <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest mb-1">Entradas</p>
                <h3 className="text-4xl font-black tracking-tight text-emerald-600">R$ {totals.income.toLocaleString('pt-BR')}</h3>
                <div className="mt-4 flex items-center gap-2 text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 w-fit px-3 py-1 rounded-full"><TrendingUp size={12}/> Saúde Positiva</div>
              </div>
              <div className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm relative group overflow-hidden">
                <div className="absolute -right-4 -top-4 text-rose-500/5 group-hover:scale-110 transition-transform"><ArrowDownCircle size={120} /></div>
                <p className="text-stone-400 font-black text-[10px] uppercase tracking-widest mb-1">Saídas</p>
                <h3 className="text-4xl font-black tracking-tight text-rose-600">R$ {totals.expense.toLocaleString('pt-BR')}</h3>
              </div>
              <div className="bg-stone-900 p-8 rounded-[3rem] text-white shadow-2xl shadow-stone-900/20 relative group overflow-hidden">
                <div className="absolute -right-4 -top-4 text-white/5 group-hover:scale-110 transition-transform"><DollarSign size={120} /></div>
                <p className="text-stone-500 font-black text-[10px] uppercase tracking-widest mb-1">Saldo Atual</p>
                <h3 className="text-4xl font-black tracking-tight text-amber-500">R$ {totals.balance.toLocaleString('pt-BR')}</h3>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm">
                <div className="flex justify-between items-center mb-10">
                  <h3 className="text-xl font-black text-stone-900 uppercase tracking-tighter">Status de Conciliação</h3>
                  <span className="text-xs font-bold text-stone-400">Banco Cora Sincronizado</span>
                </div>
                <div className="flex flex-col items-center justify-center py-6 space-y-6">
                   <div className="relative w-48 h-48">
                      <svg className="w-full h-full" viewBox="0 0 36 36">
                        <path className="text-stone-100" strokeWidth="2.5" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <path className="text-amber-500" strokeWidth="2.5" strokeDasharray={`${bankStatement.length > 0 ? (1 - pendingReconciliationCount/bankStatement.length) * 100 : 100}, 100`} strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                         <span className="text-5xl font-black text-stone-900">{bankStatement.length > 0 ? Math.round((1 - pendingReconciliationCount/bankStatement.length) * 100) : 100}%</span>
                         <span className="text-[9px] font-black text-stone-400 uppercase tracking-widest">Validado</span>
                      </div>
                   </div>
                   <div className="text-center space-y-1">
                      <p className="font-black text-stone-900 text-lg">{pendingReconciliationCount} Pendentes</p>
                      <button 
                        onClick={() => setActiveTab('conciliacao')}
                        className="text-amber-600 font-black text-[10px] uppercase tracking-widest hover:underline"
                      >
                        Acessar Conciliação Cora
                      </button>
                   </div>
                </div>
              </div>

              <div className="bg-stone-900 p-10 rounded-[3.5rem] text-white">
                <h3 className="text-xl font-black text-amber-500 uppercase tracking-tighter mb-8 flex items-center gap-2">
                  <ShieldAlert size={20} /> Alertas de Risco
                </h3>
                <div className="space-y-4">
                  {pendingReconciliationCount > 0 && (
                    <div className="bg-stone-800 p-6 rounded-3xl border border-stone-700 flex items-center gap-4 animate-pulse">
                      <Zap className="text-amber-500" />
                      <div>
                        <p className="font-bold text-sm">{pendingReconciliationCount} Conciliações Pendentes</p>
                        <p className="text-[10px] text-stone-500 uppercase tracking-widest">Ação sugerida: Validar extrato Cora</p>
                      </div>
                    </div>
                  )}
                  {Number(intelligence.runway) < 3 && (
                    <div className="bg-rose-950/30 p-6 rounded-3xl border border-rose-500/20 flex items-center gap-4">
                      <AlertTriangle className="text-rose-500" />
                      <div>
                        <p className="font-bold text-sm text-rose-100">Alerta de Runway</p>
                        <p className="text-[10px] text-rose-500/70 uppercase tracking-widest">Seu caixa dura menos de 3 meses.</p>
                      </div>
                    </div>
                  )}
                  <div className="bg-stone-800 p-6 rounded-3xl border border-stone-700 flex items-center gap-4 opacity-50">
                    <Check className="text-emerald-500" />
                    <div>
                      <p className="font-bold text-sm">Aluguel Provisionado</p>
                      <p className="text-[10px] text-stone-500 uppercase tracking-widest">Saldo suficiente para o vencimento dia 10</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: CONCILIARAÇÃO */}
        {activeTab === 'conciliacao' && (
          <div className="space-y-8">
            <div className="bg-white p-12 rounded-[4rem] border-2 border-dashed border-stone-200 flex flex-col items-center text-center space-y-6">
              <div className="w-20 h-20 bg-stone-100 rounded-[2.5rem] flex items-center justify-center text-stone-400"><Upload size={40}/></div>
              <div>
                <h3 className="text-2xl font-black text-stone-900 tracking-tighter">Conciliação Bancária Cora</h3>
                <p className="text-stone-500 font-medium max-w-sm">Importe arquivos CSV/OFX ou utilize a integração direta (PRO) para baixar lançamentos bancários.</p>
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={() => alert("Simulando upload de extrato Cora...")}
                  className="bg-stone-900 text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-stone-900/20 hover:scale-105 active:scale-95 transition-all"
                >
                   Fazer Upload OFX/CSV
                </button>
              </div>
            </div>

            {bankStatement.length > 0 && (
              <div className="bg-white rounded-[3.5rem] border border-stone-200 shadow-sm overflow-hidden animate-in slide-in-from-top-10">
                <div className="p-8 border-b border-stone-100 flex justify-between items-center">
                   <h4 className="font-black text-stone-900 uppercase tracking-tight">Transações Cora Pendentes</h4>
                   <span className="text-[10px] font-black bg-amber-50 text-amber-600 px-3 py-1 rounded-full uppercase tracking-widest">{pendingReconciliationCount} Pendentes</span>
                </div>
                <div className="divide-y divide-stone-50">
                   {bankStatement.filter(r => r.status === 'PENDING').map(row => (
                     <div key={row.id} className="p-8 flex items-center justify-between group hover:bg-stone-50/50 transition-all">
                        <div className="flex gap-8 items-center">
                          <div className="text-center">
                             <p className="text-[10px] font-black text-stone-300 uppercase">{row.date.split('-')[1]}</p>
                             <p className="text-xl font-black text-stone-900">{row.date.split('-')[2]}</p>
                          </div>
                          <div>
                             <p className="font-black text-stone-900 uppercase tracking-tight leading-tight">{row.description}</p>
                             <p className={`font-black text-sm mt-1 ${row.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-stone-900'}`}>
                               {row.type === TransactionType.INCOME ? '+' : '-'} R$ {row.amount.toLocaleString('pt-BR')}
                             </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          {row.matchedTxId ? (
                            <div className="flex items-center gap-8 animate-in fade-in">
                               <div className="text-right">
                                  <div className="flex items-center gap-1.5 justify-end">
                                     <Zap size={12} className="text-amber-500 fill-amber-500" />
                                     <span className="text-[10px] font-black text-stone-900 uppercase">Sugestão: {row.matchScore}% score</span>
                                  </div>
                                  <p className="text-[10px] text-stone-400 font-bold uppercase truncate w-40">Match: {transactions.find(t => t.id === row.matchedTxId)?.description}</p>
                               </div>
                               <button 
                                 onClick={() => confirmReconciliation(row.id)}
                                 className="bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-600"
                               >
                                 Confirmar
                               </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-3">
                               <span className="text-[10px] font-black text-stone-300 uppercase tracking-widest">Sem match direto</span>
                               <button className="p-2 bg-stone-50 text-stone-400 rounded-xl hover:text-rose-500 transition-all"><Trash2 size={16}/></button>
                            </div>
                          )}
                        </div>
                     </div>
                   ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'lancamentos' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Buscar lançamentos..." 
                  className="w-full pl-12 pr-4 py-4 bg-white border border-stone-200 rounded-[2rem] text-sm outline-none focus:ring-2 focus:ring-amber-500/20"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-3">
                <button className="bg-white border border-stone-200 text-stone-900 px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-stone-50 transition-all">
                   <Download size={18} /> Exportar
                </button>
                <button 
                  onClick={() => setShowNewTx(true)}
                  className="bg-stone-900 text-white px-8 py-4 rounded-2xl font-black text-sm flex items-center gap-2 shadow-xl shadow-stone-900/10 hover:scale-105 active:scale-95 transition-all"
                >
                   <PlusCircle size={20} /> Novo Lançamento
                </button>
              </div>
            </div>

            <div className="bg-white rounded-[3.5rem] border border-stone-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-stone-50/50">
                    <tr>
                      <th className="px-8 py-4 text-[10px] font-black text-stone-400 uppercase tracking-widest">Data</th>
                      <th className="px-8 py-4 text-[10px] font-black text-stone-400 uppercase tracking-widest">Descrição</th>
                      <th className="px-8 py-4 text-[10px] font-black text-stone-400 uppercase tracking-widest">Categoria</th>
                      <th className="px-8 py-4 text-[10px] font-black text-stone-400 uppercase tracking-widest">C. Custo</th>
                      <th className="px-8 py-4 text-[10px] font-black text-stone-400 uppercase tracking-widest text-right">Valor</th>
                      <th className="px-8 py-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {transactions.filter(t => t.description.toLowerCase().includes(searchTerm.toLowerCase())).map((tx) => (
                      <tr key={tx.id} className="group hover:bg-stone-50 transition-colors">
                        <td className="px-8 py-6 text-sm font-bold text-stone-500">{new Date(tx.date + 'T12:00:00').toLocaleDateString()}</td>
                        <td className="px-8 py-6">
                          <p className="text-sm font-black text-stone-900 uppercase tracking-tight">{tx.description}</p>
                          {tx.isReconciled && (
                            <span className="flex items-center gap-1 text-[8px] font-black text-emerald-600 uppercase tracking-widest mt-1">
                               <CheckCircle2 size={10} /> Conciliado
                            </span>
                          )}
                        </td>
                        <td className="px-8 py-6">
                          <span className="text-[10px] font-black text-stone-500 bg-stone-100 px-3 py-1 rounded-full uppercase tracking-widest">{tx.category}</span>
                        </td>
                        <td className="px-8 py-6">
                           <span className="text-xs font-bold text-stone-400">{costCenters.find(c => c.id === tx.costCenterId)?.name || '-'}</span>
                        </td>
                        <td className={`px-8 py-6 text-right font-black text-sm ${tx.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-stone-900'}`}>
                          {tx.type === TransactionType.INCOME ? '+' : '-'} {tx.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </td>
                        <td className="px-8 py-6 text-right">
                          <button className="p-2 text-stone-300 hover:text-stone-900"><MoreVertical size={18}/></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB: PLANO DE CONTAS */}
        {activeTab === 'categorias' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-stone-900 tracking-tighter">Plano de Contas</h3>
                <button className="bg-stone-900 text-white p-2 rounded-xl"><Plus size={20}/></button>
              </div>
              <div className="space-y-4">
                {categories.map(cat => (
                  <div key={cat.id} className="p-6 bg-stone-50 rounded-3xl border border-stone-100 group">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-black text-stone-900 uppercase tracking-tight">{cat.name}</h4>
                      <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${cat.type === TransactionType.INCOME ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                        {cat.type}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {cat.subcategories.map(sub => (
                        <span key={sub} className="bg-white border border-stone-100 px-3 py-1.5 rounded-xl text-xs text-stone-500 font-bold">{sub}</span>
                      ))}
                      <button className="bg-stone-200/50 p-1.5 rounded-xl text-stone-400 hover:text-stone-900"><Plus size={14}/></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-stone-900 p-10 rounded-[3.5rem] text-white space-y-8">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-amber-500 tracking-tighter">Centros de Custo</h3>
                <button className="bg-amber-500 text-stone-900 p-2 rounded-xl"><Plus size={20}/></button>
              </div>
              <div className="space-y-4">
                {costCenters.map(cc => (
                  <div key={cc.id} className="p-6 bg-stone-800 rounded-3xl border border-stone-700 hover:border-amber-500 transition-all cursor-pointer">
                    <h4 className="font-black text-white text-lg">{cc.name}</h4>
                    <p className="text-stone-400 text-xs font-medium mt-1">{cc.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB: RELATÓRIOS */}
        {activeTab === 'relatorios' && (
          <div className="space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
               <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 col-span-2 space-y-10">
                  <h3 className="text-2xl font-black text-stone-900 tracking-tighter uppercase">DRE Simplificado <span className="text-stone-300 text-sm ml-2">Referência Atual</span></h3>
                  <div className="space-y-6">
                    <div className="flex justify-between items-end pb-4 border-b border-stone-100">
                       <p className="font-black text-stone-400 text-xs uppercase tracking-widest">Receitas Operacionais</p>
                       <p className="font-black text-2xl text-emerald-600">R$ {totals.income.toLocaleString()}</p>
                    </div>
                    <div className="flex justify-between items-end pb-4 border-b border-stone-100">
                       <p className="font-black text-stone-400 text-xs uppercase tracking-widest">Despesas Variáveis</p>
                       <p className="font-black text-xl text-stone-900">(R$ {(totals.expense * 0.4).toLocaleString()})</p>
                    </div>
                    <div className="flex justify-between items-end pb-4 border-b border-stone-100">
                       <p className="font-black text-stone-400 text-xs uppercase tracking-widest">Custos Fixos</p>
                       <p className="font-black text-xl text-stone-900">(R$ {(totals.expense * 0.6).toLocaleString()})</p>
                    </div>
                    <div className="flex justify-between items-center pt-4 bg-stone-900 p-6 rounded-[2rem] text-white">
                       <p className="font-black text-amber-500 text-xs uppercase tracking-widest">Resultado Líquido</p>
                       <p className="font-black text-3xl">R$ {totals.balance.toLocaleString()}</p>
                    </div>
                  </div>
               </div>
               <div className="bg-amber-500 p-10 rounded-[4rem] text-stone-900 space-y-8 flex flex-col justify-center text-center">
                  <BarChart3 size={64} className="mx-auto text-stone-900/40" />
                  <h4 className="text-4xl font-black tracking-tighter">Saúde da Casa</h4>
                  <p className="font-bold text-stone-900/60 max-w-[200px] mx-auto">Sua reserva atual permite operar por {intelligence.runway} meses.</p>
                  <div className="text-6xl font-black text-stone-900">{intelligence.runway}</div>
                  <p className="font-black uppercase text-[10px] tracking-widest">meses de vida</p>
               </div>
            </div>
          </div>
        )}
      </div>

      {/* MODAL: NOVO LANÇAMENTO */}
      {showNewTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-stone-900/70 backdrop-blur-md" onClick={() => setShowNewTx(false)}></div>
          <div className="bg-white w-full max-w-xl rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="bg-stone-900 p-12 text-white relative">
               <button onClick={() => setShowNewTx(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white transition-colors"><X size={28} /></button>
               <div className="w-16 h-16 bg-amber-500 rounded-[2rem] flex items-center justify-center text-stone-900 mb-8 shadow-xl shadow-amber-500/20"><Plus size={32} /></div>
               <h2 className="text-4xl font-black tracking-tighter">Novo Lançamento</h2>
            </div>
            <div className="p-12 space-y-6">
               <div className="flex p-1.5 bg-stone-100 rounded-3xl gap-1.5">
                  <button onClick={() => setNewTx({ ...newTx, type: TransactionType.INCOME })} className={`flex-1 py-4 rounded-[1.5rem] text-xs font-black uppercase tracking-widest transition-all ${newTx.type === TransactionType.INCOME ? 'bg-white text-emerald-600 shadow-xl' : 'text-stone-400'}`}>Entrada</button>
                  <button onClick={() => setNewTx({ ...newTx, type: TransactionType.EXPENSE })} className={`flex-1 py-4 rounded-[1.5rem] text-xs font-black uppercase tracking-widest transition-all ${newTx.type === TransactionType.EXPENSE ? 'bg-white text-rose-600 shadow-xl' : 'text-stone-400'}`}>Saída</button>
               </div>
               <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Valor</label>
                    <input type="number" step="0.01" className="w-full bg-stone-50 rounded-2xl p-4 font-black" onChange={(e) => setNewTx({ ...newTx, amount: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Data</label>
                    <input type="date" className="w-full bg-stone-50 rounded-2xl p-4" value={newTx.date} onChange={(e) => setNewTx({ ...newTx, date: e.target.value })} />
                  </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Descrição</label>
                  <input type="text" className="w-full bg-stone-50 rounded-2xl p-4 font-black" value={newTx.description} onChange={(e) => setNewTx({ ...newTx, description: e.target.value })} />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Categoria</label>
                  <select className="w-full bg-stone-50 rounded-2xl p-4" onChange={(e) => setNewTx({ ...newTx, category: e.target.value })}>
                    <option value="">Selecionar...</option>
                    {categories.filter(c => c.type === newTx.type).map(cat => (
                      <option key={cat.id} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
               </div>
               <button onClick={handleAddTx} className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black uppercase tracking-widest shadow-2xl">Registrar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FinanceView;


import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, Landmark, Upload, CheckCircle2, AlertTriangle, 
  X, RefreshCw, Zap, Search, Download, Trash2, ShieldCheck,
  EyeOff, Info, Check, Filter, ArrowRight, History, Plus
} from 'lucide-react';
import { 
  Terreiro, Transaction, TransactionType, 
  BankStatementRow, BankConnection, FinanceAuditLog 
} from '../types';

interface BankReconciliationViewProps {
  onBack: () => void;
}

const BankReconciliationView: React.FC<BankReconciliationViewProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'conciliar' | 'extrato' | 'audit'>('conciliar');
  const [connection, setConnection] = useState<BankConnection | null>(null);
  const [statement, setStatement] = useState<BankStatementRow[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [auditLog, setAuditLog] = useState<FinanceAuditLog[]>([]);

  const activeTerreiro: Terreiro = JSON.parse(localStorage.getItem('ase_terreiro') || '{}');
  const tId = activeTerreiro.id;

  // Carregar Dados
  useEffect(() => {
    const savedConn = localStorage.getItem(`ase_bank_conn_${tId}`);
    if (savedConn) setConnection(JSON.parse(savedConn));

    const savedStatement = localStorage.getItem(`ase_bank_stmt_${tId}`);
    if (savedStatement) setStatement(JSON.parse(savedStatement));

    const savedAudit = localStorage.getItem(`ase_bank_audit_${tId}`);
    if (savedAudit) setAuditLog(JSON.parse(savedAudit));
  }, [tId]);

  const addAudit = (action: string, details: string) => {
    const user = JSON.parse(localStorage.getItem('ase_user') || '{}');
    const entry: FinanceAuditLog = {
      id: 'B-AUD-' + Date.now(),
      timestamp: new Date().toISOString(),
      userId: user.id || 'sys',
      userName: user.fullName || 'Admin',
      action,
      details
    };
    const updated = [entry, ...auditLog].slice(0, 50);
    setAuditLog(updated);
    localStorage.setItem(`ase_bank_audit_${tId}`, JSON.stringify(updated));
  };

  const handleConnectCora = () => {
    const conn: BankConnection = {
      status: 'connected',
      provider: 'cora',
      connectedAt: new Date().toISOString()
    };
    localStorage.setItem(`ase_bank_conn_${tId}`, JSON.stringify(conn));
    setConnection(conn);
    setShowConnectModal(false);
    addAudit('Conexão', 'Banco Cora conectado para importação manual');
  };

  const handleImportMockCSV = () => {
    // Simular importação de um CSV
    const now = new Date();
    const mockRows: BankStatementRow[] = [
      { id: 'B-001', date: now.toISOString().split('T')[0], description: 'PIX RECEBIDO JOAO PEREIRA', amount: 50.00, type: TransactionType.INCOME, status: 'PENDING' },
      { id: 'B-002', date: now.toISOString().split('T')[0], description: 'PAGTO ENERGIA ENEL', amount: 345.50, type: TransactionType.EXPENSE, status: 'PENDING' },
      { id: 'B-003', date: now.toISOString().split('T')[0], description: 'DEPÓSITO EM DINHEIRO', amount: 200.00, type: TransactionType.INCOME, status: 'PENDING' },
      { id: 'B-004', date: now.toISOString().split('T')[0], description: 'MENSALIDADE ANA MARIA', amount: 60.00, type: TransactionType.INCOME, status: 'PENDING' },
    ];

    // Cruzar com lançamentos reais para dar score
    const cashflow: Transaction[] = JSON.parse(localStorage.getItem(`ase_tx_${tId}`) || '[]');
    
    const scoredRows = mockRows.map(row => {
      let bestMatch: { id: string, score: number } | null = null;
      
      cashflow.forEach(tx => {
        if (tx.isReconciled) return;
        
        let score = 0;
        // Valor exato (50 pts)
        if (Math.abs(tx.amount - row.amount) < 0.01) score += 60;
        // Data próxima (±2 dias) (20 pts)
        const d1 = new Date(tx.date).getTime();
        const d2 = new Date(row.date).getTime();
        const diffDays = Math.abs(d1 - d2) / (1000 * 60 * 60 * 24);
        if (diffDays <= 2) score += 20;
        // Descrição similar (20 pts)
        if (row.description.toLowerCase().includes(tx.description.toLowerCase()) || 
            tx.description.toLowerCase().includes(row.description.toLowerCase())) score += 20;

        if (score > (bestMatch?.score || 0)) {
          bestMatch = { id: tx.id, score };
        }
      });

      return { 
        ...row, 
        matchedTxId: bestMatch?.id, 
        matchScore: bestMatch?.score 
      };
    });

    const updated = [...scoredRows, ...statement].slice(0, 100);
    setStatement(updated);
    localStorage.setItem(`ase_bank_stmt_${tId}`, JSON.stringify(updated));
    addAudit('Importação', `Importado extrato com ${scoredRows.length} linhas`);
    alert("Extrato importado e analisado pela IA de Conciliação!");
  };

  const handleConciliar = (bankRowId: string, matchedTxId: string) => {
    // 1. Atualizar extrato
    const updatedStmt = statement.map(r => r.id === bankRowId ? { ...r, status: 'RECONCILED' as const } : r);
    setStatement(updatedStmt);
    localStorage.setItem(`ase_bank_stmt_${tId}`, JSON.stringify(updatedStmt));

    // 2. Atualizar lançamento no caixa
    const cashflow: Transaction[] = JSON.parse(localStorage.getItem(`ase_tx_${tId}`) || '[]');
    const updatedCash = cashflow.map(tx => tx.id === matchedTxId ? { ...tx, isReconciled: true } : tx);
    localStorage.setItem(`ase_tx_${tId}`, JSON.stringify(updatedCash));

    addAudit('Conciliação', `Linha ${bankRowId} conciliada com lançamento ${matchedTxId}`);
  };

  const handleIgnore = (bankRowId: string) => {
    const updatedStmt = statement.map(r => r.id === bankRowId ? { ...r, status: 'IGNORED' as const } : r);
    setStatement(updatedStmt);
    localStorage.setItem(`ase_bank_stmt_${tId}`, JSON.stringify(updatedStmt));
    addAudit('Ignorar', `Transação bancária ${bankRowId} marcada como ignorada`);
  };

  const pendingCount = statement.filter(r => r.status === 'PENDING').length;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <button onClick={onBack} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm mb-2">
            <ArrowLeft size={16} /> Voltar ao Administrativo
          </button>
          <h2 className="text-3xl font-black text-stone-900 tracking-tighter flex items-center gap-3">
             <Landmark size={32} className="text-amber-500" />
             Banco & Conciliação
          </h2>
          <p className="text-stone-500 font-medium">Sincronize o fluxo de caixa com o extrato bancário do {activeTerreiro.name}</p>
        </div>

        {!connection ? (
          <button 
            onClick={() => setShowConnectModal(true)}
            className="bg-stone-900 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all"
          >
            Conectar Banco Cora
          </button>
        ) : (
          <div className="flex bg-white p-1.5 rounded-2xl border border-stone-200 shadow-sm overflow-x-auto">
            {[
              { id: 'conciliar', label: `Conciliação (${pendingCount})`, icon: Zap },
              { id: 'extrato', label: 'Extrato Importado', icon: Landmark },
              { id: 'audit', label: 'Auditoria', icon: History },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  activeTab === tab.id 
                    ? 'bg-stone-900 text-white shadow-lg' 
                    : 'text-stone-400 hover:text-stone-900'
                }`}
              >
                <tab.icon size={16} />
                {tab.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {!connection ? (
        <div className="py-20 bg-white rounded-[3.5rem] border border-stone-200 shadow-sm flex flex-col items-center justify-center text-center px-10 space-y-6">
           <div className="w-24 h-24 bg-stone-50 rounded-[2.5rem] flex items-center justify-center text-stone-300">
             <Landmark size={48} />
           </div>
           <div className="space-y-2">
             <h3 className="text-2xl font-black text-stone-900 tracking-tight">O banco ainda não está conectado</h3>
             <p className="text-stone-500 max-w-md mx-auto font-medium">A conexão com o Banco Cora permite importar extratos para validar as doações e mensalidades recebidas automaticamente.</p>
           </div>
           <button 
             onClick={() => setShowConnectModal(true)}
             className="bg-amber-500 text-stone-900 px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-amber-500/20 hover:bg-amber-400"
           >
             Configurar Conexão Bancária
           </button>
        </div>
      ) : (
        <div className="animate-in slide-in-from-bottom-4 duration-500 space-y-8">
          
          {/* TAB: CONCILIAR */}
          {activeTab === 'conciliar' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                 <h3 className="text-xl font-black text-stone-900 uppercase tracking-widest">Pendentes de Validação</h3>
                 <button 
                  onClick={handleImportMockCSV}
                  className="text-[10px] font-black uppercase text-amber-600 bg-amber-50 px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-amber-100 transition-colors"
                 >
                   <Upload size={14} /> Importar Arquivo do Banco
                 </button>
              </div>

              <div className="grid gap-4">
                {statement.filter(r => r.status === 'PENDING').map(row => (
                  <div key={row.id} className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-8 group hover:border-amber-500 transition-all">
                    <div className="flex items-center gap-6 flex-1 min-w-0">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${row.type === TransactionType.INCOME ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                        {row.type === TransactionType.INCOME ? <Plus size={24} /> : <X size={24} />}
                      </div>
                      <div className="min-w-0">
                        <p className="font-black text-stone-900 uppercase tracking-tight text-lg truncate leading-tight">{row.description}</p>
                        <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mt-1">Data: {new Date(row.date + 'T12:00:00').toLocaleDateString()} • Valor: R$ {row.amount.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6 md:border-l md:border-stone-100 md:pl-8">
                      {row.matchedTxId ? (
                        <div className="flex items-center gap-6 animate-in fade-in">
                           <div className="text-right">
                              <div className="flex items-center gap-1.5 justify-end mb-1">
                                 <Zap size={14} className="text-amber-500 fill-amber-500" />
                                 <span className="text-[11px] font-black text-stone-900 uppercase">Sugestão: {row.matchScore}% Score</span>
                              </div>
                              <p className="text-[10px] text-stone-400 font-bold uppercase truncate w-48">Lançamento: {row.matchedTxId.substring(0,8)}...</p>
                           </div>
                           <div className="flex gap-2">
                              <button 
                                onClick={() => handleConciliar(row.id, row.matchedTxId!)}
                                className="bg-emerald-500 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-600 shadow-lg shadow-emerald-500/20"
                              >
                                Conciliar
                              </button>
                              <button 
                                onClick={() => handleIgnore(row.id)}
                                className="bg-stone-50 text-stone-400 p-3 rounded-2xl hover:text-rose-500"
                              >
                                <EyeOff size={20} />
                              </button>
                           </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-4">
                           <p className="text-[10px] font-black text-stone-400 uppercase italic">Nenhuma sugestão encontrada</p>
                           <button 
                            onClick={() => handleIgnore(row.id)}
                            className="bg-stone-50 text-stone-400 p-3 rounded-2xl hover:text-stone-900"
                           >
                            <Trash2 size={20} />
                           </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {statement.filter(r => r.status === 'PENDING').length === 0 && (
                  <div className="py-20 text-center bg-stone-50 rounded-[3rem] border border-stone-100">
                    <CheckCircle2 size={48} className="mx-auto mb-4 text-stone-200" />
                    <p className="font-bold text-stone-400">Tudo em ordem! Nenhuma conciliação pendente.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: EXTRATO COMPLETO */}
          {activeTab === 'extrato' && (
            <div className="bg-white rounded-[3.5rem] border border-stone-200 shadow-sm overflow-hidden">
               <div className="p-8 border-b border-stone-100 flex items-center justify-between">
                  <h3 className="font-black text-stone-900 uppercase tracking-widest">Registros Bancários</h3>
                  <div className="relative w-64">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input 
                      type="text" 
                      placeholder="Buscar no extrato..."
                      className="w-full pl-10 pr-4 py-2 bg-stone-50 rounded-xl text-xs outline-none"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead className="bg-stone-50 text-[10px] font-black text-stone-400 uppercase tracking-widest">
                     <tr>
                       <th className="px-8 py-4">Data</th>
                       <th className="px-8 py-4">Descrição</th>
                       <th className="px-8 py-4">Valor</th>
                       <th className="px-8 py-4">Status</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-stone-100">
                     {statement.filter(r => r.description.toLowerCase().includes(searchTerm.toLowerCase())).map(row => (
                       <tr key={row.id} className="hover:bg-stone-50/50 transition-colors">
                         <td className="px-8 py-5 text-sm font-bold text-stone-500">{new Date(row.date + 'T12:00:00').toLocaleDateString()}</td>
                         <td className="px-8 py-5 font-black text-stone-900 uppercase text-xs">{row.description}</td>
                         <td className={`px-8 py-5 font-black text-xs ${row.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-stone-900'}`}>
                            {row.type === TransactionType.INCOME ? '+' : '-'} R$ {row.amount.toLocaleString()}
                         </td>
                         <td className="px-8 py-5">
                            <span className={`text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-widest ${
                              row.status === 'RECONCILED' ? 'bg-emerald-50 text-emerald-600' : 
                              row.status === 'IGNORED' ? 'bg-stone-100 text-stone-400' : 'bg-amber-50 text-amber-600'
                            }`}>
                              {row.status}
                            </span>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          )}

          {/* TAB: AUDITORIA */}
          {activeTab === 'audit' && (
            <div className="bg-stone-900 p-10 rounded-[3.5rem] text-white">
               <h3 className="text-xl font-black text-amber-500 uppercase tracking-widest mb-8 flex items-center gap-3">
                 <ShieldCheck size={24} /> Log de Operações Bancárias
               </h3>
               <div className="space-y-4">
                  {auditLog.map(log => (
                    <div key={log.id} className="flex items-center gap-6 p-4 border-b border-stone-800 last:border-0">
                       <span className="text-[10px] font-black text-stone-500 uppercase whitespace-nowrap">{new Date(log.timestamp).toLocaleTimeString()}</span>
                       <div className="flex-1">
                          <p className="font-bold text-sm text-stone-200">{log.action}: {log.details}</p>
                          <p className="text-[10px] text-stone-500 font-bold uppercase">Operador: {log.userName}</p>
                       </div>
                    </div>
                  ))}
                  {auditLog.length === 0 && <p className="text-center py-10 text-stone-700 font-black uppercase text-xs">Nenhum registro de auditoria.</p>}
               </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL: CONECTAR BANCO */}
      {showConnectModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowConnectModal(false)}></div>
           <div className="bg-white w-full max-w-xl rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-stone-900 p-12 text-white">
                 <button onClick={() => setShowConnectModal(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white"><X size={24}/></button>
                 <div className="w-16 h-16 bg-amber-500 rounded-[2rem] flex items-center justify-center text-stone-900 mb-8 shadow-xl shadow-amber-500/20"><Landmark size={32} /></div>
                 <h2 className="text-4xl font-black tracking-tighter">Conectar Cora</h2>
                 <p className="text-stone-400 mt-2 font-medium">Integração para gestão de doações e mensalidades.</p>
              </div>

              <div className="p-12 space-y-8">
                 <div className="space-y-4">
                    <div className="flex items-start gap-4">
                       <div className="w-8 h-8 bg-amber-50 text-amber-600 rounded-lg flex items-center justify-center shrink-0 font-black">1</div>
                       <p className="text-sm text-stone-600 font-medium leading-relaxed">No MVP, a integração funciona via importação de arquivos de extrato gerados no seu aplicativo Cora.</p>
                    </div>
                    <div className="flex items-start gap-4">
                       <div className="w-8 h-8 bg-amber-50 text-amber-600 rounded-lg flex items-center justify-center shrink-0 font-black">2</div>
                       <p className="text-sm text-stone-600 font-medium leading-relaxed">Na versão completa SaaS, a conexão será automática via API oficial do banco.</p>
                    </div>
                 </div>

                 <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 flex items-center gap-4">
                    <ShieldCheck className="text-emerald-500 shrink-0" size={32} />
                    <p className="text-xs text-stone-500 font-bold uppercase leading-tight tracking-widest">Segurança Bancária Nível Enterprise. Seus dados nunca são compartilhados.</p>
                 </div>

                 <button 
                  onClick={handleConnectCora}
                  className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-stone-900/20 hover:scale-[1.02] transition-all"
                 >
                   Confirmar Conexão
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default BankReconciliationView;

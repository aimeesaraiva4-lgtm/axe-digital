import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, ShieldCheck, Zap, Calendar, ArrowRight, CheckCircle2, 
  AlertTriangle, Clock, History, FileText, Lock, Sparkles, X, Plus,
  QrCode, Copy, Upload, Check as CheckIcon, Smartphone, Mail, ChevronRight,
  ShieldAlert, Info, MessageCircle, DollarSign, Key, Shield, History as HistoryIcon,
  Trash2, UserCheck, AlertCircle
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Terreiro, SubscriptionStatus, SubscriptionData, SubscriptionPayment, VendorCode, VendorAudit } from '../types';

interface SubscriptionViewProps {
  terreiro: Terreiro;
  onUpdate: () => void;
}

/**
 * SEGURANÇA: Este é o código mestre para acessar o Painel do Fornecedor.
 * No mundo real, isso seria validado no Backend. 
 * Para este MVP/SaaS local, altere esta constante antes de distribuir o software.
 */
const VENDOR_MASTER_CODE = "ASE2026";

const SubscriptionView: React.FC<SubscriptionViewProps> = ({ terreiro, onUpdate }) => {
  const [sub, setSub] = useState<SubscriptionData | null>(null);
  const [payments, setPayments] = useState<SubscriptionPayment[]>([]);
  const [showToast, setShowToast] = useState<{show: boolean, msg: string, type: 'success' | 'error'}>({show: false, msg: '', type: 'success'});
  
  // Modais
  const [showPixModal, setShowPixModal] = useState(false);
  const [showProofModal, setShowProofModal] = useState(false);
  const [showVendorAuth, setShowVendorAuth] = useState(false);
  const [showVendorPanel, setShowVendorPanel] = useState(false);
  
  // State
  const [releaseCode, setReleaseCode] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);
  const [vendorMasterInput, setVendorMasterInput] = useState('');
  const [vendorCodes, setVendorCodes] = useState<VendorCode[]>([]);
  const [vendorAudit, setVendorAudit] = useState<VendorAudit[]>([]);

  // Dados do Fornecedor Asé Digital
  const support = JSON.parse(localStorage.getItem('ase_support') || '{"whatsapp":"5521967017236","email":"contato@asedigital.com.br"}');
  const providerPix = { 
    key: '21967017236', 
    receiver: 'Asé Digital', 
    city: 'Rio de Janeiro',
    description: 'Assinatura Asé Digital'
  };

  const tId = terreiro.id;

  useEffect(() => {
    const saved = localStorage.getItem(`ase_subscription_${tId}`);
    if (saved) setSub(JSON.parse(saved));

    const savedPayments = localStorage.getItem(`ase_subscription_payments_${tId}`);
    if (savedPayments) setPayments(JSON.parse(savedPayments));

    const savedCodes = localStorage.getItem('ase_vendor_codes');
    if (savedCodes) setVendorCodes(JSON.parse(savedCodes));

    const savedAudit = localStorage.getItem('ase_vendor_audit');
    if (savedAudit) setVendorAudit(JSON.parse(savedAudit));
  }, [tId]);

  const triggerToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setShowToast({show: true, msg, type});
    setTimeout(() => setShowToast({show: false, msg: '', type: 'success'}), 3000);
  };

  const persistSub = (newSub: SubscriptionData) => {
    localStorage.setItem(`ase_subscription_${tId}`, JSON.stringify(newSub));
    setSub(newSub);
    onUpdate();
  };

  const generatePixPayload = () => {
    const date = new Date();
    const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
    const desc = `${providerPix.description} - ${terreiro.name} - ${monthYear}`.substring(0, 50);
    
    const payload = [
      "000201",
      `26${String(30 + providerPix.key.length).padStart(2, '0')}0014br.gov.bcb.pix01${String(providerPix.key.length).padStart(2, '0')}${providerPix.key}`,
      "52040000",
      "5303986",
      `54${String((sub?.price || 79).toFixed(2).length).padStart(2, '0')}${(sub?.price || 79).toFixed(2)}`,
      "5802BR",
      `59${String(providerPix.receiver.length).padStart(2, '0')}${providerPix.receiver}`,
      `60${String(providerPix.city.length).padStart(2, '0')}${providerPix.city}`,
      `62${String(desc.length + 4).padStart(2, '0')}05${String(desc.length).padStart(2, '0')}${desc}`,
      "6304"
    ].join("");
    
    return payload + "DA42"; 
  };

  const handleApplyCode = () => {
    const codeObj = vendorCodes.find(c => c.code.toUpperCase() === releaseCode.toUpperCase() && !c.usedAt);
    
    if (codeObj) {
      const days = codeObj.days;
      const currentExpiry = sub ? new Date(sub.expiresAt) : new Date();
      const newExpiryDate = new Date(Math.max(currentExpiry.getTime(), Date.now()) + days * 24 * 60 * 60 * 1000);
      
      const newSub: SubscriptionData = {
        ...sub!,
        status: SubscriptionStatus.ACTIVE,
        expiresAt: newExpiryDate.toISOString(),
        lastPaymentDate: new Date().toISOString(),
        releaseCode: codeObj.code
      };
      
      // Marcar código como usado
      const updatedCodes = vendorCodes.map(c => 
        c.code === codeObj.code ? { ...c, usedAt: new Date().toISOString(), usedBy: tId } : c
      );
      localStorage.setItem('ase_vendor_codes', JSON.stringify(updatedCodes));
      setVendorCodes(updatedCodes);

      persistSub(newSub);
      setReleaseCode('');
      triggerToast(`Assinatura estendida em ${days} dias!`);
    } else {
      triggerToast("Código inválido, expirado ou já utilizado.", "error");
    }
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(generatePixPayload());
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  // Vendor Panel Handlers
  const handleVendorAuth = () => {
    if (vendorMasterInput === VENDOR_MASTER_CODE) {
      setShowVendorAuth(false);
      setShowVendorPanel(true);
      setVendorMasterInput('');
      triggerToast("Acesso autorizado");
    } else {
      triggerToast("Código mestre incorreto", "error");
    }
  };

  const generateVendorCode = (days: number) => {
    const code = `ASE-${days}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const newCode: VendorCode = {
      code,
      days,
      createdAt: new Date().toISOString(),
    };
    const updated = [newCode, ...vendorCodes];
    localStorage.setItem('ase_vendor_codes', JSON.stringify(updated));
    setVendorCodes(updated);
    triggerToast(`Código de ${days} dias gerado!`);
    
    // Audit
    const audit: VendorAudit = {
      id: Date.now().toString(),
      action: 'GERAR_CODIGO',
      at: new Date().toISOString(),
      userId: 'VENDOR_ADMIN',
      details: `Gerado código ${code} de ${days} dias`
    };
    const newAudit = [audit, ...vendorAudit].slice(0, 50);
    localStorage.setItem('ase_vendor_audit', JSON.stringify(newAudit));
    setVendorAudit(newAudit);
  };

  const handleConfirmPayment = (pId: string) => {
    const updatedPayments = payments.map(p => 
      p.id === pId ? { ...p, status: 'CONFIRMED' as const } : p
    );
    localStorage.setItem(`ase_subscription_payments_${tId}`, JSON.stringify(updatedPayments));
    setPayments(updatedPayments);
    triggerToast("Pagamento confirmado!");
  };

  const getStatusVisuals = (status: SubscriptionStatus) => {
    switch(status) {
      case SubscriptionStatus.BLOCKED: return { color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-200', icon: Lock, label: 'ACESSO BLOQUEADO' };
      case SubscriptionStatus.OVERDUE: return { color: 'text-rose-500', bg: 'bg-rose-50', border: 'border-rose-100', icon: AlertTriangle, label: 'PAGAMENTO ATRASADO' };
      case SubscriptionStatus.EXPIRING: return { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', icon: Clock, label: 'VENCE EM BREVE' };
      default: return { color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', icon: ShieldCheck, label: 'CONTA ATIVA' };
    }
  };

  if (!sub) return null;

  const visuals = getStatusVisuals(sub.status);
  const isBlocked = sub.status === SubscriptionStatus.BLOCKED;

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20 max-w-5xl mx-auto">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-amber-600 mb-1">
            <Zap size={18} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Painel de Licenciamento</span>
          </div>
          <h1 className="text-4xl font-black text-stone-900 tracking-tighter">Assinatura da Casa</h1>
          <p className="text-stone-500 font-medium">Controle de licença SaaS e histórico financeiro do fornecedor.</p>
        </div>
        <div className="flex items-center gap-3">
           <button 
             onClick={() => setShowVendorAuth(true)}
             className="text-[10px] font-black uppercase text-stone-300 hover:text-amber-600 transition-colors"
             title="Área restrita ao fornecedor"
           >
             Área do Fornecedor
           </button>
           <a href={`https://wa.me/${support.whatsapp}`} target="_blank" rel="noreferrer" className="bg-white border border-stone-200 text-stone-600 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-stone-50 transition-all">
             <MessageCircle size={18} /> Suporte Financeiro
           </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* MAIN STATUS COLUMN */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Status Card */}
          <div className={`p-10 rounded-[3.5rem] border transition-all shadow-sm ${visuals.bg} ${visuals.border}`}>
            <div className="flex justify-between items-start mb-10">
               <div className="space-y-1">
                  <p className={`text-[10px] font-black uppercase tracking-widest ${visuals.color}`}>{visuals.label}</p>
                  <div className="flex items-center gap-3">
                     <h2 className={`text-4xl font-black tracking-tighter ${visuals.color}`}>
                       {new Date(sub.expiresAt).toLocaleDateString()}
                     </h2>
                     <visuals.icon size={28} className={visuals.color} />
                  </div>
               </div>
               <div className="text-right">
                  <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Plano</p>
                  <span className="bg-stone-900 text-white px-4 py-1.5 rounded-full font-black text-[10px] uppercase tracking-widest mt-2 inline-block">
                    CASA DIGITAL (PRO)
                  </span>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="p-6 bg-white rounded-3xl border border-stone-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600">
                    <DollarSign size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Valor Mensal</p>
                    <p className="font-black text-stone-900">R$ {sub.price.toFixed(2)}</p>
                  </div>
               </div>
               <div className="p-6 bg-white rounded-3xl border border-stone-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-400">
                    <HistoryIcon size={24} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Último Pagamento</p>
                    <p className="font-black text-stone-900">{sub.lastPaymentDate ? new Date(sub.lastPaymentDate).toLocaleDateString() : 'Não registrado'}</p>
                  </div>
               </div>
            </div>

            <div className="mt-10 pt-10 border-t border-stone-200/50 flex flex-col md:flex-row items-center justify-between gap-6">
               <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-2xl ${isBlocked ? 'bg-rose-100 text-rose-600' : 'bg-white text-stone-400'}`}>
                    {isBlocked ? <ShieldAlert size={24}/> : <Info size={24}/>}
                  </div>
                  <p className="text-sm font-medium text-stone-500 max-w-xs leading-tight">
                    {isBlocked 
                      ? "O acesso total à unidade foi suspenso. Realize o pagamento via Pix." 
                      : "Sua conta está em conformidade. A renovação antecipada libera mais tempo de licença."}
                  </p>
               </div>
               <button 
                onClick={() => setShowPixModal(true)}
                className="bg-stone-900 text-white px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all w-full md:w-auto"
               >
                 Ver Pix para Pagamento
               </button>
            </div>
          </div>

          {/* Release Code */}
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
             <div>
                <h3 className="text-xl font-black text-stone-900 uppercase flex items-center gap-3 tracking-tight">
                  <Smartphone size={24} className="text-amber-500" /> Liberação via Código
                </h3>
                <p className="text-xs font-bold text-stone-400 mt-1 uppercase">Para liberação imediata via código do fornecedor.</p>
             </div>

             <div className="flex gap-4">
                <input 
                  type="text" 
                  placeholder="EX: ASE-30-XXXX"
                  className="flex-1 bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 font-black text-stone-900 tracking-widest outline-none focus:ring-4 focus:ring-amber-500/10 transition-all placeholder:text-stone-300"
                  value={releaseCode}
                  onChange={e => setReleaseCode(e.target.value)}
                />
                <button 
                  onClick={handleApplyCode}
                  className="bg-amber-500 text-stone-900 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-amber-400 active:scale-95 transition-all shadow-lg shadow-amber-500/20"
                >
                  Ativar Código
                </button>
             </div>
          </div>

          {/* Pagamentos Histórico */}
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
             <div className="flex items-center justify-between">
                <h3 className="text-xl font-black text-stone-900 uppercase flex items-center gap-3 tracking-tight">
                  <History size={24} className="text-amber-500" /> Histórico de Faturas
                </h3>
                <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Pagamentos Identificados</span>
             </div>

             <div className="divide-y divide-stone-50">
                {payments.length > 0 ? payments.map((p) => (
                  <div key={p.id} className="py-6 flex items-center justify-between group hover:bg-stone-50/50 transition-all rounded-2xl px-4">
                     <div className="flex items-center gap-5">
                        <div className="w-10 h-10 bg-stone-100 rounded-xl flex items-center justify-center text-stone-400">
                          <FileText size={20} />
                        </div>
                        <div>
                           <p className="font-black text-stone-900">Competência {p.competence}</p>
                           <p className="text-[10px] font-bold text-stone-400 uppercase tracking-tighter">{new Date(p.date).toLocaleDateString()} via {p.method}</p>
                        </div>
                     </div>
                     <div className="text-right flex items-center gap-8">
                        <p className="font-black text-stone-900 text-sm">R$ {p.amount.toFixed(2)}</p>
                        <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase ${
                          p.status === 'CONFIRMED' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                        }`}>{p.status}</span>
                     </div>
                  </div>
                )) : (
                  <div className="py-10 text-center text-stone-300">
                    <History size={48} className="mx-auto mb-4 opacity-10" />
                    <p className="font-bold text-xs uppercase tracking-widest">Nenhum pagamento registrado.</p>
                  </div>
                )}
             </div>
          </div>
        </div>

        {/* SIDEBAR */}
        <div className="space-y-8">
           <div className="bg-stone-900 p-8 rounded-[3rem] text-white space-y-10 shadow-2xl shadow-stone-900/20 relative overflow-hidden h-full flex flex-col">
             <div className="absolute top-0 right-0 p-6 text-white/5 pointer-events-none"><Sparkles size={120} /></div>
             
             <div>
                <h3 className="text-2xl font-black tracking-tight text-amber-500">Já efetuou o Pix?</h3>
                <p className="text-stone-400 text-sm mt-1">Anexe o comprovante abaixo para conferência.</p>
             </div>

             <div className="space-y-4 flex-1">
                <button 
                  onClick={() => setShowProofModal(true)}
                  className="w-full p-6 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-left flex items-center gap-4 group"
                >
                   <div className="w-12 h-12 bg-amber-500 text-stone-900 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Upload size={24} />
                   </div>
                   <div>
                      <h4 className="font-black text-xs uppercase tracking-widest">Enviar Comprovante</h4>
                      <p className="text-[10px] text-stone-500 font-bold uppercase mt-0.5">Anexo para análise</p>
                   </div>
                </button>

                <a 
                  href={`https://wa.me/${support.whatsapp}?text=${encodeURIComponent(`Olá! Estou enviando o comprovante da assinatura do terreiro ${terreiro.name}.\nValor: R$ ${sub.price}\nChave Pix: ${providerPix.key}`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full p-6 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-left flex items-center gap-4 group"
                >
                   <div className="w-12 h-12 bg-emerald-500 text-white rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <MessageCircle size={24} />
                   </div>
                   <div>
                      <h4 className="font-black text-xs uppercase tracking-widest">WhatsApp Direto</h4>
                      <p className="text-[10px] text-stone-500 font-bold uppercase mt-0.5">Falar com Financeiro</p>
                   </div>
                </a>
             </div>

             <div className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-4">
                <h5 className="text-[10px] font-black text-amber-500 uppercase tracking-widest flex items-center gap-2">
                  <Info size={14} /> Regra de Liberação
                </h5>
                <p className="text-[10px] text-stone-400 leading-relaxed font-medium uppercase">
                  Pagamentos confirmados liberam o sistema em até 2 horas. Caso utilize um código de revendedor, a liberação é instantânea.
                </p>
             </div>
           </div>
        </div>
      </div>

      {/* MODAL: PIX */}
      {showPixModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowPixModal(false)}></div>
           <div className="bg-white w-full max-w-lg rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-stone-900 p-12 text-white relative text-center">
                 <button onClick={() => setShowPixModal(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white"><X size={24}/></button>
                 <div className="w-16 h-16 bg-amber-500 rounded-2xl flex items-center justify-center text-stone-900 mb-8 mx-auto shadow-xl"><QrCode size={32} /></div>
                 <h2 className="text-3xl font-black tracking-tighter">Pagar Licença</h2>
              </div>

              <div className="p-12 space-y-8 flex flex-col items-center">
                 <div className="bg-stone-50 p-6 rounded-[3rem] border-2 border-stone-100">
                   <QRCodeSVG value={generatePixPayload()} size={220} level="M" />
                 </div>

                 <div className="w-full space-y-6">
                    <div className="space-y-1 text-center">
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Valor da Mensalidade</p>
                       <p className="text-4xl font-black text-stone-900">R$ {sub.price.toFixed(2)}</p>
                    </div>

                    <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 space-y-4">
                       <div className="text-center">
                          <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Chave Pix</p>
                          <p className="font-black text-stone-900 text-lg uppercase">{providerPix.key}</p>
                       </div>
                    </div>

                    <button 
                      onClick={handleCopyPix}
                      className={`w-full py-5 rounded-3xl font-black text-sm uppercase tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 ${
                        copySuccess ? 'bg-emerald-500 text-white' : 'bg-stone-900 text-white hover:scale-[1.02]'
                      }`}
                    >
                      {copySuccess ? <><CheckIcon size={20} /> Copiado!</> : <><Copy size={20} /> Pix Copia e Cola</>}
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* MODAL: ENVIO DE COMPROVANTE */}
      {showProofModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-md" onClick={() => setShowProofModal(false)}></div>
           <div className="bg-white w-full max-w-lg rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="bg-stone-900 p-12 text-white">
                 <button onClick={() => setShowProofModal(false)} className="absolute top-10 right-10 text-stone-500 hover:text-white"><X size={24}/></button>
                 <h2 className="text-3xl font-black tracking-tighter">Registrar Pagamento</h2>
                 <p className="text-stone-400 mt-2 font-medium">Lançamento de comprovante para conciliação manual.</p>
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const newPay: SubscriptionPayment = {
                   id: Date.now().toString(),
                   terreiroId: tId,
                   competence: fd.get('competence') as string,
                   amount: sub.price,
                   method: 'PIX',
                   date: new Date().toISOString(),
                   status: 'PENDING'
                };
                const updated = [newPay, ...payments];
                localStorage.setItem(`ase_subscription_payments_${tId}`, JSON.stringify(updated));
                setPayments(updated);
                setShowProofModal(false);
                triggerToast("Comprovante enviado para análise!");
              }} className="p-12 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400">Competência (Mês/Ano)</label>
                    <input type="text" name="competence" required placeholder="Ex: 05/2024" className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 font-bold outline-none" />
                 </div>
                 <div className="border-2 border-dashed border-stone-200 p-10 rounded-[3rem] flex flex-col items-center justify-center text-center space-y-4 hover:border-amber-500 transition-colors cursor-pointer group">
                    <Upload size={32} className="text-stone-300 group-hover:text-amber-500" />
                    <div>
                      <p className="font-bold text-stone-900 text-sm">Anexar Comprovante</p>
                      <p className="text-[10px] text-stone-500 font-bold uppercase">PDF ou JPG</p>
                    </div>
                 </div>
                 <button type="submit" className="w-full py-5 bg-stone-900 text-white rounded-3xl font-black text-sm uppercase tracking-widest shadow-2xl">Confirmar Lançamento</button>
              </form>
           </div>
        </div>
      )}

      {/* VENDOR AUTH MODAL */}
      {showVendorAuth && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/90 backdrop-blur-md" onClick={() => setShowVendorAuth(false)}></div>
           <div className="bg-white w-full max-w-sm rounded-[3rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 p-10">
              <div className="text-center space-y-6">
                 <div className="w-16 h-16 bg-amber-500 text-stone-900 rounded-2xl flex items-center justify-center mx-auto shadow-xl"><Shield size={32} /></div>
                 <h2 className="text-2xl font-black text-stone-900 tracking-tighter">Área Restrita</h2>
                 <p className="text-stone-500 text-sm font-medium">Insira o Código Mestre de Fornecedor para prosseguir.</p>
                 <input 
                  type="password" 
                  autoFocus
                  placeholder="••••••••"
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl p-4 text-center font-black tracking-[0.5em] outline-none focus:ring-4 focus:ring-amber-500/10 placeholder:tracking-normal"
                  value={vendorMasterInput}
                  onChange={e => setVendorMasterInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleVendorAuth()}
                 />
                 <div className="flex gap-3">
                    <button 
                      onClick={() => setShowVendorAuth(false)}
                      className="flex-1 py-4 bg-stone-100 text-stone-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-stone-200 transition-all"
                    >
                      Cancelar
                    </button>
                    <button 
                      onClick={handleVendorAuth}
                      className="flex-[2] py-4 bg-stone-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-stone-800 transition-all shadow-lg"
                    >
                      Acessar Painel
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* VENDOR PANEL MODAL */}
      {showVendorPanel && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-stone-900/95 backdrop-blur-xl" onClick={() => setShowVendorPanel(false)}></div>
           <div className="bg-white w-full max-w-5xl h-[85vh] rounded-[4rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col">
              <div className="bg-stone-900 p-10 text-white flex justify-between items-center shrink-0">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-amber-500 text-stone-900 rounded-xl flex items-center justify-center"><Zap size={24} /></div>
                    <div>
                       <h2 className="text-2xl font-black tracking-tighter leading-tight">Painel do Fornecedor Asé</h2>
                       <p className="text-stone-500 text-[10px] font-black uppercase tracking-widest mt-0.5">Gestão Global de Assinaturas</p>
                    </div>
                 </div>
                 <button onClick={() => setShowVendorPanel(false)} className="bg-white/5 p-3 rounded-2xl hover:bg-white/10 text-white transition-all"><X size={24}/></button>
              </div>

              <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
                 {/* Left: Operations */}
                 <div className="flex-1 p-10 overflow-y-auto space-y-10 custom-scrollbar">
                    <section className="space-y-6">
                       <h3 className="text-xs font-black text-stone-400 uppercase tracking-[0.2em] flex items-center gap-2">
                         <Plus size={14}/> Gerar Códigos de Liberação
                       </h3>
                       <div className="grid grid-cols-3 gap-4">
                          <button onClick={() => generateVendorCode(30)} className="p-8 rounded-[2.5rem] bg-stone-50 border border-stone-100 hover:border-amber-500 transition-all text-center group shadow-sm hover:shadow-xl hover:shadow-amber-500/5">
                             <p className="text-3xl font-black text-stone-900 group-hover:text-amber-600 transition-colors">30</p>
                             <p className="text-[10px] font-black text-stone-400 uppercase mt-1">Dias</p>
                          </button>
                          <button onClick={() => generateVendorCode(60)} className="p-8 rounded-[2.5rem] bg-stone-50 border border-stone-100 hover:border-amber-500 transition-all text-center group shadow-sm hover:shadow-xl hover:shadow-amber-500/5">
                             <p className="text-3xl font-black text-stone-900 group-hover:text-amber-600 transition-colors">60</p>
                             <p className="text-[10px] font-black text-stone-400 uppercase mt-1">Dias</p>
                          </button>
                          <button onClick={() => generateVendorCode(90)} className="p-8 rounded-[2.5rem] bg-stone-50 border border-stone-100 hover:border-amber-500 transition-all text-center group shadow-sm hover:shadow-xl hover:shadow-amber-500/5">
                             <p className="text-3xl font-black text-stone-900 group-hover:text-amber-600 transition-colors">90</p>
                             <p className="text-[10px] font-black text-stone-400 uppercase mt-1">Dias</p>
                          </button>
                       </div>
                    </section>

                    <section className="space-y-6">
                       <div className="flex items-center justify-between">
                          <h3 className="text-xs font-black text-stone-400 uppercase tracking-[0.2em]">Faturas Pendentes (Cliente Ativo)</h3>
                          <span className="text-[9px] font-black bg-amber-50 text-amber-600 px-3 py-1 rounded-full uppercase">{payments.filter(p => p.status === 'PENDING').length} AGUARDANDO</span>
                       </div>
                       <div className="space-y-3">
                          {payments.filter(p => p.status === 'PENDING').map(p => (
                            <div key={p.id} className="p-6 bg-white border border-stone-100 rounded-3xl flex items-center justify-between hover:border-amber-500 transition-all">
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center text-stone-300"><FileText size={20}/></div>
                                  <div>
                                     <p className="font-black text-stone-900 text-sm">{p.competence} • R$ {p.amount.toFixed(2)}</p>
                                     <p className="text-[10px] font-bold text-stone-400 uppercase">{new Date(p.date).toLocaleString()}</p>
                                  </div>
                               </div>
                               <div className="flex gap-2">
                                  <button onClick={() => handleConfirmPayment(p.id)} className="px-6 py-2.5 bg-emerald-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-emerald-500/20">Confirmar</button>
                                  <button className="p-2.5 bg-stone-50 text-stone-400 rounded-xl hover:text-rose-500 transition-all"><X size={18}/></button>
                               </div>
                            </div>
                          ))}
                          {payments.filter(p => p.status === 'PENDING').length === 0 && (
                            <div className="p-10 text-center bg-stone-50 rounded-3xl border border-dashed border-stone-200">
                               <p className="text-xs font-bold text-stone-400 uppercase">Nenhum comprovante pendente de análise.</p>
                            </div>
                          )}
                       </div>
                    </section>
                 </div>

                 {/* Right: History/Log */}
                 <div className="w-full lg:w-96 bg-stone-50 p-10 border-l border-stone-100 overflow-y-auto custom-scrollbar">
                    <section className="space-y-8">
                       <div>
                          <h3 className="text-xs font-black text-stone-900 uppercase tracking-widest flex items-center gap-2">
                            <Key size={14}/> Códigos Ativos
                          </h3>
                          <div className="mt-6 space-y-3">
                             {vendorCodes.slice(0, 15).map((c, i) => (
                               <div key={i} className={`p-4 rounded-2xl border bg-white flex flex-col gap-2 ${c.usedAt ? 'opacity-40' : 'border-amber-200 shadow-sm'}`}>
                                  <div className="flex justify-between items-center">
                                     <span className="font-black text-sm tracking-widest">{c.code}</span>
                                     <span className="text-[8px] font-black px-2 py-0.5 rounded-full bg-stone-900 text-white uppercase">{c.days}D</span>
                                  </div>
                                  <div className="flex justify-between items-center text-[9px] font-bold text-stone-400 uppercase">
                                     <span>Criado {new Date(c.createdAt).toLocaleDateString()}</span>
                                     {c.usedAt ? <span className="text-emerald-600 flex items-center gap-1"><CheckIcon size={10}/> USADO</span> : <span className="text-amber-600">DISPONÍVEL</span>}
                                  </div>
                               </div>
                             ))}
                             {vendorCodes.length === 0 && (
                               <p className="text-xs text-stone-400 text-center py-4">Nenhum código gerado.</p>
                             )}
                          </div>
                       </div>

                       <div>
                          <h3 className="text-xs font-black text-stone-900 uppercase tracking-widest flex items-center gap-2">
                            <HistoryIcon size={14}/> Log de Auditoria
                          </h3>
                          <div className="mt-6 space-y-4">
                             {vendorAudit.map(a => (
                               <div key={a.id} className="text-[10px] leading-tight space-y-1">
                                  <p className="text-stone-400 font-black">{new Date(a.at).toLocaleString()}</p>
                                  <p className="font-bold text-stone-900 uppercase">{a.action}: {a.details}</p>
                               </div>
                             ))}
                          </div>
                       </div>
                    </section>
                 </div>
              </div>

              <div className="p-8 border-t border-stone-100 bg-amber-50 flex items-center justify-center gap-4 text-center shrink-0">
                 <AlertCircle className="text-amber-600" size={18} />
                 <p className="text-[10px] font-black text-amber-900 uppercase tracking-widest">
                   Segurança: Altere a constante <code className="bg-amber-100 px-1 rounded">VENDOR_MASTER_CODE</code> no arquivo do componente antes de distribuir comercialmente.
                 </p>
              </div>
           </div>
        </div>
      )}

      {/* TOAST FEEDBACK */}
      {showToast.show && (
        <div className="fixed bottom-10 right-10 z-[150] animate-in slide-in-from-right-10 duration-500">
           <div className={`text-white px-8 py-4 rounded-3xl shadow-2xl flex items-center gap-4 border ${
             showToast.type === 'success' ? 'bg-stone-900 border-stone-800' : 'bg-rose-600 border-rose-700'
           }`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${showToast.type === 'success' ? 'bg-amber-500 text-stone-900' : 'bg-white text-rose-600'}`}>
                 {showToast.type === 'success' ? <CheckIcon size={24} /> : <X size={24} />}
              </div>
              <div>
                 <p className="font-black text-sm tracking-tight">{showToast.type === 'success' ? 'Sucesso!' : 'Ação'}</p>
                 <p className="opacity-70 text-xs font-medium">{showToast.msg}</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionView;
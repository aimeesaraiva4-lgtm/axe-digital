
import React, { useState, useEffect, useMemo } from 'react';
import { 
  CalendarDays, PlusCircle, Search, Filter, Clock, MapPin, 
  ChevronRight, ArrowLeft, Trash2, Edit2, CheckCircle2, 
  XCircle, UserCheck, AlertCircle, Info, X, Calendar, QrCode, RefreshCw
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  AgendaEvent, AgendaEventType, AgendaEventStatus, 
  EventAttendance, UserRole, MediumProfile, MembershipStatus 
} from '../types';

interface AgendaViewProps {
  user: MediumProfile;
  mediums: MediumProfile[];
}

const AgendaView: React.FC<AgendaViewProps> = ({ user, mediums }) => {
  const [events, setEvents] = useState<AgendaEvent[]>([]);
  const [attendances, setAttendances] = useState<EventAttendance[]>([]);
  const [activeTab, setActiveTab] = useState<'lista' | 'novo' | 'detalhes'>('lista');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<AgendaEventType | 'TODOS'>('TODOS');
  const [showQrModal, setShowQrModal] = useState(false);
  const [activeToken, setActiveToken] = useState<{ token: string, expiresAt: string } | null>(null);
  
  const [newEvent, setNewEvent] = useState<Partial<AgendaEvent>>({
    type: AgendaEventType.GIRA,
    status: AgendaEventStatus.SCHEDULED,
    date: new Date().toISOString().split('T')[0],
    time: '19:30',
    location: 'Sede Principal'
  });

  const isMaster = user.role === UserRole.MASTER;
  const tId = user.terreiroId;

  // Carregar dados
  useEffect(() => {
    const savedEvents = localStorage.getItem(`ase_agenda_${tId}`);
    const savedAttendances = localStorage.getItem(`ase_attendance_${tId}`);
    if (savedEvents) setEvents(JSON.parse(savedEvents));
    if (savedAttendances) setAttendances(JSON.parse(savedAttendances));
  }, [tId]);

  // Persistência
  const saveEvents = (updated: AgendaEvent[]) => {
    localStorage.setItem(`ase_agenda_${tId}`, JSON.stringify(updated));
    setEvents(updated);
  };

  const saveAttendances = (updated: EventAttendance[]) => {
    localStorage.setItem(`ase_attendance_${tId}`, JSON.stringify(updated));
    setAttendances(updated);
  };

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.time) return alert("Preencha os campos obrigatórios");

    const event: AgendaEvent = {
      id: `EV-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      terreiroId: tId,
      type: newEvent.type as AgendaEventType,
      title: newEvent.title,
      workLine: newEvent.workLine,
      date: newEvent.date!,
      time: newEvent.time!,
      location: newEvent.location || 'Sede Principal',
      notes: newEvent.notes,
      status: AgendaEventStatus.SCHEDULED
    };

    const updated = [event, ...events].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    saveEvents(updated);
    setActiveTab('lista');
    setNewEvent({
      type: AgendaEventType.GIRA,
      status: AgendaEventStatus.SCHEDULED,
      date: new Date().toISOString().split('T')[0],
      time: '19:30',
      location: 'Sede Principal'
    });
  };

  const handleToggleAttendance = (eventId: string) => {
    const exists = attendances.find(a => a.eventId === eventId && a.userId === user.id);
    if (exists) {
      const updated = attendances.filter(a => !(a.eventId === eventId && a.userId === user.id));
      saveAttendances(updated);
    } else {
      const newAttendance: EventAttendance = {
        id: `ATT-${Date.now()}`,
        eventId,
        userId: user.id,
        userName: user.fullName,
        confirmedAt: new Date().toISOString()
      };
      saveAttendances([...attendances, newAttendance]);
    }
  };

  const handleDeleteEvent = (id: string) => {
    if (confirm("Deseja realmente excluir este evento? Isso removerá todas as presenças vinculadas.")) {
      const updated = events.filter(e => e.id !== id);
      const updatedAtt = attendances.filter(a => a.eventId !== id);
      saveEvents(updated);
      saveAttendances(updatedAtt);
    }
  };

  const handleGenerateQrToken = (eventId: string) => {
    const token = `${tId}:${eventId}:${Date.now()}:${Math.random().toString(36).substr(2, 5)}`;
    const expiresAt = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(); // 6 hours from now
    
    const tokens = JSON.parse(localStorage.getItem(`ase_tokens_${tId}`) || '{}');
    tokens[eventId] = { token, expiresAt };
    localStorage.setItem(`ase_tokens_${tId}`, JSON.stringify(tokens));
    
    setActiveToken({ token, expiresAt });
    setShowQrModal(true);
  };

  const selectedEvent = useMemo(() => events.find(e => e.id === selectedEventId), [events, selectedEventId]);

  const filteredEvents = useMemo(() => {
    return events.filter(e => {
      const matchesSearch = e.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          e.workLine?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'TODOS' || e.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [events, searchTerm, filterType]);

  const eventStats = (eventId: string) => {
    const confirmed = attendances.filter(a => a.eventId === eventId).length;
    const totalMediums = mediums.filter(m => m.status === MembershipStatus.ACTIVE).length;
    return { confirmed, totalMediums, absent: totalMediums - confirmed };
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tighter">Agenda do Terreiro</h1>
          <p className="text-stone-500 font-medium">Giras, reuniões e obrigações da casa</p>
        </div>
        
        {activeTab === 'lista' && isMaster && (
          <button 
            onClick={() => setActiveTab('novo')}
            className="bg-stone-900 text-white px-8 py-3 rounded-2xl font-black text-sm flex items-center gap-2 shadow-xl shadow-stone-900/10 hover:scale-105 transition-all"
          >
            <PlusCircle size={20} /> Agendar Evento
          </button>
        )}
      </div>

      {activeTab === 'lista' && (
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
              <input 
                type="text" 
                placeholder="Buscar por título ou linha..." 
                className="w-full pl-12 pr-4 py-4 bg-white border border-stone-200 rounded-[2rem] text-sm outline-none focus:ring-2 focus:ring-amber-500/20"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex bg-white p-1 rounded-2xl border border-stone-200 shadow-sm overflow-x-auto scrollbar-hide">
              {['TODOS', ...Object.values(AgendaEventType)].map(type => (
                <button
                  key={type}
                  onClick={() => setFilterType(type as any)}
                  className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                    filterType === type 
                      ? 'bg-stone-900 text-white shadow-md' 
                      : 'text-stone-400 hover:text-stone-900'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map(event => {
              const stats = eventStats(event.id);
              const isConfirmed = attendances.some(a => a.eventId === event.id && a.userId === user.id);
              const isPast = new Date(`${event.date}T${event.time}`) < new Date();

              return (
                <div 
                  key={event.id} 
                  className={`bg-white rounded-[2.5rem] border-2 transition-all p-8 flex flex-col justify-between group ${
                    isPast ? 'opacity-60 border-stone-100 grayscale' : 'border-stone-100 hover:border-amber-500 shadow-sm'
                  }`}
                >
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <span className="text-[9px] font-black bg-stone-100 text-stone-500 px-3 py-1 rounded-full uppercase tracking-widest">
                        {event.type}
                      </span>
                      {isMaster && (
                        <button 
                          onClick={() => handleDeleteEvent(event.id)}
                          className="text-stone-300 hover:text-rose-500 transition-colors p-1"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>

                    <div className="space-y-1">
                      <h3 className="text-xl font-black text-stone-900 tracking-tight leading-tight group-hover:text-amber-600 transition-colors">{event.title}</h3>
                      {event.workLine && <p className="text-xs font-bold text-stone-400 uppercase tracking-wider">{event.workLine}</p>}
                    </div>

                    <div className="space-y-2 pt-2">
                      <div className="flex items-center gap-2 text-stone-500 font-bold text-xs">
                        <Clock size={14} className="text-amber-500" />
                        {new Date(event.date + 'T' + event.time).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long' })} às {event.time}
                      </div>
                      <div className="flex items-center gap-2 text-stone-500 font-bold text-xs">
                        <MapPin size={14} className="text-amber-500" />
                        {event.location}
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-6 border-t border-stone-50 flex items-center justify-between">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="w-6 h-6 rounded-full bg-stone-200 border-2 border-white flex items-center justify-center text-[8px] font-black">
                          {i}
                        </div>
                      ))}
                      {stats.confirmed > 3 && <div className="text-[8px] font-black text-stone-400 pl-4">+{stats.confirmed - 3}</div>}
                    </div>
                    
                    <button 
                      onClick={() => { setSelectedEventId(event.id); setActiveTab('detalhes'); }}
                      className="text-[10px] font-black uppercase text-amber-600 tracking-widest hover:underline flex items-center gap-1"
                    >
                      Ver Detalhes <ChevronRight size={14} />
                    </button>
                  </div>
                  
                  {!isPast && (
                    <button 
                      onClick={() => handleToggleAttendance(event.id)}
                      className={`w-full mt-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                        isConfirmed 
                          ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                          : 'bg-stone-50 text-stone-400 hover:bg-stone-900 hover:text-white'
                      }`}
                    >
                      {isConfirmed ? 'Presença Confirmada' : 'Confirmar Presença'}
                    </button>
                  )}
                </div>
              );
            })}
            
            {filteredEvents.length === 0 && (
              <div className="col-span-full py-20 bg-white rounded-[3rem] border-2 border-dashed border-stone-200 flex flex-col items-center justify-center text-stone-300">
                <CalendarDays size={48} className="mb-4 opacity-20" />
                <p className="font-bold">Nenhum evento agendado para esta busca.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'novo' && (
        <div className="max-w-2xl mx-auto animate-in slide-in-from-bottom-4 duration-500">
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-8">
            <div className="flex items-center gap-4">
              <button onClick={() => setActiveTab('lista')} className="p-3 bg-stone-50 rounded-2xl text-stone-400 hover:text-stone-900 transition-all">
                <ArrowLeft size={20} />
              </button>
              <h2 className="text-2xl font-black text-stone-900 tracking-tighter">Agendar Novo Evento</h2>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Título do Evento</label>
                <input 
                  type="text" 
                  placeholder="Ex: Gira de Pretos Velhos"
                  className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm focus:ring-4 focus:ring-amber-500/10 outline-none font-bold"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Tipo</label>
                  <select 
                    className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm font-bold outline-none"
                    value={newEvent.type}
                    onChange={(e) => setNewEvent({...newEvent, type: e.target.value as AgendaEventType})}
                  >
                    {Object.values(AgendaEventType).map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Linha de Trabalho</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Almas / Caridade"
                    className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none font-bold"
                    value={newEvent.workLine}
                    onChange={(e) => setNewEvent({...newEvent, workLine: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Data</label>
                  <input 
                    type="date" 
                    className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none font-bold"
                    value={newEvent.date}
                    onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Hora</label>
                  <input 
                    type="time" 
                    className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none font-bold"
                    value={newEvent.time}
                    onChange={(e) => setNewEvent({...newEvent, time: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Local</label>
                <input 
                  type="text" 
                  className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none font-bold"
                  value={newEvent.location}
                  onChange={(e) => setNewEvent({...newEvent, location: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Observações (opcional)</label>
                <textarea 
                  className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none font-bold h-32"
                  placeholder="Instruções para a corrente..."
                  value={newEvent.notes}
                  onChange={(e) => setNewEvent({...newEvent, notes: e.target.value})}
                />
              </div>

              <button 
                onClick={handleAddEvent}
                className="w-full py-5 bg-stone-900 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-stone-900/20 hover:scale-[1.02] active:scale-95 transition-all"
              >
                Confirmar Agendamento
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'detalhes' && selectedEvent && (
        <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-right-4 duration-500">
          <button onClick={() => setActiveTab('lista')} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm">
            <ArrowLeft size={16} /> Voltar para Agenda
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Event Info */}
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-10 right-10">
                   <span className="text-[10px] font-black bg-amber-500 text-stone-900 px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg shadow-amber-500/20">
                    {selectedEvent.type}
                   </span>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h2 className="text-4xl font-black text-stone-900 tracking-tighter leading-tight">{selectedEvent.title}</h2>
                    {selectedEvent.workLine && <p className="text-amber-600 font-black text-sm uppercase mt-1 tracking-widest">{selectedEvent.workLine}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-6 pt-4 border-t border-stone-50">
                    <div className="flex items-center gap-3">
                       <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center text-amber-500 shadow-inner">
                          <Calendar size={24} />
                       </div>
                       <div>
                         <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Data</p>
                         <p className="font-bold text-stone-900">{new Date(selectedEvent.date + 'T12:00:00').toLocaleDateString()}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-3">
                       <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center text-amber-500 shadow-inner">
                          <Clock size={24} />
                       </div>
                       <div>
                         <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Horário</p>
                         <p className="font-bold text-stone-900">{selectedEvent.time}</p>
                       </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                     <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center text-amber-500 shadow-inner">
                        <MapPin size={24} />
                     </div>
                     <div>
                       <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Localização</p>
                       <p className="font-bold text-stone-900">{selectedEvent.location}</p>
                     </div>
                  </div>

                  {selectedEvent.notes && (
                    <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100">
                      <p className="text-[10px] font-black text-stone-400 uppercase mb-2 flex items-center gap-2">
                        <Info size={12} /> Instruções e Notas
                      </p>
                      <p className="text-sm font-medium text-stone-700 leading-relaxed whitespace-pre-line">{selectedEvent.notes}</p>
                    </div>
                  )}

                  <div className="flex flex-col gap-4">
                    <div className="flex gap-4">
                      <button 
                        onClick={() => handleToggleAttendance(selectedEvent.id)}
                        className={`flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${
                          attendances.some(a => a.eventId === selectedEvent.id && a.userId === user.id)
                            ? 'bg-emerald-500 text-white shadow-xl shadow-emerald-500/20'
                            : 'bg-stone-900 text-white hover:bg-stone-800'
                        }`}
                      >
                        {attendances.some(a => a.eventId === selectedEvent.id && a.userId === user.id) ? 'Vou participar!' : 'Confirmar minha Presença'}
                      </button>
                      {isMaster && (
                         <button className="p-4 bg-stone-100 text-stone-400 rounded-2xl hover:text-stone-900 transition-all"><Edit2 size={24}/></button>
                      )}
                    </div>
                    
                    {isMaster && (
                      <button 
                        onClick={() => handleGenerateQrToken(selectedEvent.id)}
                        className="w-full py-4 bg-amber-500 text-stone-900 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 hover:bg-amber-400 transition-all"
                      >
                        <QrCode size={20} /> Gerar QR de Presença
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Attendance List */}
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <h4 className="font-black text-stone-900 flex items-center gap-2 text-sm uppercase tracking-widest">
                    <UserCheck size={18} className="text-amber-500" /> Corrente Confirmada
                  </h4>
                  <span className="text-[10px] font-black bg-stone-100 text-stone-400 px-3 py-1 rounded-full uppercase">
                    {attendances.filter(a => a.eventId === selectedEvent.id).length} Confirmed
                  </span>
                </div>

                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 scrollbar-hide">
                  {attendances.filter(a => a.eventId === selectedEvent.id).map(att => (
                    <div key={att.id} className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100 animate-in fade-in">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center font-black text-stone-400 border border-stone-200">
                          {att.userName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-stone-900 text-sm">{att.userName}</p>
                          <p className="text-[9px] text-stone-400 font-black uppercase">Confirmado às {new Date(att.confirmedAt).toLocaleTimeString()}</p>
                        </div>
                      </div>
                      <CheckCircle2 size={16} className="text-emerald-500" />
                    </div>
                  ))}
                  
                  {attendances.filter(a => a.eventId === selectedEvent.id).length === 0 && (
                    <div className="text-center py-12 text-stone-300">
                      <Clock size={48} className="mx-auto mb-4 opacity-10" />
                      <p className="font-bold text-xs uppercase tracking-widest">Aguardando confirmações</p>
                    </div>
                  )}
                </div>
              </div>
              
              {isMaster && (
                <div className="bg-amber-50 p-8 rounded-[3rem] border border-amber-100 text-amber-900">
                  <h4 className="font-black uppercase text-[10px] tracking-widest mb-2 flex items-center gap-2">
                    <AlertCircle size={14} /> Resumo Administrativo
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm font-bold">
                       <span>Total Médiuns</span>
                       <span>{mediums.filter(m => m.status === MembershipStatus.ACTIVE).length}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm font-bold">
                       <span>Confirmados</span>
                       <span>{attendances.filter(a => a.eventId === selectedEvent.id).length}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm font-bold text-rose-600">
                       <span>Ausentes</span>
                       <span>{mediums.filter(m => m.status === MembershipStatus.ACTIVE).length - attendances.filter(a => a.eventId === selectedEvent.id).length}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {showQrModal && activeToken && selectedEvent && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-stone-900/80 backdrop-blur-sm" onClick={() => setShowQrModal(false)}></div>
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="bg-stone-900 p-8 text-white text-center">
              <button onClick={() => setShowQrModal(false)} className="absolute top-6 right-6 text-white/40 hover:text-white transition-colors">
                <X size={24} />
              </button>
              <h3 className="text-xl font-black tracking-tight">{selectedEvent.title}</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-amber-500 mt-1">QR Code de Presença</p>
            </div>
            
            <div className="p-8 flex flex-col items-center space-y-6">
              <div className="bg-stone-50 p-6 rounded-[2.5rem] border-2 border-stone-100">
                <QRCodeSVG 
                  value={activeToken.token}
                  size={240}
                  level="H"
                  includeMargin={true}
                />
              </div>
              
              <div className="text-center space-y-1">
                <p className="text-stone-500 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2">
                  <Clock size={12} /> Válido até {new Date(activeToken.expiresAt).toLocaleTimeString()}
                </p>
                <p className="text-[10px] text-stone-400 font-medium">Os médiuns devem escanear pela aba "Presença QR".</p>
              </div>

              <div className="flex gap-3 w-full pt-4">
                <button 
                  onClick={() => handleGenerateQrToken(selectedEvent.id)}
                  className="flex-1 py-4 bg-stone-100 text-stone-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-stone-200 transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw size={14} /> Regenerar
                </button>
                <button 
                  onClick={() => setShowQrModal(false)}
                  className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-stone-800 transition-all"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgendaView;

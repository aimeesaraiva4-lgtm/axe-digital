
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Shield, Heart, Sparkles, FileText, User, Camera, AlertCircle, DollarSign, Calendar, Info } from 'lucide-react';
import { MediumProfile, UserRole } from '../types';

interface FichaProps {
  mediumId: string;
  currentUserId: string;
  isMaster: boolean;
  onBack?: () => void;
}

const MediumFichaForm: React.FC<FichaProps> = ({ mediumId, currentUserId, isMaster, onBack }) => {
  const [activeSection, setActiveSection] = useState('pessoal');
  const [medium, setMedium] = useState<MediumProfile | null>(null);

  useEffect(() => {
    const tId = JSON.parse(localStorage.getItem('ase_terreiro') || '{}').id;
    const mediums = JSON.parse(localStorage.getItem(`ase_mediums_${tId}`) || '[]');
    const found = mediums.find((m: MediumProfile) => m.id === mediumId);
    if (found) setMedium(found);
  }, [mediumId]);

  const handleSave = () => {
    if (!medium) return;
    const tId = JSON.parse(localStorage.getItem('ase_terreiro') || '{}').id;
    const mediums = JSON.parse(localStorage.getItem(`ase_mediums_${tId}`) || '[]');
    const index = mediums.findIndex((m: MediumProfile) => m.id === mediumId);
    
    if (index !== -1) {
      mediums[index] = medium;
      localStorage.setItem(`ase_mediums_${tId}`, JSON.stringify(mediums));
      alert("Ficha salva com sucesso!");
    }
  };

  const sections = [
    { id: 'pessoal', label: 'Dados Pessoais', icon: User },
    { id: 'saude', label: 'Saúde e Emergência', icon: Heart },
    { id: 'espiritual', label: 'Dados Espirituais', icon: Sparkles },
    { id: 'financeiro', label: 'Plano Financeiro', icon: DollarSign },
    { id: 'documentos', label: 'Documentos', icon: FileText },
  ];

  if (!medium) return <div>Carregando...</div>;

  return (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          {onBack && (
            <button onClick={onBack} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-bold text-sm mb-2">
              <ArrowLeft size={16} /> Voltar para lista
            </button>
          )}
          <h2 className="text-3xl font-black text-stone-900 tracking-tighter">Ficha do Médium</h2>
          <p className="text-stone-500">Gestão completa de dados cadastrais e espirituais</p>
        </div>
        <button 
          onClick={handleSave}
          className="flex items-center gap-2 bg-stone-900 text-white px-8 py-3 rounded-2xl font-bold hover:bg-stone-800 transition-all shadow-xl shadow-stone-900/10"
        >
          <Save size={20} /> Salvar Alterações
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Navigation */}
        <div className="lg:col-span-1 space-y-2">
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all border-2 ${
                activeSection === s.id 
                  ? 'bg-white border-amber-500 text-stone-900 shadow-md' 
                  : 'bg-transparent border-transparent text-stone-400 hover:bg-stone-100'
              }`}
            >
              <s.icon size={20} className={activeSection === s.id ? 'text-amber-500' : ''} />
              <span className="font-bold text-sm">{s.label}</span>
            </button>
          ))}
        </div>

        {/* Form Content */}
        <div className="lg:col-span-3 bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
          {activeSection === 'pessoal' && (
            <div className="space-y-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-24 h-24 bg-stone-100 rounded-3xl flex items-center justify-center text-stone-300 border-2 border-dashed border-stone-200 relative overflow-hidden group cursor-pointer">
                  <Camera size={32} />
                  <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="text-white text-[10px] font-bold">Alterar</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-black text-stone-900 uppercase text-xs tracking-widest">Foto de Perfil</h4>
                  <p className="text-xs text-stone-500">Formatos aceitos: JPG, PNG. Máx 2MB.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Nome Completo</label>
                  <input type="text" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={medium.fullName} onChange={e => setMedium({...medium, fullName: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">E-mail</label>
                  <input type="email" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={medium.email} onChange={e => setMedium({...medium, email: e.target.value})} />
                </div>
              </div>
            </div>
          )}

          {activeSection === 'financeiro' && (
            <div className="space-y-8 animate-in fade-in">
              <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 flex items-center gap-4">
                <Info className="text-amber-500" size={24} />
                <p className="text-sm text-stone-500 font-medium">Configure as regras de cobrança automática para este médium. As cobranças são geradas mensalmente com base nestes dados.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Valor da Mensalidade (R$)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                      <input 
                        type="number" 
                        disabled={!isMaster}
                        className="w-full pl-12 pr-4 py-4 bg-white border border-stone-200 rounded-2xl text-xl font-black outline-none focus:ring-4 focus:ring-amber-500/10 disabled:opacity-50"
                        value={medium.monthlyFeeValue || 0}
                        onChange={e => setMedium({...medium, monthlyFeeValue: parseFloat(e.target.value)})}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Dia de Vencimento (1-28)</label>
                    <input 
                      type="number" 
                      min="1" 
                      max="28"
                      disabled={!isMaster}
                      className="w-full px-4 py-4 bg-white border border-stone-200 rounded-2xl text-lg font-bold outline-none focus:ring-4 focus:ring-amber-500/10"
                      value={medium.feeDueDay || 10}
                      onChange={e => setMedium({...medium, feeDueDay: parseInt(e.target.value)})}
                    />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Início de Cobrança (Mês/Ano)</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                      <input 
                        type="month" 
                        disabled={!isMaster}
                        className="w-full pl-12 pr-4 py-4 bg-white border border-stone-200 rounded-2xl text-lg font-bold outline-none focus:ring-4 focus:ring-amber-500/10"
                        value={medium.feeChargeStart || ''}
                        onChange={e => setMedium({...medium, feeChargeStart: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-white border border-stone-200 rounded-2xl flex items-center justify-between">
                    <div>
                      <h5 className="font-black text-stone-900 text-sm">Status Isento</h5>
                      <p className="text-[10px] text-stone-500 font-bold uppercase">Não gera cobranças mensais</p>
                    </div>
                    <button 
                      onClick={() => isMaster && setMedium({...medium, feeIsExempt: !medium.feeIsExempt})}
                      className={`w-12 h-6 rounded-full p-1 transition-colors ${medium.feeIsExempt ? 'bg-amber-500' : 'bg-stone-200'} ${!isMaster ? 'cursor-not-allowed opacity-50' : ''}`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full transition-transform ${medium.feeIsExempt ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Observações Financeiras</label>
                <textarea 
                  className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm outline-none h-24 font-medium"
                  placeholder="Acordos específicos, bolsas, etc..."
                  value={medium.feeNotes || ''}
                  onChange={e => setMedium({...medium, feeNotes: e.target.value})}
                />
              </div>
            </div>
          )}

          {activeSection === 'espiritual' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Data de Entrada</label>
                  <input type="date" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={medium.entryDate} onChange={e => setMedium({...medium, entryDate: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-stone-400">Pai (Orixá)</label>
                  <input type="text" className="w-full bg-stone-50 border-stone-100 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={medium.paiOrixa} onChange={e => setMedium({...medium, paiOrixa: e.target.value})} />
                </div>
            </div>
          )}

          {activeSection === 'documentos' && (
            <div className="space-y-6">
              <div className="border-2 border-dashed border-stone-200 p-12 rounded-3xl flex flex-col items-center justify-center text-center space-y-4 hover:border-amber-500 transition-colors cursor-pointer group">
                <div className="w-16 h-16 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-400 group-hover:bg-amber-50 group-hover:text-amber-500 transition-all">
                  <FileText size={32} />
                </div>
                <div>
                  <p className="font-bold text-stone-900">Arraste seus documentos aqui</p>
                  <p className="text-xs text-stone-500">RG, CPF, Comprovante de Residência (PDF ou Imagem)</p>
                </div>
                <button className="bg-stone-900 text-white px-6 py-2 rounded-xl font-bold text-sm">Selecionar Arquivo</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediumFichaForm;


import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, QrCode, UserCheck, ShieldCheck, History as HistoryIcon, 
  Sparkles, RefreshCcw, CheckCircle2, XCircle, 
  Users, Calendar, Clock, Play, Square, AlertTriangle, Download, Trash2, Search, Filter
} from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
// Fixed imports: removed unused/missing EventoPresenca and EventStatus
import { 
  UserRole, 
  MediumProfile, 
  RegistroPresenca,
  AgendaEvent
} from '../types';

interface AttendanceProps {
  user: MediumProfile;
}

const AttendanceView: React.FC<AttendanceProps> = ({ user }) => {
  const [registros, setRegistros] = useState<RegistroPresenca[]>([]);
  const [events, setEvents] = useState<AgendaEvent[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState<{ type: 'success' | 'error' | 'idle', message: string }>({ type: 'idle', message: '' });
  const [selectedEventForReport, setSelectedEventForReport] = useState<string | 'ALL'>('ALL');
  
  const isMaster = user.role === UserRole.MASTER;
  const tId = user.terreiroId;
  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);

  // Carregar dados
  useEffect(() => {
    const savedRecords = JSON.parse(localStorage.getItem(`ase_records_${tId}`) || '[]');
    setRegistros(savedRecords);

    const savedEvents = JSON.parse(localStorage.getItem(`ase_agenda_${tId}`) || '[]');
    setEvents(savedEvents);

    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(console.error);
      }
    };
  }, [tId]);

  const startScanner = async () => {
    setIsScanning(true);
    setScanStatus({ type: 'idle', message: '' });

    setTimeout(async () => {
      try {
        const scanner = new Html5Qrcode("reader");
        html5QrCodeRef.current = scanner;

        await scanner.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: { width: 250, height: 250 } },
          onScanSuccess,
          onScanFailure
        );
      } catch (err) {
        console.error("Falha ao iniciar scanner:", err);
        setScanStatus({ type: 'error', message: "Não foi possível acessar a câmera." });
        setIsScanning(false);
      }
    }, 300);
  };

  const onScanSuccess = (decodedText: string) => {
    try {
      // Token format: terreiroId:eventId:timestamp:random
      const parts = decodedText.split(':');
      if (parts.length !== 4) {
        throw new Error("QR Code inválido.");
      }

      const [tokenTId, tokenEId, tokenTimestamp, tokenRandom] = parts;
      
      if (tokenTId !== tId) {
        throw new Error("Este QR Code pertence a outro Terreiro.");
      }

      // Validar se o token existe no localStorage e não expirou
      const savedTokens = JSON.parse(localStorage.getItem(`ase_tokens_${tId}`) || '{}');
      const tokenInfo = savedTokens[tokenEId];

      if (!tokenInfo || tokenInfo.token !== decodedText) {
        throw new Error("QR Code inválido ou obsoleto.");
      }

      if (new Date(tokenInfo.expiresAt) < new Date()) {
        throw new Error("Este QR Code expirou.");
      }

      // Validar se já marcou presença
      const alreadyRegistered = registros.some(r => r.eventoId === tokenEId && r.mediumId === user.id);
      if (alreadyRegistered) {
        throw new Error("Sua presença já foi registrada para este evento.");
      }

      const event = events.find(e => e.id === tokenEId);
      const newRecord: RegistroPresenca = {
        id: `REG-${Math.random().toString(36).substr(2, 5)}`,
        terreiroId: tId,
        eventoId: tokenEId,
        mediumId: user.id,
        mediumName: user.fullName,
        dataHoraRegistro: new Date().toISOString(),
        origem: 'QR',
        valido: true
      };

      const updatedRecords = [newRecord, ...registros];
      localStorage.setItem(`ase_records_${tId}`, JSON.stringify(updatedRecords));
      setRegistros(updatedRecords);
      
      setScanStatus({ type: 'success', message: `Presença confirmada: ${event?.title || 'Evento'}!` });
      stopScanner();

    } catch (err: any) {
      setScanStatus({ type: 'error', message: err.message || "Erro ao validar QR Code." });
      stopScanner();
    }
  };

  const onScanFailure = (error: any) => {
    // Busca contínua
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current) {
      try {
        if (html5QrCodeRef.current.isScanning) {
          await html5QrCodeRef.current.stop();
        }
      } catch (e) {
        console.error("Erro ao fechar scanner", e);
      }
    }
    setIsScanning(false);
  };

  const handleExportCSV = () => {
    const recordsToExport = selectedEventForReport === 'ALL' 
      ? registros 
      : registros.filter(r => r.eventoId === selectedEventForReport);
    
    if (recordsToExport.length === 0) return alert("Nenhum registro para exportar.");

    const headers = "ID,Evento,Medium,Data,Hora,Origem\n";
    const csvContent = recordsToExport.map(r => {
      const eventName = events.find(e => e.id === r.eventoId)?.title || 'Desconhecido';
      const date = new Date(r.dataHoraRegistro).toLocaleDateString();
      const time = new Date(r.dataHoraRegistro).toLocaleTimeString();
      return `${r.id},${eventName},${r.mediumName},${date},${time},${r.origem}`;
    }).join("\n");

    const blob = new Blob([headers + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `presencas_${selectedEventForReport === 'ALL' ? 'geral' : selectedEventForReport}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredRecords = registros.filter(r => 
    selectedEventForReport === 'ALL' ? true : r.eventoId === selectedEventForReport
  );

  const myRecords = registros.filter(r => r.mediumId === user.id);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tighter">Presença Asé</h1>
          <p className="text-stone-500">{isMaster ? 'Relatórios e controle de corrente' : 'Confirme sua participação nos eventos'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Lado Esquerdo: Scanner ou Histórico do Médium */}
        <div className="bg-white p-8 md:p-12 rounded-[3rem] border border-stone-200 shadow-xl min-h-[400px]">
          {!isScanning && scanStatus.type === 'idle' && (
            <div className="flex flex-col items-center text-center py-10 space-y-6">
              <div className="w-24 h-24 bg-amber-100 rounded-[2rem] flex items-center justify-center text-amber-600 shadow-inner">
                <QrCode size={48} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-stone-900">Registrar Presença</h3>
                <p className="text-stone-500 text-sm max-w-[250px]">Escaneie o QR Code gerado pelo Pai de Santo para confirmar sua presença.</p>
              </div>
              <button 
                onClick={startScanner}
                className="w-full py-5 bg-stone-900 text-white font-black rounded-3xl flex items-center justify-center gap-4 hover:bg-stone-800 transition-all shadow-2xl shadow-stone-900/20"
              >
                <Camera size={24} /> Escanear QR Code
              </button>
            </div>
          )}

          {isScanning && (
            <div className="space-y-6 animate-in fade-in">
              <div className="relative">
                <div id="reader" className="overflow-hidden rounded-[2.5rem] bg-stone-100 min-h-[300px] border-4 border-stone-900"></div>
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-48 h-48 border-2 border-amber-500 rounded-3xl animate-pulse"></div>
                </div>
              </div>
              <button 
                onClick={stopScanner}
                className="w-full py-4 bg-stone-100 text-stone-500 font-black rounded-2xl hover:bg-stone-200 transition-all"
              >
                Cancelar
              </button>
            </div>
          )}

          {scanStatus.type !== 'idle' && (
            <div className="flex flex-col items-center text-center py-10 space-y-6 animate-in zoom-in duration-300">
              <div className={`w-24 h-24 rounded-[2rem] flex items-center justify-center shadow-lg ${
                scanStatus.type === 'success' ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
              }`}>
                {scanStatus.type === 'success' ? <CheckCircle2 size={48} /> : <XCircle size={48} />}
              </div>
              <div className="space-y-2">
                <h3 className={`text-2xl font-black ${scanStatus.type === 'success' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {scanStatus.type === 'success' ? 'Confirmado!' : 'Ops!'}
                </h3>
                <p className="text-stone-600 font-bold px-4">{scanStatus.message}</p>
              </div>
              <button 
                onClick={() => setScanStatus({ type: 'idle', message: '' })}
                className="px-8 py-3 bg-stone-900 text-white font-black rounded-2xl hover:bg-stone-800"
              >
                Voltar
              </button>
            </div>
          )}
        </div>

        {/* Lado Direito: Relatórios (Master) ou Histórico (Medium) */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm overflow-hidden min-h-[400px]">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black text-stone-900 flex items-center gap-3">
                {isMaster ? <Users size={24} className="text-amber-500" /> : <HistoryIcon size={24} className="text-amber-500" />}
                {isMaster ? 'Relatório de Corrente' : 'Minhas Presenças'}
              </h3>
              {isMaster && registros.length > 0 && (
                <button 
                  onClick={handleExportCSV}
                  className="p-2 bg-stone-100 text-stone-500 rounded-xl hover:bg-stone-900 hover:text-white transition-all"
                  title="Exportar CSV"
                >
                  <Download size={18} />
                </button>
              )}
            </div>

            {isMaster && (
              <div className="mb-6">
                <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest mb-2 block">Filtrar por Evento</label>
                <select 
                  className="w-full bg-stone-50 border-stone-100 rounded-2xl p-4 text-sm font-bold outline-none"
                  value={selectedEventForReport}
                  onChange={(e) => setSelectedEventForReport(e.target.value)}
                >
                  <option value="ALL">Todos os Registros</option>
                  {events.map(ev => <option key={ev.id} value={ev.id}>{ev.title} ({new Date(ev.date + 'T12:00:00').toLocaleDateString()})</option>)}
                </select>
              </div>
            )}

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {isMaster ? (
                filteredRecords.length > 0 ? (
                  filteredRecords.map(record => (
                    <div key={record.id} className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100 animate-in slide-in-from-right-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-stone-900 font-black border border-stone-200">
                          {record.mediumName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-stone-900 text-sm">{record.mediumName}</p>
                          <p className="text-[9px] text-stone-400 font-black uppercase">
                            {events.find(e => e.id === record.eventoId)?.title || 'Evento'} • {new Date(record.dataHoraRegistro).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center">
                        <UserCheck size={16} />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-stone-300">
                    <Users size={48} className="mx-auto mb-4 opacity-10" />
                    <p className="font-bold text-sm">Nenhum registro encontrado.</p>
                  </div>
                )
              ) : (
                myRecords.length > 0 ? (
                  myRecords.map(record => (
                    <div key={record.id} className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-100">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center text-stone-900 font-black">
                          <CheckCircle2 size={20} />
                        </div>
                        <div>
                          <p className="font-bold text-stone-900 text-sm">{events.find(e => e.id === record.eventoId)?.title || 'Gira Registrada'}</p>
                          <p className="text-[10px] text-stone-500 font-black uppercase">
                            {new Date(record.dataHoraRegistro).toLocaleDateString()} às {new Date(record.dataHoraRegistro).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full">Validado</span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-stone-300">
                    <HistoryIcon size={48} className="mx-auto mb-4 opacity-10" />
                    <p className="font-bold text-sm">Você ainda não tem presenças registradas.</p>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e7e5e4;
          border-radius: 10px;
        }
        #reader video {
           border-radius: 2rem !important;
           object-fit: cover !important;
        }
      `}</style>
    </div>
  );
};

export default AttendanceView;

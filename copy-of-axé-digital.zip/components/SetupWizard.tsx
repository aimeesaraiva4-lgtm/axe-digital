
import React, { useState } from 'react';
import { Building2, Sparkles, User, ArrowRight, ShieldCheck, Globe, Key, UserPlus } from 'lucide-react';
import { Terreiro, UserRole, MembershipStatus, MediumProfile } from '../types';

interface SetupProps {
  onComplete: (t: Terreiro, u: MediumProfile) => void;
}

const SetupWizard: React.FC<SetupProps> = ({ onComplete }) => {
  const [mode, setMode] = useState<'CHOICE' | 'CREATE' | 'JOIN'>('CHOICE');
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    terreiroName: '',
    foundationDate: '',
    masterName: '',
    masterEmail: '',
    masterPhone: '',
    orixa: '',
    inviteCode: ''
  });

  const handleCreateTerreiro = () => {
    const newTerreiro: Terreiro = {
      id: `T-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      name: formData.terreiroName,
      foundationDate: formData.foundationDate,
      masterPhone: formData.masterPhone,
      plan: 'FREE',
      responsible: formData.masterName
    };

    const newMaster: MediumProfile = {
      id: `U-${Math.random().toString(36).substr(2, 5)}`,
      terreiroId: newTerreiro.id,
      role: UserRole.MASTER,
      status: MembershipStatus.ACTIVE,
      fullName: formData.masterName,
      email: formData.masterEmail,
      phone: formData.masterPhone,
      entryDate: new Date().toISOString(),
      balance: 0,
      paiOrixa: formData.orixa,
      fatherName: '', motherName: '', address: '', nationality: '', profession: '',
      birthDate: '', bloodType: '', emergencyContactName: '', emergencyContactPhone: '',
      emergencyContactRelation: '', hasDisease: false, continuousMedicine: false,
      chefeDeCabeca: '', spiritualHistory: '', anjoGuarda: '', exu: '', trancaRua: '',
      maeOrixa: '', gerente: '', segundoOrixa: '', terceiroOrixa: ''
    };

    onComplete(newTerreiro, newMaster);
  };

  const handleJoinTerreiro = () => {
    // Simulação de busca de terreiro por código
    const joinedTerreiro: Terreiro = {
      id: 'T-SaaS-001',
      name: 'Terreiro de Demonstração (SaaS)',
      foundationDate: '2010-01-01',
      masterPhone: '1199999999',
      // Fix: 'PRO' is not a valid plan type in Terreiro interface. Changing to 'CASA_DIGITAL'.
      plan: 'CASA_DIGITAL'
    };

    const newMedium: MediumProfile = {
      id: `U-${Math.random().toString(36).substr(2, 5)}`,
      terreiroId: joinedTerreiro.id,
      role: UserRole.MEDIUM,
      status: MembershipStatus.PENDING,
      fullName: formData.masterName,
      email: formData.masterEmail,
      phone: formData.masterPhone,
      entryDate: new Date().toISOString(),
      balance: 0,
      paiOrixa: formData.orixa,
      fatherName: '', motherName: '', address: '', nationality: '', profession: '',
      birthDate: '', bloodType: '', emergencyContactName: '', emergencyContactPhone: '',
      emergencyContactRelation: '', hasDisease: false, continuousMedicine: false,
      chefeDeCabeca: '', spiritualHistory: '', anjoGuarda: '', exu: '', trancaRua: '',
      maeOrixa: '', gerente: '', segundoOrixa: '', terceiroOrixa: ''
    };

    onComplete(joinedTerreiro, newMedium);
  };

  if (mode === 'CHOICE') {
    return (
      <div className="min-h-screen bg-stone-900 flex items-center justify-center p-6">
        <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 animate-in zoom-in-95 duration-500">
          <button 
            onClick={() => setMode('CREATE')}
            className="group bg-white p-12 rounded-[3rem] text-left hover:ring-8 hover:ring-amber-500/20 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 mb-8 group-hover:bg-amber-500 group-hover:text-white transition-all">
                <Building2 size={32} />
              </div>
              <h2 className="text-3xl font-black text-stone-900 tracking-tighter leading-tight">Sou Gestor de Terreiro(s)</h2>
              <p className="mt-4 text-stone-500 font-medium">Quero criar uma conta administrativa para gerir uma ou mais unidades simultaneamente.</p>
            </div>
            <div className="mt-12 flex items-center gap-2 font-black text-amber-600 uppercase tracking-widest text-sm">
              Criar Conta SaaS <ArrowRight size={18} />
            </div>
          </button>

          <button 
            onClick={() => setMode('JOIN')}
            className="group bg-stone-800 p-12 rounded-[3rem] text-left hover:ring-8 hover:ring-white/10 transition-all flex flex-col justify-between border border-stone-700"
          >
            <div>
              <div className="w-16 h-16 bg-stone-700 rounded-2xl flex items-center justify-center text-stone-300 mb-8 group-hover:bg-white group-hover:text-stone-900 transition-all">
                <Key size={32} />
              </div>
              <h2 className="text-3xl font-black text-white tracking-tighter leading-tight">Sou Médium da Corrente</h2>
              <p className="mt-4 text-stone-400 font-medium">Já faço parte de um terreiro e recebi um código de convite para acessar o Asé Digital.</p>
            </div>
            <div className="mt-12 flex items-center gap-2 font-black text-white uppercase tracking-widest text-sm">
              Entrar em Unidade <ArrowRight size={18} />
            </div>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-900 flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-in fade-in duration-500">
        <div className="bg-amber-500 p-12 text-stone-900 relative">
          <button onClick={() => setMode('CHOICE')} className="absolute top-8 right-8 text-stone-900/40 hover:text-stone-900 font-bold text-xs uppercase">Cancelar</button>
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-xl mb-6">
            {mode === 'CREATE' ? <Building2 size={32} /> : <UserPlus size={32} />}
          </div>
          <h1 className="text-4xl font-black tracking-tighter leading-tight">
            {mode === 'CREATE' ? 'Configurar\nPrimeira Unidade' : 'Entrar na\nCorrente'}
          </h1>
          <p className="mt-4 font-bold text-stone-900/70">
            {mode === 'CREATE' ? 'Inicie sua jornada SaaS hoje.' : 'Informe o código enviado pelo seu terreiro.'}
          </p>
        </div>

        <div className="p-12 space-y-8">
          {mode === 'JOIN' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-stone-400">Código de Convite</label>
                <input 
                  type="text" 
                  placeholder="Ex: ASE-12345"
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-xl font-black text-stone-900 uppercase placeholder:text-stone-300 outline-none focus:ring-4 focus:ring-amber-500/20"
                  onChange={e => setFormData({...formData, inviteCode: e.target.value})}
                />
              </div>
            </div>
          )}

          {mode === 'CREATE' && step === 1 && (
            <div className="space-y-6 animate-in slide-in-from-right-4">
              <h3 className="text-xl font-black text-stone-900 flex items-center gap-3">
                <Building2 size={24} className="text-amber-500" /> Detalhes do Terreiro
              </h3>
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Nome do Terreiro"
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-stone-900 outline-none focus:ring-2 focus:ring-amber-500"
                  onChange={e => setFormData({...formData, terreiroName: e.target.value})}
                />
                <input 
                  type="date" 
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-stone-900 outline-none focus:ring-2 focus:ring-amber-500"
                  onChange={e => setFormData({...formData, foundationDate: e.target.value})}
                />
              </div>
              <button 
                onClick={() => setStep(2)}
                disabled={!formData.terreiroName}
                className="w-full py-4 bg-stone-900 text-white font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-stone-800 disabled:opacity-50 transition-all"
              >
                Próximo Passo <ArrowRight size={20} />
              </button>
            </div>
          )}

          {(mode === 'JOIN' || (mode === 'CREATE' && step === 2)) && (
            <div className="space-y-6 animate-in slide-in-from-right-4">
              <h3 className="text-xl font-black text-stone-900 flex items-center gap-3">
                <User size={24} className="text-amber-500" /> Seu Perfil de Gestor
              </h3>
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Seu Nome Completo"
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-stone-900 outline-none focus:ring-2 focus:ring-amber-500"
                  onChange={e => setFormData({...formData, masterName: e.target.value})}
                />
                <input 
                  type="email" 
                  placeholder="Seu E-mail"
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-stone-900 outline-none focus:ring-2 focus:ring-amber-500"
                  onChange={e => setFormData({...formData, masterEmail: e.target.value})}
                />
                <input 
                  type="text" 
                  placeholder="Seu Orixá de Cabeça"
                  className="w-full bg-stone-50 border-stone-200 rounded-2xl p-4 text-stone-900 outline-none focus:ring-2 focus:ring-amber-500"
                  onChange={e => setFormData({...formData, orixa: e.target.value})}
                />
              </div>
              <button 
                onClick={mode === 'CREATE' ? handleCreateTerreiro : handleJoinTerreiro}
                className="w-full py-4 bg-amber-500 text-stone-900 font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-amber-400 shadow-xl shadow-amber-500/20 transition-all"
              >
                {mode === 'CREATE' ? 'Ativar Conta Master' : 'Solicitar Entrada'} <Sparkles size={20} />
              </button>
            </div>
          )}
        </div>
        <div className="bg-stone-50 p-6 flex justify-center gap-8 border-t border-stone-100">
           <div className="flex items-center gap-2 text-stone-400 text-xs font-bold">
             <Globe size={14} /> Arquitetura SaaS
           </div>
           <div className="flex items-center gap-2 text-stone-400 text-xs font-bold">
             <ShieldCheck size={14} /> Dados Isolados
           </div>
        </div>
      </div>
    </div>
  );
};

export default SetupWizard;
